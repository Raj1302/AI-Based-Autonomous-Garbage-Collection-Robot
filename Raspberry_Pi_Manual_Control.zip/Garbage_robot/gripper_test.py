from adafruit_servokit import ServoKit
import time

# ==========================================
# PCA9685 SETUP
# ==========================================

kit = ServoKit(channels=16, address=0x40)
kit.frequency = 50

# ==========================================
# GRIPPER
# CH5 - MG90S
# ==========================================

GRIPPER = 5

kit.servo[GRIPPER].set_pulse_width_range(500, 2500)


# ==========================================
# SLOW MOVEMENT
# ==========================================

def slow_move(start_angle, end_angle, delay=0.03):

    if start_angle < end_angle:
        for angle in range(start_angle, end_angle + 1):
            kit.servo[GRIPPER].angle = angle
            time.sleep(delay)

    else:
        for angle in range(start_angle, end_angle - 1, -1):
            kit.servo[GRIPPER].angle = angle
            time.sleep(delay)


# ==========================================
# GRIPPER TEST
# ==========================================

try:

    print("\n========================================")
    print("       GRIPPER TEST")
    print("========================================")

    # --------------------------------------
    # INITIAL POSITION
    # --------------------------------------

    print("\nMoving Gripper to 90 degrees...")

    kit.servo[GRIPPER].angle = 90

    time.sleep(2)

    print("Gripper is now at 90 degrees.")


    # --------------------------------------
    # OPEN
    # --------------------------------------

    input("\nPress ENTER to OPEN the gripper...")

    print("Opening: 90° -> 0°")

    slow_move(90,0)

    print("Gripper OPEN.")


    # --------------------------------------
    # CLOSE
    # --------------------------------------

    input("\nPress ENTER to CLOSE the gripper...")

    print("Closing: 10° -> 155°")

    slow_move(20, 140)

    print("Gripper CLOSED.")


    # --------------------------------------
    # FINISH
    # --------------------------------------

    input("\nPress ENTER to release servo signal and exit...")


except KeyboardInterrupt:

    print("\nTest stopped by user.")


finally:

    kit.servo[GRIPPER].angle = None

    print("Servo signal released.")
