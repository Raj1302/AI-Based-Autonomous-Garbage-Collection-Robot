import cv2

camera = cv2.VideoCapture("/dev/video0", cv2.CAP_V4L2)

camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
camera.set(cv2.CAP_PROP_FPS, 30)

if not camera.isOpened():
    print("ERROR: Could not open USB camera")
    exit()

print("Camera started.")
print("Resolution:",
      int(camera.get(cv2.CAP_PROP_FRAME_WIDTH)),
      "x",
      int(camera.get(cv2.CAP_PROP_FRAME_HEIGHT)))

print("FPS:", camera.get(cv2.CAP_PROP_FPS))
print("Press Q to quit.")

while True:
    ret, frame = camera.read()

    if not ret:
        print("ERROR: Failed to read frame")
        break

    cv2.imshow("Garbage Collection CAR - Camera Test", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

camera.release()
cv2.destroyAllWindows()
