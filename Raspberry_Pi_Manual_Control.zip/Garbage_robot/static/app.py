from flask import Flask, request, jsonify, send_from_directory, Response
from gpiozero import OutputDevice, DistanceSensor
import atexit
import time
from adafruit_servokit import ServoKit
import cv2

# =========================================================
# PCA9685 SERVO SETUP
# =========================================================

kit = ServoKit(channels=16, address=0x40)
kit.frequency = 50

# GC-Bot servo channels
SERVO_CHANNELS = {
    "base": 0,
    "shoulder": 1,
    "elbow": 2,
    "wrist": 3,
    "wristRotation": 4,
    "gripper": 5
}

# MG995 / MG90S pulse range
# Tested successfully with your servo.
# 500–2500 microseconds = 0–180 degree command range.
for channel in SERVO_CHANNELS.values():
    kit.servo[channel].set_pulse_width_range(500, 2500)


app = Flask(__name__, static_folder=".")

camera = cv2.VideoCapture("/dev/video0", cv2.CAP_V4L2)
camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
camera.set(cv2.CAP_PROP_FPS, 30)


# =========================================================
# HARDWARE
# =========================================================

HARDWARE_ENABLED = True


# =========================================================
# MOTOR GPIO
# =========================================================

# Left side - L298N #1
FL_IN1 = 17
FL_IN2 = 27

RL_IN1 = 22
RL_IN2 = 23

# Right side - L298N #2
FR_IN1 = 5
FR_IN2 = 6

RR_IN1 = 13
RR_IN2 = 26


# Create motor outputs
fl1 = OutputDevice(FL_IN1, initial_value=False)
fl2 = OutputDevice(FL_IN2, initial_value=False)

rl1 = OutputDevice(RL_IN1, initial_value=False)
rl2 = OutputDevice(RL_IN2, initial_value=False)

fr1 = OutputDevice(FR_IN1, initial_value=False)
fr2 = OutputDevice(FR_IN2, initial_value=False)

rr1 = OutputDevice(RR_IN1, initial_value=False)
rr2 = OutputDevice(RR_IN2, initial_value=False)


# =========================================================
# ULTRASONIC
# =========================================================

# Front:
# TRIG GPIO9
# ECHO GPIO25
front_sensor = DistanceSensor(
    echo=25,
    trigger=9,
    max_distance=4
)

# Rear:
# TRIG GPIO16
# ECHO GPIO12
rear_sensor = DistanceSensor(
    echo=12,
    trigger=16,
    max_distance=4
)


# =========================================================
# ROBOT STATE
# =========================================================

robot_state = {
    "drive": "stop",
    "emergency": False,

    "servos": {
        "base": 90,
        "shoulder": 90,
        "elbow": 90,
        "wrist": 90,
        "wristRotation": 90,
        "gripper": 90
    },

    "frontDistance": None,
    "rearDistance": None
}


# =========================================================
# LOW LEVEL MOTOR FUNCTIONS
# =========================================================

def motor_forward(a, b):
    a.on()
    b.off()


def motor_backward(a, b):
    a.off()
    b.on()


def motor_stop(a, b):
    a.off()
    b.off()


def all_motors_stop():

    motor_stop(fl1, fl2)
    motor_stop(rl1, rl2)
    motor_stop(fr1, fr2)
    motor_stop(rr1, rr2)


# =========================================================
# DRIVE CONTROL
# =========================================================

def drive_robot(direction):

    if not HARDWARE_ENABLED:
        print("Hardware disabled")
        return

    # Emergency protection
    if robot_state["emergency"] and direction != "stop":
        print("EMERGENCY STOP ACTIVE")
        all_motors_stop()
        return

    # STOP
    if direction == "stop":

        all_motors_stop()

    # -----------------------------------------------------
    # FORWARD
    # -----------------------------------------------------

    elif direction == "forward":

        motor_forward(fl1, fl2)
        motor_forward(rl1, rl2)

        # Right motors are reversed because of mirrored
        # wheel orientation.
        motor_backward(fr1, fr2)
        motor_backward(rr1, rr2)

    # -----------------------------------------------------
    # BACKWARD
    # -----------------------------------------------------

    elif direction == "backward":

        motor_backward(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_forward(rr1, rr2)

    # -----------------------------------------------------
    # STRAFE LEFT
    # -----------------------------------------------------

    elif direction == "left":

        motor_backward(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_forward(rr1, rr2)

    # -----------------------------------------------------
    # STRAFE RIGHT
    # -----------------------------------------------------

    elif direction == "right":

        motor_forward(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_backward(rr1, rr2)

    # -----------------------------------------------------
    # ROTATE LEFT
    # -----------------------------------------------------

    elif direction == "rotate_left":

        motor_backward(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_backward(rr1, rr2)

    # -----------------------------------------------------
    # ROTATE RIGHT
    # -----------------------------------------------------

    elif direction == "rotate_right":

        motor_forward(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_forward(rr1, rr2)

    # -----------------------------------------------------
    # DIAGONAL FORWARD LEFT
    # -----------------------------------------------------

    elif direction == "forward_left":

        motor_stop(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_stop(rr1, rr2)

    # -----------------------------------------------------
    # DIAGONAL FORWARD RIGHT
    # -----------------------------------------------------

    elif direction == "forward_right":

        motor_forward(fl1, fl2)
        motor_stop(rl1, rl2)

        motor_stop(fr1, fr2)
        motor_backward(rr1, rr2)

    # -----------------------------------------------------
    # DIAGONAL BACKWARD LEFT
    # -----------------------------------------------------

    elif direction == "backward_left":

        motor_backward(fl1, fl2)
        motor_stop(rl1, rl2)

        motor_stop(fr1, fr2)
        motor_forward(rr1, rr2)

    # -----------------------------------------------------
    # DIAGONAL BACKWARD RIGHT
    # -----------------------------------------------------

    elif direction == "backward_right":

        motor_stop(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_stop(rr1, rr2)

    else:

        all_motors_stop()
        direction = "stop"

    robot_state["drive"] = direction

    print("DRIVE COMMAND:", direction)


# =========================================================
# SERVO CONTROL
# =========================================================

def set_servo(name, angle):

    if name not in SERVO_CHANNELS:
        return False

    angle = max(0, min(180, int(angle)))

    channel = SERVO_CHANNELS[name]

    kit.servo[channel].angle = angle

    robot_state["servos"][name] = angle

    print(f"SERVO {name}: {angle} degrees")

    return True


# =========================================================
# ARM PRESETS
# =========================================================

def arm_preset(preset):

    presets = {

        "home": {
            "base": 90,
            "shoulder": 90,
            "elbow": 90,
            "wrist": 90,
            "wristRotation": 90,
            "gripper": 90
        },

        "grab": {
            "base": 90,
            "shoulder": 120,
            "elbow": 60,
            "wrist": 80,
            "wristRotation": 90,
            "gripper": 30
        },

        "release": {
            "base": 90,
            "shoulder": 100,
            "elbow": 80,
            "wrist": 90,
            "wristRotation": 90,
            "gripper": 120
        }
    }

    if preset not in presets:
        return False

    print("ARM PRESET:", preset)

    for servo, angle in presets[preset].items():
        set_servo(servo, angle)

    return True


# =========================================================
# WEB PAGE
# =========================================================

def generate_frames():

    while True:

        success, frame = camera.read()

        if not success:
            continue

        ret, buffer = cv2.imencode(".jpg", frame)

        if not ret:
            continue

        frame = buffer.tobytes()

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + frame +
            b"\r\n"
        )


@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/style.css")
def style():
    return send_from_directory(".", "style.css")


@app.route("/script.js")
def script():
    return send_from_directory(".", "script.js")


@app.route("/video_feed")
def video_feed():

    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )


# =========================================================
# DRIVE API
# =========================================================

@app.route("/api/drive", methods=["POST"])
def api_drive():

    data = request.get_json(silent=True) or {}

    direction = data.get("direction", "stop")

    allowed = [

        "forward",
        "backward",
        "left",
        "right",
        "rotate_left",
        "rotate_right",
        "forward_left",
        "forward_right",
        "backward_left",
        "backward_right",
        "stop"
    ]

    if direction not in allowed:

        return jsonify({
            "success": False,
            "error": "Invalid drive command"
        }), 400

    drive_robot(direction)

    return jsonify({
        "success": True,
        "direction": direction
    })


# =========================================================
# SERVO API
# =========================================================

@app.route("/api/servo", methods=["POST"])
def api_servo():

    data = request.get_json(silent=True) or {}

    name = data.get("name")
    angle = data.get("angle")

    if name is None or angle is None:

        return jsonify({
            "success": False,
            "error": "Servo name and angle required"
        }), 400

    try:
        angle = int(angle)

    except:

        return jsonify({
            "success": False,
            "error": "Invalid angle"
        }), 400

    if not set_servo(name, angle):

        return jsonify({
            "success": False,
            "error": "Unknown servo"
        }), 400

    return jsonify({
        "success": True,
        "servo": name,
        "angle": angle
    })


# =========================================================
# ARM PRESET API
# =========================================================

@app.route("/api/arm-preset", methods=["POST"])
def api_arm_preset():

    data = request.get_json(silent=True) or {}

    preset = data.get("preset")

    if not arm_preset(preset):

        return jsonify({
            "success": False,
            "error": "Unknown preset"
        }), 400

    return jsonify({
        "success": True,
        "preset": preset,
        "servos": robot_state["servos"]
    })


# =========================================================
# EMERGENCY STOP
# =========================================================

@app.route("/api/emergency", methods=["POST"])
def api_emergency():

    robot_state["emergency"] = True

    all_motors_stop()

    robot_state["drive"] = "stop"

    print("")
    print("================================")
    print("       EMERGENCY STOP")
    print("================================")
    print("")

    return jsonify({
        "success": True,
        "emergency": True
    })


# =========================================================
# RESET EMERGENCY
# =========================================================

@app.route("/api/emergency/reset", methods=["POST"])
def reset_emergency():

    robot_state["emergency"] = False

    print("Emergency stop reset")

    return jsonify({
        "success": True,
        "emergency": False
    })


# =========================================================
# SENSOR DISTANCE
# =========================================================

def get_distance_cm(sensor):

    try:

        distance = sensor.distance * 100

        if distance < 2:
            return None

        if distance > 400:
            return None

        return round(distance, 1)

    except:

        return None


# =========================================================
# STATUS API
# =========================================================

@app.route("/api/status", methods=["GET"])
def status():

    front = get_distance_cm(front_sensor)
    rear = get_distance_cm(rear_sensor)

    robot_state["frontDistance"] = front
    robot_state["rearDistance"] = rear

    return jsonify(robot_state)


# =========================================================
# CLEANUP
# =========================================================

def cleanup():

    print("Stopping motors...")

    all_motors_stop()

    front_sensor.close()
    rear_sensor.close()

    fl1.close()
    fl2.close()
    rl1.close()
    rl2.close()

    fr1.close()
    fr2.close()
    rr1.close()
    rr2.close()


atexit.register(cleanup)


# =========================================================
# START SERVER
# =========================================================

if __name__ == "__main__":

    # Make absolutely sure motors start stopped.
    all_motors_stop()

    print("")
    print("======================================")
    print("       GARBAGE ROBOT SERVER")
    print("======================================")
    print("")
    print("Hardware enabled:", HARDWARE_ENABLED)
    print("")
    print("Motor GPIO:")
    print("FL = 17,27")
    print("RL = 22,23")
    print("FR = 5,6")
    print("RR = 13,26")
    print("")
    print("Front ultrasonic: TRIG 9 / ECHO 25")
    print("Rear ultrasonic:  TRIG 16 / ECHO 12")
    print("")
    print("PCA9685:")
    print("Address = 0x40")
    print("Servo pulse range = 500–2500 us")
    print("Servo channels = CH0–CH5")
    print("")
    print("Open on phone:")
    print("http://192.168.1.32:5000")
    print("")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False
    )