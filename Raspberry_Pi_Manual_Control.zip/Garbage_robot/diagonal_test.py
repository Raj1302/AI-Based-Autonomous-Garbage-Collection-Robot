import RPi.GPIO as GPIO
import time

# =========================================================
# GPIO SETUP
# =========================================================

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# =========================================================
# L298N #1
# Front Left (FL)
# Back Left (BL)
# =========================================================

FL_IN1 = 17
FL_IN2 = 27

BL_IN1 = 24
BL_IN2 = 10

FL_EN = 18
BL_EN = 19

# =========================================================
# L298N #2
# Front Right (FR)
# Back Right (BR)
# =========================================================

FR_IN1 = 5
FR_IN2 = 6

BR_IN1 = 13
BR_IN2 = 26

FR_EN = 20
BR_EN = 21

# =========================================================
# SETUP PINS
# =========================================================

motor_pins = [
    FL_IN1, FL_IN2,
    BL_IN1, BL_IN2,
    FR_IN1, FR_IN2,
    BR_IN1, BR_IN2
]

for pin in motor_pins:
    GPIO.setup(pin, GPIO.OUT)

GPIO.setup(FL_EN, GPIO.OUT)
GPIO.setup(BL_EN, GPIO.OUT)
GPIO.setup(FR_EN, GPIO.OUT)
GPIO.setup(BR_EN, GPIO.OUT)

# =========================================================
# PWM
# =========================================================

fl_pwm = GPIO.PWM(FL_EN, 1000)
bl_pwm = GPIO.PWM(BL_EN, 1000)
fr_pwm = GPIO.PWM(FR_EN, 1000)
br_pwm = GPIO.PWM(BR_EN, 1000)

fl_pwm.start(0)
bl_pwm.start(0)
fr_pwm.start(0)
br_pwm.start(0)

# FULL SPEED
SPEED = 100


# =========================================================
# MOTOR FUNCTIONS
# =========================================================

def forward(in1, in2):
    GPIO.output(in1, GPIO.HIGH)
    GPIO.output(in2, GPIO.LOW)


def backward(in1, in2):
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.HIGH)


def stop_motor(in1, in2, pwm):
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.LOW)
    pwm.ChangeDutyCycle(0)


# =========================================================
# STOP ALL
# =========================================================

def stop_all():
    stop_motor(FL_IN1, FL_IN2, fl_pwm)
    stop_motor(BL_IN1, BL_IN2, bl_pwm)
    stop_motor(FR_IN1, FR_IN2, fr_pwm)
    stop_motor(BR_IN1, BR_IN2, br_pwm)


# =========================================================
# DIAGONAL FORWARD LEFT
#
# FL = FORWARD
# BR = FORWARD
# FR = STOP
# BL = STOP
# =========================================================

def diagonal_forward_left():

    forward(FL_IN1, FL_IN2)
    fl_pwm.ChangeDutyCycle(SPEED)

    forward(BR_IN1, BR_IN2)
    br_pwm.ChangeDutyCycle(SPEED)

    stop_motor(FR_IN1, FR_IN2, fr_pwm)
    stop_motor(BL_IN1, BL_IN2, bl_pwm)


# =========================================================
# DIAGONAL BACKWARD RIGHT
#
# FR = BACKWARD
# BL = BACKWARD
# FL = STOP
# BR = STOP
# =========================================================

def diagonal_backward_right():

    backward(FR_IN1, FR_IN2)
    fr_pwm.ChangeDutyCycle(SPEED)

    backward(BL_IN1, BL_IN2)
    bl_pwm.ChangeDutyCycle(SPEED)

    stop_motor(FL_IN1, FL_IN2, fl_pwm)
    stop_motor(BR_IN1, BR_IN2, br_pwm)


# =========================================================
# TEST
# =========================================================

try:

    print("======================================")
    print(" GC BOT - DIAGONAL MOTOR TEST")
    print(" PWM SPEED = 100%")
    print("======================================")

    while True:

        print("DIAGONAL FORWARD LEFT")
        diagonal_forward_left()

        time.sleep(3)

        print("STOP")
        stop_all()

        time.sleep(2)

        print("DIAGONAL BACKWARD RIGHT")
        diagonal_backward_right()

        time.sleep(3)

        print("STOP")
        stop_all()

        time.sleep(2)


except KeyboardInterrupt:

    print("\nTest stopped.")


finally:

    stop_all()

    fl_pwm.stop()
    bl_pwm.stop()
    fr_pwm.stop()
    br_pwm.stop()

    GPIO.cleanup()

    print("GPIO cleaned up.")
