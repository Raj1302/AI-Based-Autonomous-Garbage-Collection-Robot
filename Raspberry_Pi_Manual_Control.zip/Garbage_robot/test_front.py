from gpiozero import DistanceSensor
from time import sleep

sensor = DistanceSensor(
    echo=25,
    trigger=9,
    max_distance=4
)

print("REAR HC-SR04 TEST")
print("TRIG = GPIO 16")
print("ECHO = GPIO 12")
print("Put an object 20-100 cm behind sensor")
print("Press CTRL+C to stop")
print()

try:
    while True:
        try:
            distance = sensor.distance * 100
            print(f"Distance: {distance:.1f} cm")
        except Exception as e:
            print("ERROR:", e)

        sleep(0.5)

except KeyboardInterrupt:
    print("\nStopped.")

finally:
    sensor.close()
