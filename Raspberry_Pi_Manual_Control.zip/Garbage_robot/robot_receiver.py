from http.server import HTTPServer, BaseHTTPRequestHandler
import json

class RobotReceiver(BaseHTTPRequestHandler):

    def do_POST(self):

        if self.path != "/command":
            self.send_response(404)
            self.end_headers()
            return

        try:
            content_length = int(
                self.headers.get("Content-Length", 0)
            )

            body = self.rfile.read(content_length)
            data = json.loads(body)

            command = data.get("command")

            print()
            print("==============================")
            print("COMMAND RECEIVED:", command)
            print("==============================")
            print()

            response = json.dumps({
                "status": "received",
                "command": command
            }).encode("utf-8")

            self.send_response(200)
            self.send_header(
                "Content-Type",
                "application/json"
            )
            self.send_header(
                "Content-Length",
                str(len(response))
            )
            self.end_headers()

            self.wfile.write(response)

        except Exception as error:
            print("ERROR:", error)

            response = json.dumps({
                "status": "error",
                "error": str(error)
            }).encode("utf-8")

            self.send_response(500)
            self.send_header(
                "Content-Type",
                "application/json"
            )
            self.send_header(
                "Content-Length",
                str(len(response))
            )
            self.end_headers()

            self.wfile.write(response)


PORT = 9000

server = HTTPServer(
    ("0.0.0.0", PORT),
    RobotReceiver
)

print()
print("==============================")
print("   GARBAGE ROBOT RECEIVER")
print("==============================")
print()
print("Listening on port:", PORT)
print("Waiting for Windows commands...")
print()

server.serve_forever()
