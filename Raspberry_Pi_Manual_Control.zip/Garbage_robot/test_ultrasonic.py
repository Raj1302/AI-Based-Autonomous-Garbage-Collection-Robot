from gpiozero import DistanceSensor
from time import sleep

# =========================================================
# GC BOT - ULTRASONIC TEST
# =========================================================

# Front HC-SR04
front_sensor = DistanceSensor(
    echo=25,
    trigger=9,
    max_distance=4
)

# Rear HC-SR04
rear_sensor = DistanceSensor(
    echo=12,
    trigger=16,
    max_distance=4
)

print("=" * 50)
print("       GC BOT ULTRASONIC SENSOR TEST")
print("=" * 50)
print("Front: TRIG GPIO 9  | ECHO GPIO 25")
print("Rear : TRIG GPIO 16 | ECHO GPIO 12")
print("Press CTRL+C to stop")
print("=" * 50)

try:
    while True:

        front_cm = front_sensor.distance * 100
        rear_cm = rear_sensor.distance * 100

        # Limit readings to HC-SR04 practical range
        if front_cm > 400:
            front_cm = 400

        if rear_cm > 400:
            rear_cm = 400

        print(
            f"Front: {front_cm:6.1f} cm   |   "
            f"Rear: {rear_cm:6.1f} cm"
        )

        sleep(0.2)

except KeyboardInterrupt:
    print("\nStopping ultrasonic test...")

finally:
    front_sensor.close()
    rear_sensor.close()
    print("Test finished.")
