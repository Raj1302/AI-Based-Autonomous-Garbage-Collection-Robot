
import time
import RPi.GPIO as GPIO

# ==========================================
# MOTOR DIRECTION PINS (BCM numbering)
# ==========================================

LEFT_IN1 = 17
LEFT_IN2 = 27
LEFT_IN3 = 24
LEFT_IN4 = 10

RIGHT_IN1 = 5
RIGHT_IN2 = 6
RIGHT_IN3 = 13
RIGHT_IN4 = 26

# ==========================================
# L298N ENABLE PINS (ENA / ENB)
# ==========================================

# L298N #1
LEFT_ENA = 18
LEFT_ENB = 19

# L298N #2
RIGHT_ENA = 20
RIGHT_ENB = 21

# ==========================================
# GPIO SETUP
# ==========================================

DIRECTION_PINS = [
    LEFT_IN1, LEFT_IN2, LEFT_IN3, LEFT_IN4,
    RIGHT_IN1, RIGHT_IN2, RIGHT_IN3, RIGHT_IN4
]

ENABLE_PINS = [LEFT_ENA, LEFT_ENB, RIGHT_ENA, RIGHT_ENB]

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

for pin in DIRECTION_PINS:
    GPIO.setup(pin, GPIO.OUT, initial=GPIO.LOW)

for pin in ENABLE_PINS:
    GPIO.setup(pin, GPIO.OUT, initial=GPIO.LOW)

# PWM frequency: 1 kHz
pwm_left_a = GPIO.PWM(LEFT_ENA, 1000)
pwm_left_b = GPIO.PWM(LEFT_ENB, 1000)
pwm_right_a = GPIO.PWM(RIGHT_ENA, 1000)
pwm_right_b = GPIO.PWM(RIGHT_ENB, 1000)

for pwm in (pwm_left_a, pwm_left_b, pwm_right_a, pwm_right_b):
    pwm.start(0)

# Speed: 0-100%
SPEED = 40


def set_speed(speed=SPEED):
    speed = max(0, min(100, int(speed)))
    for pwm in (pwm_left_a, pwm_left_b, pwm_right_a, pwm_right_b):
        pwm.ChangeDutyCycle(speed)


def stop():
    set_speed(0)

    for pin in DIRECTION_PINS:
        GPIO.output(pin, GPIO.LOW)

    print("MOTORS: STOP")


def forward():
    stop()

    GPIO.output(LEFT_IN1, GPIO.HIGH)
    GPIO.output(LEFT_IN2, GPIO.LOW)
    GPIO.output(LEFT_IN3, GPIO.HIGH)
    GPIO.output(LEFT_IN4, GPIO.LOW)

    GPIO.output(RIGHT_IN1, GPIO.HIGH)
    GPIO.output(RIGHT_IN2, GPIO.LOW)
    GPIO.output(RIGHT_IN3, GPIO.HIGH)
    GPIO.output(RIGHT_IN4, GPIO.LOW)

    set_speed(SPEED)
    print("MOTORS: FORWARD")


def backward():
    stop()

    GPIO.output(LEFT_IN1, GPIO.LOW)
    GPIO.output(LEFT_IN2, GPIO.HIGH)
    GPIO.output(LEFT_IN3, GPIO.LOW)
    GPIO.output(LEFT_IN4, GPIO.HIGH)

    GPIO.output(RIGHT_IN1, GPIO.LOW)
    GPIO.output(RIGHT_IN2, GPIO.HIGH)
    GPIO.output(RIGHT_IN3, GPIO.LOW)
    GPIO.output(RIGHT_IN4, GPIO.HIGH)

    set_speed(SPEED)
    print("MOTORS: BACKWARD")


def left():
    stop()

    GPIO.output(LEFT_IN1, GPIO.LOW)
    GPIO.output(LEFT_IN2, GPIO.HIGH)
    GPIO.output(LEFT_IN3, GPIO.LOW)
    GPIO.output(LEFT_IN4, GPIO.HIGH)

    GPIO.output(RIGHT_IN1, GPIO.HIGH)
    GPIO.output(RIGHT_IN2, GPIO.LOW)
    GPIO.output(RIGHT_IN3, GPIO.HIGH)
    GPIO.output(RIGHT_IN4, GPIO.LOW)

    set_speed(SPEED)
    print("MOTORS: LEFT")


def right():
    stop()

    GPIO.output(LEFT_IN1, GPIO.HIGH)
    GPIO.output(LEFT_IN2, GPIO.LOW)
    GPIO.output(LEFT_IN3, GPIO.HIGH)
    GPIO.output(LEFT_IN4, GPIO.LOW)

    GPIO.output(RIGHT_IN1, GPIO.LOW)
    GPIO.output(RIGHT_IN2, GPIO.HIGH)
    GPIO.output(RIGHT_IN3, GPIO.LOW)
    GPIO.output(RIGHT_IN4, GPIO.HIGH)

    set_speed(SPEED)
    print("MOTORS: RIGHT")


def rear_left():
    stop()

    GPIO.output(LEFT_IN1, GPIO.LOW)
    GPIO.output(LEFT_IN2, GPIO.HIGH)
    GPIO.output(LEFT_IN3, GPIO.LOW)
    GPIO.output(LEFT_IN4, GPIO.HIGH)

    set_speed(SPEED)
    print("MOTORS: REAR LEFT")


def rear_right():
    stop()

    GPIO.output(RIGHT_IN1, GPIO.LOW)
    GPIO.output(RIGHT_IN2, GPIO.HIGH)
    GPIO.output(RIGHT_IN3, GPIO.LOW)
    GPIO.output(RIGHT_IN4, GPIO.HIGH)

    set_speed(SPEED)
    print("MOTORS: REAR RIGHT")


def handle_command(command):
    command = command.strip().lower()

    commands = {
        "forward": forward,
        "backward": backward,
        "left": left,
        "right": right,
        "rear_left": rear_left,
        "rear_right": rear_right,
        "stop": stop,
    }

    action = commands.get(command)

    if action:
        action()
    else:
        print("Unknown command:", command)


try:
    print("====================================")
    print(" ROBOT MOTOR CONTROLLER")
    print("====================================")
    print("Commands: forward, backward, left, right")
    print("          rear_left, rear_right, stop")
    print("Press Ctrl+C to exit.")
    print("====================================")

    stop()

    while True:
        command = input("> ")
        handle_command(command)

except KeyboardInterrupt:
    print("\nStopping robot...")

finally:
    stop()

    for pwm in (pwm_left_a, pwm_left_b, pwm_right_a, pwm_right_b):
        pwm.stop()

    GPIO.cleanup()
    print("GPIO CLEANUP COMPLETE")
