from flask import Flask, request, jsonify, send_from_directory, Response
from gpiozero import OutputDevice, PWMOutputDevice, DistanceSensor
import atexit
from adafruit_servokit import ServoKit
import cv2


# =========================================================
# FLASK
# =========================================================

app = Flask(__name__, static_folder=".")


# =========================================================
# PCA9685 SERVO SETUP
# =========================================================

kit = ServoKit(channels=16, address=0x40)
kit.frequency = 50

SERVO_CHANNELS = {
    "base": 0,
    "shoulder": 1,
    "elbow": 2,
    "wrist": 3,
    "wristRotation": 4,
    "gripper": 5
}

# MG995 / MG90S pulse range
for channel in SERVO_CHANNELS.values():
    kit.servo[channel].set_pulse_width_range(500, 2500)


# =========================================================
# CAMERA
# =========================================================

camera = cv2.VideoCapture(
    "/dev/video0",
    cv2.CAP_V4L2
)

camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
camera.set(cv2.CAP_PROP_FPS, 30)


# =========================================================
# HARDWARE
# =========================================================

HARDWARE_ENABLED = True


# =========================================================
# MOTOR GPIO - L298N #1
# LEFT SIDE
# =========================================================

FL_IN1 = 17
FL_IN2 = 27

RL_IN1 = 24
RL_IN2 = 10


# =========================================================
# MOTOR GPIO - L298N #2
# RIGHT SIDE
# =========================================================

FR_IN1 = 5
FR_IN2 = 6

RR_IN1 = 13
RR_IN2 = 26


# =========================================================
# L298N ENABLE / PWM GPIO
# =========================================================

# L298N #1
L298N1_ENA = 18
L298N1_ENB = 19

# L298N #2
L298N2_ENA = 20
L298N2_ENB = 21


# =========================================================
# MOTOR SPEED
# =========================================================

# 1.0 = 100%
MOTOR_SPEED = 1.0


# =========================================================
# MOTOR DIRECTION OUTPUTS
# =========================================================

fl1 = OutputDevice(FL_IN1, initial_value=False)
fl2 = OutputDevice(FL_IN2, initial_value=False)

rl1 = OutputDevice(RL_IN1, initial_value=False)
rl2 = OutputDevice(RL_IN2, initial_value=False)

fr1 = OutputDevice(FR_IN1, initial_value=False)
fr2 = OutputDevice(FR_IN2, initial_value=False)

rr1 = OutputDevice(RR_IN1, initial_value=False)
rr2 = OutputDevice(RR_IN2, initial_value=False)


# =========================================================
# L298N ENABLE PWM OUTPUTS
# =========================================================

ena1 = PWMOutputDevice(
    L298N1_ENA,
    frequency=1000,
    initial_value=0
)

enb1 = PWMOutputDevice(
    L298N1_ENB,
    frequency=1000,
    initial_value=0
)

ena2 = PWMOutputDevice(
    L298N2_ENA,
    frequency=1000,
    initial_value=0
)

enb2 = PWMOutputDevice(
    L298N2_ENB,
    frequency=1000,
    initial_value=0
)


# =========================================================
# ENABLE / DISABLE MOTORS
# =========================================================

def enable_all_motors():

    ena1.value = MOTOR_SPEED
    enb1.value = MOTOR_SPEED

    ena2.value = MOTOR_SPEED
    enb2.value = MOTOR_SPEED


def disable_all_motors():

    ena1.value = 0
    enb1.value = 0

    ena2.value = 0
    enb2.value = 0


# =========================================================
# ULTRASONIC SENSORS
# =========================================================

front_sensor = DistanceSensor(
    echo=25,
    trigger=9,
    max_distance=4
)

rear_sensor = DistanceSensor(
    echo=12,
    trigger=16,
    max_distance=4
)


# =========================================================
# ROBOT STATE
# =========================================================

robot_state = {

    "drive": "stop",

    "emergency": False,

    "speed": 100,

    "servos": {

        "base": 90,
        "shoulder": 90,
        "elbow": 90,
        "wrist": 90,
        "wristRotation": 90,
        "gripper": 90
    },

    "frontDistance": None,
    "rearDistance": None
}


# =========================================================
# LOW LEVEL MOTOR FUNCTIONS
# =========================================================

def motor_forward(a, b):

    a.on()
    b.off()


def motor_backward(a, b):

    a.off()
    b.on()


def motor_stop(a, b):

    a.off()
    b.off()


def all_motors_stop():

    motor_stop(fl1, fl2)
    motor_stop(rl1, rl2)
    motor_stop(fr1, fr2)
    motor_stop(rr1, rr2)

    disable_all_motors()


# =========================================================
# DRIVE CONTROL
# =========================================================

def drive_robot(direction):

    if not HARDWARE_ENABLED:

        print("Hardware disabled")
        return


    # =====================================================
    # EMERGENCY PROTECTION
    # =====================================================

    if robot_state["emergency"] and direction != "stop":

        print("EMERGENCY STOP ACTIVE")

        all_motors_stop()

        robot_state["drive"] = "stop"

        return


    # =====================================================
    # STOP
    # =====================================================

    if direction == "stop":

        all_motors_stop()


    # =====================================================
    # FORWARD
    # =====================================================

    elif direction == "forward":

        enable_all_motors()

        # LEFT SIDE
        motor_forward(fl1, fl2)
        motor_forward(rl1, rl2)

        # RIGHT SIDE
        # Reversed because of wheel orientation
        motor_backward(fr1, fr2)
        motor_backward(rr1, rr2)


    # =====================================================
    # BACKWARD
    # =====================================================

    elif direction == "backward":

        enable_all_motors()

        # LEFT SIDE
        motor_backward(fl1, fl2)
        motor_backward(rl1, rl2)

        # RIGHT SIDE
        motor_forward(fr1, fr2)
        motor_forward(rr1, rr2)


    # =====================================================
    # STRAFE LEFT
    # =====================================================

    elif direction == "left":

        enable_all_motors()

        motor_backward(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_forward(rr1, rr2)


    # =====================================================
    # STRAFE RIGHT
    # =====================================================

    elif direction == "right":

        enable_all_motors()

        motor_forward(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_backward(rr1, rr2)


    # =====================================================
    # ROTATE LEFT
    # =====================================================

    elif direction == "rotate_left":

        enable_all_motors()

        motor_backward(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_backward(rr1, rr2)


    # =====================================================
    # ROTATE RIGHT
    # =====================================================

    elif direction == "rotate_right":

        enable_all_motors()

        motor_forward(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_forward(rr1, rr2)


    # =====================================================
    # DIAGONAL FORWARD LEFT
    # =====================================================

    elif direction == "forward_left":

        enable_all_motors()

        motor_stop(fl1, fl2)
        motor_forward(rl1, rl2)

        motor_backward(fr1, fr2)
        motor_stop(rr1, rr2)


    # =====================================================
    # DIAGONAL FORWARD RIGHT
    # =====================================================

    elif direction == "forward_right":

        enable_all_motors()

        motor_forward(fl1, fl2)
        motor_stop(rl1, rl2)

        motor_stop(fr1, fr2)
        motor_backward(rr1, rr2)


    # =====================================================
    # DIAGONAL BACKWARD LEFT
    # =====================================================

    elif direction == "backward_left":

        enable_all_motors()

        motor_backward(fl1, fl2)
        motor_stop(rl1, rl2)

        motor_stop(fr1, fr2)
        motor_forward(rr1, rr2)


    # =====================================================
    # DIAGONAL BACKWARD RIGHT
    # =====================================================

    elif direction == "backward_right":

        enable_all_motors()

        motor_stop(fl1, fl2)
        motor_backward(rl1, rl2)

        motor_forward(fr1, fr2)
        motor_stop(rr1, rr2)


    # =====================================================
    # UNKNOWN COMMAND
    # =====================================================

    else:

        all_motors_stop()

        direction = "stop"


    robot_state["drive"] = direction

    print("DRIVE COMMAND:", direction)


# =========================================================
# SPEED CONTROL
# =========================================================

def set_motor_speed(speed):

    global MOTOR_SPEED

    try:
        speed = float(speed)

    except (TypeError, ValueError):

        return False

    # Limit speed between 0% and 100%
    speed = max(0.0, min(100.0, speed))

    # Convert percentage to PWM value
    MOTOR_SPEED = speed / 100.0

    # Save speed as percentage
    robot_state["speed"] = int(speed)

    # Apply new speed immediately if robot is moving
    if (
        robot_state["drive"] != "stop"
        and not robot_state["emergency"]
    ):

        ena1.value = MOTOR_SPEED
        enb1.value = MOTOR_SPEED

        ena2.value = MOTOR_SPEED
        enb2.value = MOTOR_SPEED

    print(
        f"MOTOR SPEED: {int(speed)}%"
    )

    return True


# =========================================================
# SERVO CONTROL
# =========================================================

def set_servo(name, angle):

    if name not in SERVO_CHANNELS:
        return False

    try:
        angle = int(angle)

    except (TypeError, ValueError):

        return False

    angle = max(0, min(180, angle))

    channel = SERVO_CHANNELS[name]

    kit.servo[channel].angle = angle

    robot_state["servos"][name] = angle

    print(
        f"SERVO {name}: {angle} degrees"
    )

    return True


# =========================================================
# ARM PRESETS
# =========================================================

def arm_preset(preset):

    presets = {

        "home": {
            "base": 90,
            "shoulder": 90,
            "elbow": 90,
            "wrist": 90,
            "wristRotation": 90,
            "gripper": 90
        },

        "grab": {
            "base": 90,
            "shoulder": 120,
            "elbow": 60,
            "wrist": 80,
            "wristRotation": 90,
            "gripper": 30
        },

        "release": {
            "base": 90,
            "shoulder": 100,
            "elbow": 80,
            "wrist": 90,
            "wristRotation": 90,
            "gripper": 120
        }
    }

    if preset not in presets:
        return False

    print(
        "ARM PRESET:",
        preset
    )

    for servo, angle in presets[preset].items():

        set_servo(
            servo,
            angle
        )

    return True


# =========================================================
# CAMERA STREAM
# =========================================================

def generate_frames():

    while True:

        success, frame = camera.read()

        if not success:
            continue

        ret, buffer = cv2.imencode(
            ".jpg",
            frame
        )

        if not ret:
            continue

        frame = buffer.tobytes()

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + frame
            + b"\r\n"
        )


# =========================================================
# WEB PAGE
# =========================================================

@app.route("/")
def index():

    return send_from_directory(
        ".",
        "index.html"
    )


@app.route("/style.css")
def style():

    return send_from_directory(
        ".",
        "style.css"
    )


@app.route("/script.js")
def script():

    return send_from_directory(
        ".",
        "script.js"
    )


@app.route("/video_feed")
def video_feed():

    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )


# =========================================================
# DRIVE API
# =========================================================

@app.route(
    "/api/drive",
    methods=["POST"]
)
def api_drive():

    data = request.get_json(
        silent=True
    ) or {}

    direction = data.get(
        "direction",
        "stop"
    )

    allowed = [

        "forward",
        "backward",
        "left",
        "right",
        "rotate_left",
        "rotate_right",
        "forward_left",
        "forward_right",
        "backward_left",
        "backward_right",
        "stop"
    ]

    if direction not in allowed:

        return jsonify({

            "success": False,

            "error": "Invalid drive command"

        }), 400

    drive_robot(direction)

    return jsonify({

        "success": True,

        "direction": robot_state["drive"],

        "emergency": robot_state["emergency"],

        "speed": robot_state["speed"]

    })


# =========================================================
# SPEED API
# =========================================================

@app.route(
    "/api/speed",
    methods=["POST"]
)
def api_speed():

    data = request.get_json(
        silent=True
    ) or {}

    speed = data.get("speed")

    if speed is None:

        return jsonify({

            "success": False,

            "error": "Speed required"

        }), 400

    if not set_motor_speed(speed):

        return jsonify({

            "success": False,

            "error": "Invalid speed"

        }), 400

    return jsonify({

        "success": True,

        "speed": robot_state["speed"]

    })


# =========================================================
# SERVO API
# =========================================================

@app.route(
    "/api/servo",
    methods=["POST"]
)
def api_servo():

    data = request.get_json(
        silent=True
    ) or {}

    name = data.get("name")
    angle = data.get("angle")

    if name is None or angle is None:

        return jsonify({

            "success": False,

            "error": "Servo name and angle required"

        }), 400

    try:
        angle = int(angle)

    except (
        TypeError,
        ValueError
    ):

        return jsonify({

            "success": False,

            "error": "Invalid angle"

        }), 400

    if not set_servo(
        name,
        angle
    ):

        return jsonify({

            "success": False,

            "error": "Unknown servo"

        }), 400

    return jsonify({

        "success": True,

        "servo": name,

        "angle": angle

    })


# =========================================================
# ARM PRESET API
# =========================================================

@app.route(
    "/api/arm-preset",
    methods=["POST"]
)
def api_arm_preset():

    data = request.get_json(
        silent=True
    ) or {}

    preset = data.get("preset")

    if not arm_preset(preset):

        return jsonify({

            "success": False,

            "error": "Unknown preset"

        }), 400

    return jsonify({

        "success": True,

        "preset": preset,

        "servos": robot_state["servos"]

    })


# =========================================================
# EMERGENCY STOP
# =========================================================

@app.route(
    "/api/emergency",
    methods=["POST"]
)
def api_emergency():

    robot_state["emergency"] = True

    all_motors_stop()

    robot_state["drive"] = "stop"

    print("")
    print("================================")
    print("        EMERGENCY STOP")
    print("================================")
    print("")

    return jsonify({

        "success": True,

        "emergency": True

    })


# =========================================================
# RESET EMERGENCY
# =========================================================

@app.route(
    "/api/emergency/reset",
    methods=["POST"]
)
def reset_emergency():

    robot_state["emergency"] = False

    print(
        "Emergency stop reset"
    )

    return jsonify({

        "success": True,

        "emergency": False

    })


# =========================================================
# ULTRASONIC DISTANCE
# =========================================================

def get_distance_cm(sensor):

    try:

        distance = sensor.distance * 100

        if distance < 2:
            return None

        if distance > 400:
            return None

        return round(
            distance,
            1
        )

    except Exception:

        return None


# =========================================================
# STATUS API
# =========================================================

@app.route(
    "/api/status",
    methods=["GET"]
)
def status():

    front = get_distance_cm(
        front_sensor
    )

    rear = get_distance_cm(
        rear_sensor
    )

    robot_state["frontDistance"] = front
    robot_state["rearDistance"] = rear

    return jsonify(
        robot_state
    )


# =========================================================
# CLEANUP
# =========================================================

def cleanup():

    print(
        "Stopping motors..."
    )

    try:
        all_motors_stop()

    except Exception:
        pass

    try:
        front_sensor.close()
        rear_sensor.close()

    except Exception:
        pass

    try:

        fl1.close()
        fl2.close()

        rl1.close()
        rl2.close()

        fr1.close()
        fr2.close()

        rr1.close()
        rr2.close()

    except Exception:
        pass

    try:

        ena1.close()
        enb1.close()

        ena2.close()
        enb2.close()

    except Exception:
        pass

    try:
        camera.release()

    except Exception:
        pass


atexit.register(cleanup)


# =========================================================
# START SERVER
# =========================================================

if __name__ == "__main__":

    # Make absolutely sure motors start stopped.
    all_motors_stop()

    print("")
    print("======================================")
    print("       GARBAGE ROBOT SERVER")
    print("======================================")
    print("")

    print(
        "Hardware enabled:",
        HARDWARE_ENABLED
    )

    print("")

    print("MOTOR CONFIGURATION:")
    print("")

    print("L298N #1 - LEFT")
    print("Front Left  = GPIO17, GPIO27")
    print("Rear Left   = GPIO24, GPIO10")

    print("")

    print("L298N #2 - RIGHT")
    print("Front Right = GPIO5, GPIO6")
    print("Rear Right  = GPIO13, GPIO26")

    print("")

    print("ENA / ENB PWM:")
    print("L298N #1 ENA = GPIO18 (Pin 12)")
    print("L298N #1 ENB = GPIO19 (Pin 35)")
    print("L298N #2 ENA = GPIO20 (Pin 38)")
    print("L298N #2 ENB = GPIO21 (Pin 40)")
    print("Software speed control = ENABLED")
    print("Motor speed = 100%")

    print("")

    print("IMPORTANT:")
    print("Remove all four physical ENA/ENB jumpers.")
    print("")

    print("Front ultrasonic:")
    print("TRIG GPIO9 / ECHO GPIO25")

    print("Rear ultrasonic:")
    print("TRIG GPIO16 / ECHO GPIO12")

    print("")

    print("PCA9685:")
    print("I2C address = 0x40")
    print("Servo channels = CH0-CH5")

    print("")

    print("Open on phone:")
    print("Use your Raspberry Pi current IP + :5000")
    print("Current example: http://10.100.52.185:5000")

    print("")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False
    )