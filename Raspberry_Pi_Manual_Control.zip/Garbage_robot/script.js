
async function sendCommand(url, data) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        console.log(result);

    } catch (error) {
        console.error("Robot connection error:", error);
    }
}


// DRIVE
function drive(direction) {
    console.log("Drive:", direction);

    sendCommand("/api/drive", {
        direction: direction
    });
}


// SERVO
function updateServo(name, value) {

    const display = document.getElementById(name + "Value");

    if (display) {
        display.textContent = value + "°";
    }

    sendCommand("/api/servo", {
        name: name,
        angle: value
    });
}


// ARM PRESETS
function armPreset(preset) {

    console.log("Arm preset:", preset);

    sendCommand("/api/arm-preset", {
        preset: preset
    });
}


// EMERGENCY STOP
function emergencyStop() {

    console.log("EMERGENCY STOP!");

    sendCommand("/api/emergency", {});

    alert("🛑 EMERGENCY STOP");
}



// ULTRASONIC DISTANCE
async function updateDistances() {
    try {
        const response = await fetch("/api/status");
        const data = await response.json();

        const front = document.getElementById("frontDistance");
        const rear = document.getElementById("rearDistance");

        if (front) {
            front.textContent =
                data.frontDistance !== null
                    ? data.frontDistance + " cm"
                    : "-- cm";
        }

        if (rear) {
            rear.textContent =
                data.rearDistance !== null
                    ? data.rearDistance + " cm"
                    : "-- cm";
        }

    } catch (error) {
        console.error("Sensor error:", error);
    }
}

setInterval(updateDistances, 1000);
updateDistances();


// PRESS AND HOLD DRIVE

function startDrive(direction) {
    console.log("Drive:", direction);

    sendCommand("/api/drive", {
        direction: direction
    });
}

function stopDrive() {
    console.log("Drive: stop");

    sendCommand("/api/drive", {
        direction: "stop"
    });
}

