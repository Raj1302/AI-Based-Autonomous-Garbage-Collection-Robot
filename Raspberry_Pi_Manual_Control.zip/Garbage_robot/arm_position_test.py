from adafruit_servokit import ServoKit
import time

# ==========================================
# PCA9685 SETUP
# ==========================================

kit = ServoKit(channels=16, address=0x40)
kit.frequency = 50


# ==========================================
# SERVO CHANNELS
# ==========================================

BASE = 0
SHOULDER = 1
ELBOW = 2
WRIST = 3
WRIST_ROTATION = 4
GRIPPER = 5


# ==========================================
# SERVO PULSE RANGE
# ==========================================

for ch in [
    BASE,
    SHOULDER,
    ELBOW,
    WRIST,
    WRIST_ROTATION,
    GRIPPER
]:
    kit.servo[ch].set_pulse_width_range(500, 2500)


# ==========================================
# SLOW SERVO MOVEMENT
# ==========================================

def slow_move(channel, start_angle, end_angle, step=1, delay=0.06):

    if start_angle < end_angle:
        angles = range(start_angle, end_angle + 1, step)
    else:
        angles = range(start_angle, end_angle - 1, -step)

    for angle in angles:
        kit.servo[channel].angle = angle
        time.sleep(delay)


# ==========================================
# DIRECT POSITION
# ==========================================

def set_position(channel, angle):
    kit.servo[channel].angle = angle


# ==========================================
# MAIN TEST
# ==========================================

try:

    # ======================================
    # INITIAL POSITION
    # ======================================

    print("\n========================================")
    print("INITIAL POSITION")
    print("========================================")

    print("Base            -> 0°")
    set_position(BASE, 0)

    print("Shoulder        -> 90°")
    set_position(SHOULDER, 90)

    print("Elbow           -> 90°")
    set_position(ELBOW, 90)

    print("Wrist           -> 90°")
    set_position(WRIST, 90)

    print("Wrist Rotation  -> 90°")
    set_position(WRIST_ROTATION, 90)

    print("Gripper         -> 170°")
    set_position(GRIPPER, 170)

    time.sleep(3)


    # ======================================
    # PICK-UP SEQUENCE
    # SHOULDER -> GRIPPER
    # ======================================

    input("\nPress ENTER to start PICK-UP sequence...")

    print("\n========================================")
    print("PICK-UP SEQUENCE")
    print("========================================")


    # 1. Shoulder
    print("\n1. Shoulder: 90° -> 40°")

    slow_move(
        SHOULDER,
        90,
        50,
        step=1,
        delay=0.02
    )

    time.sleep(1)


    # 2. Gripper
    print("\n2. Gripper: 170° -> 50°")

    slow_move(
        GRIPPER,
        170,
        50,
        step=1,
        delay=0.02
    )

    print("\nPick-up position reached.")

    time.sleep(3)


    # ======================================
    # AFTER PICK-UP SEQUENCE
    #
    # SHOULDER -> BASE -> ELBOW -> GRIPPER
    # ======================================

    input("\nPress ENTER to start AFTER PICK-UP sequence...")

    print("\n========================================")
    print("AFTER PICK-UP SEQUENCE")
    print("========================================")


    # 1. Shoulder
    print("\n1. Shoulder: 40° -> 144°")

    slow_move(
        SHOULDER,
        40,
        144,
        step=1,
        delay=0.02
    )

    time.sleep(1)


    # 2. Base
    # IMPORTANT:
    # Base moves from 0° -> 180°
    print("\n2. Base: 0° -> 180°")

    slow_move(
        BASE,
        0,
        180,
        step=1,
        delay=0.02
    )

    time.sleep(1)


    # 3. Elbow
    print("\n3. Elbow: 90° -> 170°")

    slow_move(
        ELBOW,
        90,
        170,
        step=1,
        delay=0.02
    )

    time.sleep(1)


    # 4. Gripper
    print("\n4. Gripper: 50° -> 175°")

    slow_move(
        GRIPPER,
        50,
        175,
        step=1,
        delay=0.02
    )


    # ======================================
    # FINAL POSITION
    # ======================================

    print("\n========================================")
    print("AFTER PICK-UP POSITION COMPLETED")
    print("========================================")

    print("Base            : 180°")
    print("Shoulder        : 144°")
    print("Elbow           : 170°")
    print("Wrist           : 90°")
    print("Wrist Rotation  : 90°")
    print("Gripper         : 175°")


    input("\nPress ENTER to release servo signals and exit...")


# ==========================================
# STOP WITH CTRL+C
# ==========================================

except KeyboardInterrupt:

    print("\nTest stopped by user.")


# ==========================================
# RELEASE SERVOS
# ==========================================

finally:

    for ch in [
        BASE,
        SHOULDER,
        ELBOW,
        WRIST,
        WRIST_ROTATION,
        GRIPPER
    ]:
        kit.servo[ch].angle = None

    print("Servo signals released.")
