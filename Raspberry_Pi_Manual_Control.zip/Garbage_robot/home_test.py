from adafruit_servokit import ServoKit
import time

# PCA9685
kit = ServoKit(channels=16, address=0x40)
kit.frequency = 50

# Servo channels
BASE = 0
SHOULDER = 1
ELBOW = 2
WRIST = 3
WRIST_ROTATION = 4
GRIPPER = 5

# GC-Bot HOME / INITIAL POSITION
HOME_POSITION = {
    BASE: 180,
    SHOULDER: 90,
    ELBOW: 90,
    WRIST: 90,
    WRIST_ROTATION: 90,
    GRIPPER: 30,
}

print("===================================")
print("       GC-Bot HOME POSITION TEST")
print("===================================")
print()
print("Moving arm to Home position...")
print()

# Move one servo at a time
for channel, angle in HOME_POSITION.items():
    print(f"Channel {channel}: {angle} degrees")
    kit.servo[channel].angle = angle
    time.sleep(0.7)

print()
print("===================================")
print("HOME POSITION SET")
print("===================================")
print()
print("Base            : 180 degrees")
print("Shoulder        : 90 degrees")
print("Elbow           : 90 degrees")
print("Wrist           : 90 degrees")
print("Wrist Rotation  : 90 degrees")
print("Gripper         : 30 degrees")
print()
print("Arm will remain at Home position.")
print("Press CTRL+C to stop.")
print()

try:
    while True:
        time.sleep(1)

except KeyboardInterrupt:
    print()
    print("Home test stopped.")
    print("Arm remains at its last commanded position.")
