GC BOT APP SCREENSHOTS

Screenshots of the Flutter Android application for the AI-Based Autonomous Garbage Collection Robot.

Files:
01_drive_control.jpg - Manual drive control screen
02_project_hub.jpg - Project hub screen
03_arm_control.jpg - Robotic arm control screen
04_choose_mode.png - Manual/autonomous mode selection screen
05_splash_screen.png - App splash screen

These are app screenshots for documentation. They are not the Flutter source code or APK.
