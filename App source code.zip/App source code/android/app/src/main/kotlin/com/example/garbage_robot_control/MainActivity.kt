package com.example.garbage_robot_control

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
