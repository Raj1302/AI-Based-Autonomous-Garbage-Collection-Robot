# Field / Ops — Garbage Collection Robot

Flutter starter app for the manual-control experience. The current screen is the **Drive** tab and includes a camera-feed placeholder, front/rear ultrasonic cards, eight directional controls, 360° turn controls, and an adjustable speed slider.

## Open in VS Code

1. Open this folder in VS Code.
2. Run `flutter pub get` in the terminal.
3. Start on a connected Flutter device or emulator with `flutter run`.

## Robot integration

The UI currently uses demo/offline states. Connect the camera stream and robot command/sensor transport (for example, your ROS 2 bridge or a WebSocket service) before using it to control hardware. The drive buttons currently provide pressed/command feedback only; they do not send motor commands.

The bottom navigation shows the planned **Drive**, **Arm**, and **Project hub** sections. Drive is implemented first; Arm and Project hub are visual placeholders for subsequent work.
