import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:mjpeg_view/mjpeg_view.dart';

void main() => runApp(const GarbageRobotApp());

const ink = Color(0xFF17241F);
const muted = Color(0xFF718078);
const green = Color(0xFF39745C);
const lime = Color(0xFFD9EF78);
const canvas = Color(0xFFF4F5F0);

class GarbageRobotApp extends StatelessWidget {
  const GarbageRobotApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GC Bot Control',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: canvas,
          colorScheme: ColorScheme.fromSeed(seedColor: green, surface: canvas),
          fontFamily: 'Roboto',
        ),
        home: const EntryScreen(),
      );
}

class EntryScreen extends StatefulWidget {
  const EntryScreen({super.key});

  @override
  State<EntryScreen> createState() => _EntryScreenState();
}

class _EntryScreenState extends State<EntryScreen> {
  int page = -1;
  HttpClient? robotClient;
  String? robotAddress;
  String? robotBaseUrl;
  int robotPort = 5000;

  @override
  void dispose() {
    robotClient?.close(force: true);
    super.dispose();
  }

  void _disconnectFromRobot() {
    robotClient?.close(force: true);
    setState(() {
      robotClient = null;
      robotAddress = null;
      robotBaseUrl = null;
    });
  }

  Future<void> _showConnectionDialog() async {
    final ipController =
        TextEditingController(text: robotAddress ?? '192.168.1.60');
    final portController = TextEditingController(text: '$robotPort');
    var connecting = false;
    String? error;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, updateDialog) => AlertDialog(
          backgroundColor: canvas,
          title: const Text('Connect GC Bot',
              style: TextStyle(color: ink, fontWeight: FontWeight.w800)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                  'Enter the Pi IP address. Your phone and Pi must share Wi-Fi.',
                  style: TextStyle(color: muted, fontSize: 12)),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: ipController,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'IP address or URL',
                hintText: '192.168.1.60 or http://192.168.1.60:5000',
                prefixIcon: Icon(Icons.router_rounded),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: portController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Web port',
                hintText: '5000',
                prefixIcon: Icon(Icons.settings_ethernet_rounded),
                border: OutlineInputBorder(),
              ),
            ),
            if (error != null) ...[
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(error!,
                    style: const TextStyle(
                        color: Color(0xFFB33A32), fontSize: 11)),
              ),
            ],
          ]),
          actions: [
            TextButton(
              onPressed: connecting ? null : () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: connecting
                  ? null
                  : () async {
                      final host = ipController.text.trim();
                      final port = int.tryParse(portController.text.trim());
                      if (host.isEmpty ||
                          port == null ||
                          port < 1 ||
                          port > 65535) {
                        updateDialog(
                            () => error = 'Enter a valid IP and port.');
                        return;
                      }

                      updateDialog(() {
                        connecting = true;
                        error = null;
                      });
                      final client = HttpClient()
                        ..connectionTimeout = const Duration(seconds: 5);
                      try {
                        final enteredUri = Uri.tryParse(host);
                        final uri = enteredUri != null && enteredUri.hasScheme
                            ? enteredUri
                            : Uri(scheme: 'http', host: host, port: port);
                        if (uri.scheme != 'http' || uri.host.isEmpty) {
                          throw const FormatException('Invalid address');
                        }
                        final request = await client.getUrl(uri);
                        final response = await request.close();
                        await response.drain<void>();
                        if (!mounted) {
                          client.close(force: true);
                          return;
                        }
                        robotClient?.close(force: true);
                        setState(() {
                          robotClient = client;
                          robotAddress = uri.host;
                          robotPort = uri.port;
                          robotBaseUrl = uri.origin;
                        });
                        if (dialogContext.mounted) {
                          Navigator.pop(dialogContext);
                        }
                      } catch (_) {
                        client.close(force: true);
                        updateDialog(() {
                          connecting = false;
                          error =
                              'Could not reach $host. Confirm it opens in Chrome and both devices share Wi-Fi.';
                        });
                      }
                    },
              style: FilledButton.styleFrom(backgroundColor: green),
              child: Text(connecting ? 'Connecting…' : 'Connect'),
            ),
          ],
        ),
      ),
    );
    ipController.dispose();
    portController.dispose();
  }

  void _connectionAction() {
    if (robotClient != null) {
      _disconnectFromRobot();
    } else {
      _showConnectionDialog();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (page == -1) {
      return _introScreen();
    }
    if (page == 1) {
      return ControlScreen(
        onBack: () => setState(() => page = 0),
        isConnected: robotClient != null,
        robotBaseUrl: robotBaseUrl,
        robotClient: robotClient,
        onConnectionAction: _connectionAction,
      );
    }
    if (page == 2) {
      return Scaffold(
        body: SafeArea(
          child: Column(children: [
            _entryHeader('AUTONOMOUS', onBack: () => setState(() => page = 0)),
            const Expanded(child: SizedBox.expand()),
          ]),
        ),
      );
    }
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _entryHeader('GC BOT', trailing: _connectionButton()),
              const Spacer(),
              const Text('ROBOT CONTROL',
                  style: TextStyle(
                      color: green,
                      fontSize: 10,
                      letterSpacing: 1.4,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Choose a mode.',
                  style: TextStyle(
                      color: ink,
                      fontSize: 30,
                      height: 1,
                      letterSpacing: -1,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Select how you want to operate GC Bot.',
                  style: TextStyle(color: muted, fontSize: 13)),
              const SizedBox(height: 24),
              _modeCard(
                icon: Icons.gamepad_rounded,
                title: 'Manual',
                description:
                    'Drive, control the arm, and view project details.',
                onTap: () => setState(() => page = 1),
              ),
              const SizedBox(height: 12),
              _modeCard(
                icon: Icons.auto_mode_rounded,
                title: 'Autonomous',
                description: 'Autonomous controls will be available here.',
                onTap: () => setState(() => page = 2),
              ),
              const Spacer(),
              const Center(
                child: Text('GC BOT  ·  COLLECTION ROBOT',
                    style: TextStyle(
                        color: muted,
                        fontSize: 9,
                        letterSpacing: 1,
                        fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _introScreen() => IntroScreen(
        onStart: () => setState(() => page = 0),
      );
  Widget _entryHeader(String title, {VoidCallback? onBack, Widget? trailing}) =>
      Padding(
        padding: const EdgeInsets.fromLTRB(22, 9, 18, 7),
        child: Row(children: [
          if (onBack != null) ...[
            IconButton(
                onPressed: onBack,
                tooltip: 'Back',
                icon: const Icon(Icons.arrow_back_rounded, color: ink)),
            const SizedBox(width: 2),
          ],
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
                color: ink, borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.recycling_rounded, color: lime, size: 21),
          ),
          const SizedBox(width: 10),
          Text(title,
              style: const TextStyle(
                  color: ink,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  fontSize: 13)),
          if (trailing != null) ...[
            const Spacer(),
            trailing,
          ],
        ]),
      );

  Widget _connectionButton() => OutlinedButton.icon(
        onPressed: _connectionAction,
        icon: Icon(
            robotClient == null ? Icons.link_rounded : Icons.link_off_rounded,
            size: 15),
        label: Text(robotClient == null ? 'Connect GC Bot' : 'Disconnect'),
        style: OutlinedButton.styleFrom(
          foregroundColor:
              robotClient == null ? green : const Color(0xFFB33A32),
          backgroundColor: Colors.white,
          side: BorderSide(
              color: robotClient == null
                  ? const Color(0xFFDCE6DC)
                  : const Color(0xFFE9D6D3)),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
          textStyle: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800),
        ),
      );

  Widget _modeCard({
    required IconData icon,
    required String title,
    required String description,
    required VoidCallback onTap,
  }) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFE5E9E3))),
          child: Row(children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                  color: const Color(0xFFF0F4EB),
                  borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: green, size: 23),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: ink,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    Text(description,
                        style: const TextStyle(color: muted, fontSize: 10)),
                  ]),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: muted, size: 15),
          ]),
        ),
      );
}

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key, required this.onStart});
  final VoidCallback onStart;

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  double get _seconds => _controller.value;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 9),
      lowerBound: 0,
      upperBound: 9,
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _replay() {
    _controller
      ..value = 0
      ..forward();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: canvas,
        body: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final t = _seconds;
            final ready = t >= 9;
            final reveal = _introSeg(t, 6, 6.7);
            final subtitle = _introSeg(t, 7.3, 8);
            final progress = _introSeg(t, 7.6, 9);
            return LayoutBuilder(builder: (context, bounds) {
              final width = bounds.maxWidth;
              return Stack(children: [
                Positioned.fill(
                  child: RepaintBoundary(
                    child: CustomPaint(painter: IntroPainter(t)),
                  ),
                ),
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(22, 14, 22, 18),
                    child: Column(children: [
                      Row(children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                              color: ink,
                              borderRadius: BorderRadius.circular(11),
                              border:
                                  Border.all(color: green.withOpacity(.28))),
                          child: const Icon(Icons.recycling_rounded,
                              color: lime, size: 20),
                        ),
                        const SizedBox(width: 10),
                        const Text('GC BOT',
                            style: TextStyle(
                                color: ink,
                                letterSpacing: 1.5,
                                fontSize: 12,
                                fontWeight: FontWeight.w800)),
                        const Spacer(),
                        TextButton.icon(
                          onPressed: _replay,
                          icon: const Icon(Icons.replay_rounded, size: 16),
                          label: const Text('REPLAY'),
                          style: TextButton.styleFrom(
                              foregroundColor: green,
                              textStyle: const TextStyle(
                                  fontSize: 9,
                                  letterSpacing: .8,
                                  fontWeight: FontWeight.w800)),
                        ),
                      ]),
                      const Spacer(flex: 6),
                      Opacity(
                        opacity: reveal,
                        child: Transform.translate(
                          offset: Offset(0, 14 * (1 - reveal)),
                          child: Column(children: [
                            RepaintBoundary(
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text('GARBAGE COLLECTION',
                                    style: TextStyle(
                                        color: ink,
                                        fontSize: width < 380 ? 18 : 21,
                                        letterSpacing: 2.3,
                                        fontWeight: FontWeight.w800,
                                        shadows: const [
                                          Shadow(
                                              color: Color(0x2239745C),
                                              blurRadius: 12)
                                        ])),
                              ),
                            ),
                            const SizedBox(height: 1),
                            Text('ROBOT',
                                style: TextStyle(
                                    color: green,
                                    fontSize: width < 380 ? 38 : 44,
                                    height: 1,
                                    letterSpacing: 8,
                                    fontWeight: FontWeight.w900,
                                    shadows: const [
                                      Shadow(
                                          color: Color(0x2239745C),
                                          blurRadius: 16)
                                    ])),
                            const SizedBox(height: 9),
                            Opacity(
                              opacity: subtitle,
                              child: const Text('AI POWERED  ·  AUTONOMOUS',
                                  style: TextStyle(
                                      color: muted,
                                      fontSize: 9,
                                      letterSpacing: 1.7,
                                      fontWeight: FontWeight.w700)),
                            ),
                          ]),
                        ),
                      ),
                      const Spacer(flex: 3),
                      if (t >= 7.4) ...[
                        Row(children: [
                          const Text('INITIALIZING SYSTEM',
                              style: TextStyle(
                                  color: muted,
                                  fontSize: 9,
                                  letterSpacing: 1.3,
                                  fontWeight: FontWeight.w700)),
                          const Spacer(),
                          Text('${(progress * 100).round()}%',
                              style: const TextStyle(
                                  color: Color(0xFF22D3EE),
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800)),
                        ]),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 3,
                            backgroundColor: const Color(0xFFE2E8DF),
                            valueColor: const AlwaysStoppedAnimation(green),
                          ),
                        ),
                        const SizedBox(height: 16),
                      ] else
                        const SizedBox(height: 37),
                      _RaisedStartButton(
                          enabled: ready, onPressed: widget.onStart),
                    ]),
                  ),
                ),
              ]);
            });
          },
        ),
      );
}

class _RaisedStartButton extends StatefulWidget {
  const _RaisedStartButton({required this.enabled, required this.onPressed});
  final bool enabled;
  final VoidCallback onPressed;

  @override
  State<_RaisedStartButton> createState() => _RaisedStartButtonState();
}

class _RaisedStartButtonState extends State<_RaisedStartButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTapDown:
            widget.enabled ? (_) => setState(() => _pressed = true) : null,
        onTapCancel: () => setState(() => _pressed = false),
        onTapUp: widget.enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onPressed();
              }
            : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          transform: Matrix4.translationValues(0, _pressed ? 4 : 0, 0),
          width: double.infinity,
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: widget.enabled
                  ? const [Color(0xFF4D8B6E), Color(0xFF2F624B)]
                  : const [Color(0xFFB6C1B8), Color(0xFF98A79D)],
            ),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: const Color(0xFF92B6A0), width: .8),
            boxShadow: _pressed
                ? const []
                : const [
                    BoxShadow(color: Color(0xFFCBD2C9), offset: Offset(0, 5)),
                    BoxShadow(
                        color: Color(0x2239745C),
                        blurRadius: 16,
                        spreadRadius: 1),
                  ],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(widget.enabled ? 'GET STARTED' : 'PREPARING GC BOT',
                style: TextStyle(
                    color: widget.enabled ? Colors.white : Colors.white70,
                    fontSize: 11,
                    letterSpacing: 1.5,
                    fontWeight: FontWeight.w900)),
            if (widget.enabled) ...[
              const SizedBox(width: 8),
              const Icon(Icons.arrow_forward_rounded, color: ink, size: 17),
            ],
          ]),
        ),
      );
}

class IntroPainter extends CustomPainter {
  IntroPainter(this.t);
  final double t;
  static const _cyan = Color(0xFF39745C);
  static const _green = Color(0xFF6F9B74);

  @override
  void paint(Canvas canvas, Size size) {
    final bounds = Offset.zero & size;
    canvas.drawRect(
      bounds,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF4F5F0), Color(0xFFEDF1E9), Color(0xFFE5EBE2)],
        ).createShader(bounds),
    );
    _drawParticles(canvas, size);
    final scale = math.min(size.width / 360, 1.15);
    final groundY = size.height * .54;
    _drawFloor(canvas, size, groundY);
    final drive = _ease(_introSeg(t, 0, 2.4));
    final carScale = (.48 + .52 * drive) * scale;
    final carX = size.width * (.30 + .18 * drive);
    final fade = _introSeg(t, 0, .6);

    canvas.save();
    canvas.translate(carX, groundY + (1 - drive) * 38 * scale);
    canvas.scale(carScale);
    if (fade < 1)
      canvas.saveLayer(null, Paint()..color = Colors.white.withOpacity(fade));
    _drawRobot(canvas, t);
    if (fade < 1) canvas.restore();
    canvas.restore();

    _drawRadar(canvas, carX, groundY, scale);
    _drawDetection(
        canvas, Offset(carX + 96 * scale, groundY - 9 * scale), scale);
    if (t > 5.9 && t < 6.8) {
      final y = size.height * _introSeg(t, 5.9, 6.8);
      canvas.drawLine(
          Offset(0, y),
          Offset(size.width, y),
          Paint()
            ..color = _cyan.withOpacity(.25)
            ..strokeWidth = 1.2);
    }
  }

  void _drawParticles(Canvas canvas, Size size) {
    for (var i = 0; i < 24; i++) {
      final x = ((i * 47.7) % size.width);
      final seedY = (i * 79.3) % size.height;
      final y = (seedY - t * (8 + (i % 4) * 3)) % size.height;
      final radius = 1 + (i % 3) * .35;
      canvas.drawCircle(Offset(x, y < 0 ? y + size.height : y), radius,
          Paint()..color = _cyan.withOpacity(.12 + (i % 4) * .035));
    }
  }

  void _drawFloor(Canvas canvas, Size size, double y) {
    final vanishing = Offset(size.width * .5, y - 18);
    final linePaint = Paint()
      ..color = _cyan.withOpacity(.09)
      ..strokeWidth = .7;
    for (var i = -7; i <= 7; i++) {
      canvas.drawLine(vanishing,
          Offset(size.width * .5 + i * size.width / 7, size.height), linePaint);
    }
    for (var i = 1; i <= 8; i++) {
      final p = math.pow(i / 8, 1.65).toDouble();
      final rowY = y + (size.height - y) * p;
      canvas.drawLine(Offset(0, rowY), Offset(size.width, rowY), linePaint);
    }
    canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        Paint()
          ..color = _cyan.withOpacity(.35)
          ..strokeWidth = 1.3);
  }

  void _drawRobot(Canvas canvas, double t) {
    final body = RRect.fromRectAndRadius(
        const Rect.fromLTRB(-61, -48, 63, -13), const Radius.circular(11));
    canvas.drawOval(const Rect.fromLTRB(-70, -6, 70, 5),
        Paint()..color = Colors.black.withOpacity(.45));
    canvas.drawRRect(body, Paint()..color = const Color(0xFF17241F));
    canvas.drawRRect(
        body,
        Paint()
          ..color = _cyan.withOpacity(.65)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTRB(-50, -42, 48, -37), const Radius.circular(2)),
        Paint()..color = _cyan.withOpacity(.85));

    final bin = RRect.fromRectAndRadius(
        const Rect.fromLTRB(-41, -72, -7, -47), const Radius.circular(4));
    final flash = t > 6.8 && t < 7.6 ? _introPulse(t, 6.8, 7.6) : 0.0;
    canvas.drawRRect(bin, Paint()..color = const Color(0xFF263A31));
    canvas.drawRRect(
        bin,
        Paint()
          ..color = (flash > .1 ? _green : _cyan).withOpacity(.72)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.3);
    canvas.drawLine(
        const Offset(-35, -65),
        const Offset(-13, -65),
        Paint()
          ..color = _cyan.withOpacity(.65)
          ..strokeWidth = 1);
    canvas.drawCircle(
        const Offset(-24, -76),
        3.4,
        Paint()
          ..color = (math.sin(t * 10).abs() > .45 && t > 2.2
              ? const Color(0xFFF5B642)
              : Colors.transparent));

    // Low-mounted UVC camera and front status lamp.
    canvas.drawCircle(
        const Offset(51, -39), 8, Paint()..color = const Color(0xFFDAEAF0));
    canvas.drawCircle(
        const Offset(52, -39), 4.1, Paint()..color = const Color(0xFF102031));
    canvas.drawCircle(const Offset(52, -39), 1.8, Paint()..color = _cyan);
    canvas.drawCircle(const Offset(59, -24), 2.2, Paint()..color = _green);

    for (final wheelX in const [-39.0, 39.0]) {
      canvas.drawCircle(
          Offset(wheelX, -10), 15, Paint()..color = const Color(0xFF202923));
      canvas.drawCircle(
          Offset(wheelX, -10), 10.5, Paint()..color = const Color(0xFF43564A));
      canvas.drawCircle(
          Offset(wheelX, -10),
          8.5,
          Paint()
            ..color = _cyan.withOpacity(.65)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2);
      canvas.save();
      canvas.translate(wheelX, -10);
      canvas.rotate(t * 5);
      for (var i = 0; i < 2; i++) {
        canvas.rotate(math.pi);
        canvas.drawLine(
            const Offset(0, -6),
            const Offset(0, 6),
            Paint()
              ..color = Colors.white54
              ..strokeWidth = 1);
      }
      canvas.restore();
    }

    // Lower to the litter, lift it, swing the base toward the bin, then dip in.
    final target = _armTarget(t);
    final base = const Offset(52, -44);
    final rotation = _armBaseRotation(t);
    final end = _drawArm(canvas, base, target, t, rotation);
    if (t < 4.55) {
      _drawBottle(canvas, const Offset(96, -3), t < 4.2 ? -.22 : 0, 1);
    } else if (t < 6.95) {
      final alpha = t > 6.65 ? 1 - _introSeg(t, 6.65, 6.95) : 1.0;
      final bottlePoint = t < 6.4
          ? Offset(end.dx, end.dy - 3)
          : Offset.lerp(
              end, const Offset(-24, -48), _ease(_introSeg(t, 6.4, 6.8)))!;
      _drawBottle(canvas, bottlePoint, 0, alpha);
    }

    // Headlight beam fades in as the rover reaches the collection area.
    final beam = _introSeg(t, 2.0, 2.6);
    if (beam > 0) {
      final path = Path()
        ..moveTo(57, -36)
        ..lineTo(137, -64)
        ..lineTo(137, -7)
        ..close();
      canvas.drawPath(path, Paint()..color = _cyan.withOpacity(.045 * beam));
    }
  }

  Offset _armTarget(double t) {
    const stowed = Offset(15, -35);
    const loweredToBottle = Offset(96, -3);
    const lifted = Offset(90, -36);
    const aboveBin = Offset(-25, -63);
    const insideBin = Offset(-24, -48);
    if (t < 3.4) return stowed;
    if (t < 4.15) {
      return Offset.lerp(
          stowed, loweredToBottle, _ease(_introSeg(t, 3.4, 4.15)))!;
    }
    if (t < 4.55) return loweredToBottle;
    if (t < 5.15) {
      return Offset.lerp(
          loweredToBottle, lifted, _ease(_introSeg(t, 4.55, 5.15)))!;
    }
    if (t < 6.05) {
      return Offset.lerp(lifted, aboveBin, _ease(_introSeg(t, 5.15, 6.05)))!;
    }
    if (t < 6.4) {
      return Offset.lerp(aboveBin, insideBin, _ease(_introSeg(t, 6.05, 6.4)))!;
    }
    if (t < 6.65) return insideBin;
    if (t < 7.8) {
      return Offset.lerp(insideBin, stowed, _ease(_introSeg(t, 6.65, 7.8)))!;
    }
    return stowed;
  }

  double _armBaseRotation(double t) {
    if (t < 5.15) return 0;
    if (t < 6.05) return 2.8 * _ease(_introSeg(t, 5.15, 6.05));
    if (t < 6.65) return 2.8;
    if (t < 7.8) return 2.8 * (1 - _ease(_introSeg(t, 6.65, 7.8)));
    return 0;
  }

  Offset _drawArm(
      Canvas canvas, Offset base, Offset target, double t, double rotation) {
    const l1 = 53.0, l2 = 38.0;
    // Solve the joints in the base's local frame while rotating the full arm.
    final worldDx = target.dx - base.dx;
    final worldDy = target.dy - base.dy;
    final rotCos = math.cos(rotation);
    final sine = math.sin(rotation);
    final dx = rotCos * worldDx + sine * worldDy;
    final localScreenDy = -sine * worldDx + rotCos * worldDy;
    final dy = -localScreenDy;
    final distance = math.sqrt(dx * dx + dy * dy).clamp(1.0, l1 + l2 - .1);
    final cosine = ((distance * distance - l1 * l1 - l2 * l2) / (2 * l1 * l2))
        .clamp(-1.0, 1.0);
    final elbow = math.acos(cosine);
    final shoulder = math.atan2(dy, dx) -
        math.atan2(l2 * math.sin(elbow), l1 + l2 * math.cos(elbow));
    const localBase = Offset.zero;
    final joint = Offset(l1 * math.cos(shoulder), -l1 * math.sin(shoulder));
    final localEnd = Offset(joint.dx + l2 * math.cos(shoulder + elbow),
        joint.dy - l2 * math.sin(shoulder + elbow));
    canvas.drawCircle(base, 11, Paint()..color = const Color(0xFF263A31));
    canvas.drawCircle(
        base,
        9,
        Paint()
          ..color = _cyan.withOpacity(.85)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5);
    canvas.save();
    canvas.translate(base.dx, base.dy);
    canvas.rotate(rotation);
    _armLink(canvas, localBase, joint, 11);
    _armLink(canvas, joint, localEnd, 9);
    for (final point in [localBase, joint, localEnd]) {
      canvas.drawCircle(point, 6, Paint()..color = const Color(0xFF193B50));
      canvas.drawCircle(
          point,
          4.5,
          Paint()
            ..color = _cyan.withOpacity(.9)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2);
      canvas.drawCircle(point, 1.8, Paint()..color = Colors.white70);
    }
    final gripOpen = t < 4.15 || (t >= 6.4 && t < 6.65);
    for (final side in [-1.0, 1.0]) {
      final finger =
          Offset(localEnd.dx + 8, localEnd.dy + side * (gripOpen ? 5 : 2));
      canvas.drawLine(
          localEnd,
          finger,
          Paint()
            ..color = _cyan
            ..strokeWidth = 2.3
            ..strokeCap = StrokeCap.round);
    }
    canvas.restore();
    return Offset(base.dx + rotCos * localEnd.dx - sine * localEnd.dy,
        base.dy + sine * localEnd.dx + rotCos * localEnd.dy);
  }

  void _armLink(Canvas canvas, Offset a, Offset b, double width) {
    canvas.drawLine(
        a,
        b,
        Paint()
          ..color = _cyan.withOpacity(.7)
          ..strokeWidth = width + 3
          ..strokeCap = StrokeCap.round);
    canvas.drawLine(
        a,
        b,
        Paint()
          ..color = const Color(0xFF17334A)
          ..strokeWidth = width
          ..strokeCap = StrokeCap.round);
    canvas.drawLine(
        a,
        b,
        Paint()
          ..color = Colors.white.withOpacity(.12)
          ..strokeWidth = 1
          ..strokeCap = StrokeCap.round);
  }

  void _drawBottle(
      Canvas canvas, Offset point, double rotation, double opacity) {
    canvas.save();
    canvas.translate(point.dx, point.dy);
    canvas.rotate(rotation);
    final body = RRect.fromRectAndRadius(
        const Rect.fromLTRB(-4, -17, 4, 2), const Radius.circular(2.5));
    canvas.drawRRect(
        body, Paint()..color = const Color(0xFF91B7A9).withOpacity(opacity));
    canvas.drawRect(const Rect.fromLTRB(-2, -22, 2, -17),
        Paint()..color = Colors.white.withOpacity(opacity));
    canvas.drawRect(const Rect.fromLTRB(-2, -12, 2, -4),
        Paint()..color = Colors.white.withOpacity(.3 * opacity));
    canvas.restore();
  }

  void _drawRadar(Canvas canvas, double x, double y, double scale) {
    for (var i = 0; i < 3; i++) {
      final age = t - (2.4 + i * .5);
      if (age < 0 || age > 1.2) continue;
      final p = age / 1.2;
      canvas.drawOval(
          Rect.fromCenter(
              center: Offset(x, y - 1),
              width: (35 + p * 115) * scale,
              height: (8 + p * 20) * scale),
          Paint()
            ..color = _cyan.withOpacity((1 - p) * .26)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2);
    }
  }

  void _drawDetection(Canvas canvas, Offset bottle, double scale) {
    if (t < 3 || t > 4.8) return;
    final fade = 1 - _introSeg(t, 4.4, 4.8);
    final shrink = 1.9 - .9 * _introSeg(t, 3, 4.2);
    final rect = Rect.fromCenter(
        center: bottle.translate(0, -13 * scale),
        width: 27 * scale * shrink,
        height: 34 * scale * shrink);
    final paint = Paint()
      ..color = _green.withOpacity(.95 * fade)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    final corner = 7 * scale;
    for (final sx in [-1.0, 1.0]) {
      for (final sy in [-1.0, 1.0]) {
        final p = Offset(rect.center.dx + sx * rect.width / 2,
            rect.center.dy + sy * rect.height / 2);
        canvas.drawLine(p, p.translate(-sx * corner, 0), paint);
        canvas.drawLine(p, p.translate(0, -sy * corner), paint);
      }
    }
    _drawText(
        canvas,
        'PLASTIC  ·  94%',
        Offset(rect.left - 17 * scale, rect.top - 12 * scale),
        _green.withOpacity(fade),
        7 * scale,
        true);
  }

  void _drawText(Canvas canvas, String text, Offset at, Color color,
      double size, bool bold) {
    final painter = TextPainter(
        text: TextSpan(
            text: text,
            style: TextStyle(
                color: color,
                fontSize: size,
                fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
                letterSpacing: .5)),
        textDirection: TextDirection.ltr)
      ..layout();
    painter.paint(canvas, at);
  }

  @override
  bool shouldRepaint(covariant IntroPainter oldDelegate) => oldDelegate.t != t;
}

double _introSeg(double t, double start, double end) =>
    ((t - start) / (end - start)).clamp(0.0, 1.0);
double _ease(double value) => Curves.easeInOutCubic.transform(value);
double _introPulse(double t, double start, double end) =>
    .5 + .5 * math.sin((t - start) / (end - start) * math.pi * 5);

class ServoInfo {
  final String name, channel, function, left, right;
  const ServoInfo(
      this.name, this.channel, this.function, this.left, this.right);
}

const servos = <ServoInfo>[
  ServoInfo('MG995 #1', 'CH0', 'Base rotation', 'Left', 'Right'),
  ServoInfo('MG995 #2', 'CH1', 'Shoulder', 'Up', 'Down'),
  ServoInfo('MG995 #3', 'CH2', 'Elbow', 'Up', 'Down'),
  ServoInfo('MG90S #1', 'CH3', 'Wrist', 'Left', 'Right'),
  ServoInfo('MG90S #2', 'CH4', 'Wrist rotation', 'Up', 'Down'),
  ServoInfo('MG90S #3', 'CH5', 'Gripper', 'Open', 'Close'),
];

class ControlScreen extends StatefulWidget {
  const ControlScreen({
    super.key,
    this.onBack,
    this.isConnected = false,
    this.robotBaseUrl,
    this.robotClient,
    this.onConnectionAction,
  });

  final VoidCallback? onBack;
  final VoidCallback? onConnectionAction;
  final bool isConnected;
  final String? robotBaseUrl;
  final HttpClient? robotClient;
  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  static const servoApiNames = [
    'base',
    'shoulder',
    'elbow',
    'wrist',
    'wristRotation',
    'gripper',
  ];

  int tab = 0, selectedServo = 0, servoStep = 2;
  double speed = 42;
  final angles = List<double>.filled(6, 90);
  String? activeDrive, lastServoAction;
  String? pressedServoAction;
  Timer? servoRepeatTimer;
  Timer? statusTimer;
  bool servoControllerOpen = false;
  bool robotOnline = false;
  bool emergencyActive = false;
  bool statusRequestInProgress = false;
  double? frontDistance, rearDistance;

  @override
  void initState() {
    super.initState();
    _syncStatusPolling();
  }

  @override
  void didUpdateWidget(covariant ControlScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.robotBaseUrl != widget.robotBaseUrl ||
        oldWidget.robotClient != widget.robotClient) {
      _syncStatusPolling();
    }
  }

  void _syncStatusPolling() {
    statusTimer?.cancel();
    statusTimer = null;
    if (widget.robotBaseUrl == null || widget.robotClient == null) {
      robotOnline = false;
      return;
    }
    _pollRobotStatus();
    statusTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _pollRobotStatus();
    });
  }

  Future<void> _pollRobotStatus() async {
    if (statusRequestInProgress ||
        widget.robotBaseUrl == null ||
        widget.robotClient == null) {
      return;
    }
    statusRequestInProgress = true;
    try {
      final request = await widget.robotClient!
          .getUrl(Uri.parse('${widget.robotBaseUrl}/api/status'))
          .timeout(const Duration(seconds: 2));
      final response =
          await request.close().timeout(const Duration(seconds: 2));
      final body = await response.transform(utf8.decoder).join();
      if (response.statusCode != 200) {
        throw HttpException('Status endpoint returned ${response.statusCode}');
      }
      final decoded = jsonDecode(body);
      if (decoded is! Map || !mounted) return;
      final servos = decoded['servos'];
      setState(() {
        robotOnline = true;
        emergencyActive = decoded['emergency'] == true;
        final front = decoded['frontDistance'];
        final rear = decoded['rearDistance'];
        frontDistance = front is num ? front.toDouble() : null;
        rearDistance = rear is num ? rear.toDouble() : null;
        if (servos is Map) {
          for (var i = 0; i < servoApiNames.length; i++) {
            final angle = servos[servoApiNames[i]];
            if (angle is num) {
              angles[i] = angle.toDouble().clamp(0, 180).toDouble();
            }
          }
        }
      });
    } catch (_) {
      if (mounted && robotOnline) setState(() => robotOnline = false);
    } finally {
      statusRequestInProgress = false;
    }
  }

  Future<void> _postRobot(String path, [Map<String, Object>? data]) async {
    final client = widget.robotClient;
    final baseUrl = widget.robotBaseUrl;
    if (client == null || baseUrl == null) return;
    try {
      final request = await client
          .postUrl(Uri.parse('$baseUrl$path'))
          .timeout(const Duration(seconds: 2));
      if (data != null) {
        request.headers.contentType = ContentType.json;
        request.write(jsonEncode(data));
      }
      final response =
          await request.close().timeout(const Duration(seconds: 2));
      await response.drain<void>();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Command endpoint returned ${response.statusCode}');
      }
      if (mounted && !robotOnline) setState(() => robotOnline = true);
    } catch (_) {
      if (mounted && robotOnline) setState(() => robotOnline = false);
    }
  }

  void _sendDriveCommand(String direction) {
    if (emergencyActive && direction != 'stop') return;
    _postRobot('/api/drive', {'direction': direction});
  }

  void _sendSpeed() {
    _postRobot('/api/speed', {'speed': speed.round()});
  }

  void _sendServoAngle(int index) {
    _postRobot('/api/servo', {
      'name': servoApiNames[index],
      'angle': angles[index].round(),
    });
  }

  void _stopDrive() {
    if (activeDrive == null) return;
    activeDrive = null;
    _sendDriveCommand('stop');
    if (mounted) setState(() {});
  }

  String _driveApiDirection(String label) => switch (label) {
        'Forward left' => 'forward_left',
        'Forward' => 'forward',
        'Forward right' => 'forward_right',
        'Left' => 'left',
        'Right' => 'right',
        'Backward left' => 'backward_left',
        'Backward' => 'backward',
        'Backward right' => 'backward_right',
        'Spin left' => 'rotate_left',
        'Spin right' => 'rotate_right',
        _ => 'stop',
      };

  @override
  void dispose() {
    servoRepeatTimer?.cancel();
    statusTimer?.cancel();
    if (activeDrive != null) _sendDriveCommand('stop');
    super.dispose();
  }

  void _startServoHold(String action) {
    servoRepeatTimer?.cancel();
    setState(() => pressedServoAction = action);
    _servoAction(action);
    servoRepeatTimer = Timer.periodic(const Duration(milliseconds: 180), (_) {
      _servoAction(action);
    });
  }

  void _stopServoHold() {
    servoRepeatTimer?.cancel();
    servoRepeatTimer = null;
    if (pressedServoAction != null && mounted) {
      setState(() => pressedServoAction = null);
    }
  }

  void _servoAction(String action) {
    setState(() {
      lastServoAction = action;
      if (action == 'Home') {
        angles[selectedServo] = 90;
      } else {
        final delta = switch (selectedServo) {
          0 => action == 'Left' ? servoStep : -servoStep,
          1 => action == 'Up' ? servoStep : -servoStep,
          2 => action == 'Up' ? -servoStep : servoStep,
          3 => action == 'Left' ? servoStep : -servoStep,
          4 => action == 'Up' ? servoStep : -servoStep,
          _ => action == 'Open' ? servoStep : -servoStep,
        };
        angles[selectedServo] =
            (angles[selectedServo] + delta).clamp(0.0, 180.0).toDouble();
      }
    });
    _sendServoAngle(selectedServo);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _topBar(),
              Expanded(
                child: tab == 2
                    ? const ProjectHubScreen()
                    : LayoutBuilder(builder: (context, bounds) {
                        final wide = bounds.maxWidth > 760;
                        final compact = bounds.maxHeight < 730;
                        final width =
                            bounds.maxWidth > 1080 ? 1080.0 : bounds.maxWidth;
                        final cameraHeight =
                            wide ? 320.0 : (compact ? 175.0 : 210.0);
                        final content = SizedBox(
                          width: width,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(
                                22, compact ? 7 : 16, 22, compact ? 6 : 16),
                            child: tab == 0
                                ? _driveContent(wide, compact, cameraHeight)
                                : _armContent(compact, cameraHeight),
                          ),
                        );
                        return Align(
                          alignment: Alignment.topCenter,
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.topCenter,
                            child: content,
                          ),
                        );
                      }),
              ),
              _bottomBar(),
            ],
          ),
        ),
      );

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(22, 9, 18, 7),
        child: Row(
          children: [
            if (widget.onBack != null) ...[
              IconButton(
                  onPressed: widget.onBack,
                  tooltip: 'Back to mode selection',
                  icon: const Icon(Icons.arrow_back_rounded, color: ink)),
              const SizedBox(width: 2),
            ],
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: ink, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.recycling_rounded, color: lime, size: 21),
            ),
            const SizedBox(width: 10),
            const Text('GC BOT',
                style: TextStyle(
                    color: ink,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    fontSize: 13)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFE3E7E0))),
              child: Row(children: [
                Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                        color: robotOnline ? green : const Color(0xFFE2A044),
                        shape: BoxShape.circle)),
                const SizedBox(width: 7),
                Text(robotOnline ? 'CONNECTED' : 'OFFLINE',
                    style: const TextStyle(
                        color: ink,
                        fontSize: 10,
                        letterSpacing: .8,
                        fontWeight: FontWeight.w800)),
              ]),
            ),
            IconButton(
                onPressed: widget.onConnectionAction,
                tooltip:
                    widget.isConnected ? 'Disconnect GC Bot' : 'Connect GC Bot',
                icon: const Icon(Icons.power_settings_new_rounded, color: ink)),
          ],
        ),
      );

  Widget _title(String section, String title, String subtitle, String meta) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(section,
              style: const TextStyle(
                  color: green,
                  letterSpacing: 1.3,
                  fontSize: 9,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(
                child: Text(title,
                    style: const TextStyle(
                        fontSize: 27,
                        height: 1,
                        letterSpacing: -1,
                        fontWeight: FontWeight.w800,
                        color: ink))),
            Text(meta,
                style: const TextStyle(
                    fontSize: 9,
                    letterSpacing: .8,
                    color: muted,
                    fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 5),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: muted)),
        ],
      );

  Widget _driveContent(bool wide, bool compact, double cameraHeight) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _title(
              'MANUAL CONTROL  /  DRIVE',
              'Take the wheel.',
              'Live view and movement controls for your collection run.',
              'UNIT 07  ·  ROVER'),
          SizedBox(height: compact ? 8 : 18),
          if (wide)
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                  flex: 6,
                  child: Column(children: [
                    _camera(cameraHeight),
                    const SizedBox(height: 14),
                    _sensors()
                  ])),
              const SizedBox(width: 16),
              Expanded(flex: 5, child: _drivePanel(compact)),
            ])
          else
            Column(mainAxisSize: MainAxisSize.min, children: [
              _camera(cameraHeight),
              SizedBox(height: compact ? 7 : 12),
              _sensors(),
              SizedBox(height: compact ? 7 : 12),
              _drivePanel(compact),
            ]),
        ],
      );

  Widget _armContent(bool compact, double cameraHeight) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _title(
              'MANUAL CONTROL  /  ARM',
              'Work the arm.',
              'Select one servo to open its individual controls.',
              '6-AXIS  ·  PCA9685'),
          SizedBox(height: compact ? 7 : 16),
          _camera(cameraHeight),
          SizedBox(height: compact ? 7 : 14),
          _servoPicker(compact),
          SizedBox(height: compact ? 7 : 14),
          if (servoControllerOpen) _servoPanel(compact),
        ],
      );

  Widget _camera(double height) => Container(
        height: height,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
            color: const Color(0xFF1E2B26),
            borderRadius: BorderRadius.circular(18)),
        child: Stack(fit: StackFit.expand, children: [
          CustomPaint(painter: CameraGrid()),
          if (robotOnline && widget.robotBaseUrl != null)
            MjpegView(
              uri: '${widget.robotBaseUrl}/video_feed',
              fit: BoxFit.cover,
              width: double.infinity,
              height: height,
              fps: 15,
            )
          else
            Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.videocam_off_outlined,
                    color: Colors.white70, size: 25),
                const SizedBox(height: 7),
                Text(
                  widget.robotBaseUrl == null
                      ? 'Connect GC Bot to view the camera'
                      : 'Waiting for camera stream',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600),
                ),
                Text('Raspberry Pi live feed · /video_feed',
                    style: TextStyle(
                        color: Colors.white.withOpacity(.58), fontSize: 9)),
              ]),
            ),
          Positioned(
            left: 14,
            top: 12,
            child: _cameraTag(Icons.videocam_rounded, 'USB UVC CAMERA'),
          ),
          Positioned(
            left: 14,
            bottom: 10,
            child: Text(
              robotOnline
                  ? 'LIVE STREAM  ·  15 FPS'
                  : 'USB UVC CAMERA  ·  640 × 480',
              style: TextStyle(
                  color: Colors.white.withOpacity(.6),
                  fontSize: 8,
                  letterSpacing: .7),
            ),
          ),
        ]),
      );
  Widget _cameraTag(IconData icon, String label, {bool dot = false}) =>
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
            color: Colors.black.withOpacity(.32),
            borderRadius: BorderRadius.circular(8)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon,
              color: dot ? const Color(0xFFE2A044) : Colors.white,
              size: dot ? 7 : 12),
          const SizedBox(width: 5),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  letterSpacing: .7)),
        ]),
      );

  Widget _sensors() => Row(children: [
        _sensorCard('FRONT ULTRASONIC', frontDistance),
        const SizedBox(width: 10),
        _sensorCard('REAR ULTRASONIC', rearDistance),
      ]);

  Widget _sensorCard(String label, double? distance) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE8EBE5))),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.sensors_rounded, size: 14, color: green),
              const SizedBox(width: 6),
              Expanded(
                  child: Text(label,
                      style: const TextStyle(
                          color: muted,
                          fontSize: 8,
                          letterSpacing: .4,
                          fontWeight: FontWeight.w800))),
            ]),
            const SizedBox(height: 7),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(distance?.toStringAsFixed(1) ?? '—',
                  style: const TextStyle(
                      color: ink,
                      fontSize: 22,
                      height: 1,
                      fontWeight: FontWeight.w800)),
              const SizedBox(width: 4),
              const Padding(
                  padding: EdgeInsets.only(bottom: 2),
                  child:
                      Text('cm', style: TextStyle(color: muted, fontSize: 9))),
            ]),
            const SizedBox(height: 5),
            Text(distance == null ? 'Awaiting sensor' : 'Live reading',
                style: const TextStyle(color: muted, fontSize: 9)),
          ]),
        ),
      );
  Widget _drivePanel(bool compact) => Container(
        padding: EdgeInsets.all(compact ? 11 : 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE8EBE5))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(
                child: Text('Drive control',
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: ink))),
            const Text('HOLD TO MOVE',
                style: TextStyle(
                    color: muted,
                    fontSize: 8,
                    letterSpacing: .7,
                    fontWeight: FontWeight.w700))
          ]),
          SizedBox(height: compact ? 5 : 10),
          Center(
              child: SizedBox(
                  width: 226,
                  height: compact ? 158 : 200,
                  child: Stack(alignment: Alignment.center, children: [
                    Container(
                        width: compact ? 72 : 88,
                        height: compact ? 72 : 88,
                        decoration: BoxDecoration(
                            color: canvas,
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFFE6EAE3))),
                        child: const Icon(Icons.gamepad_rounded,
                            color: Color(0xFFADB7AF), size: 25)),
                    _driveButton(Icons.north_west_rounded, 'Forward left',
                        Alignment.topLeft, compact),
                    _driveButton(Icons.north_rounded, 'Forward',
                        Alignment.topCenter, compact),
                    _driveButton(Icons.north_east_rounded, 'Forward right',
                        Alignment.topRight, compact),
                    _driveButton(Icons.west_rounded, 'Left',
                        Alignment.centerLeft, compact),
                    _driveButton(Icons.east_rounded, 'Right',
                        Alignment.centerRight, compact),
                    _driveButton(Icons.south_west_rounded, 'Backward left',
                        Alignment.bottomLeft, compact),
                    _driveButton(Icons.south_rounded, 'Backward',
                        Alignment.bottomCenter, compact),
                    _driveButton(Icons.south_east_rounded, 'Backward right',
                        Alignment.bottomRight, compact),
                  ]))),
          SizedBox(height: compact ? 3 : 7),
          Row(children: [
            Expanded(
                child: _spinButton(
                    Icons.rotate_left_rounded, '360° LEFT', 'Spin left')),
            const SizedBox(width: 8),
            Expanded(
                child: _spinButton(
                    Icons.rotate_right_rounded, '360° RIGHT', 'Spin right'))
          ]),
          SizedBox(height: compact ? 7 : 15),
          Row(children: [
            const Icon(Icons.speed_rounded, size: 16, color: green),
            const SizedBox(width: 6),
            const Text('SPEED',
                style: TextStyle(
                    color: ink,
                    fontSize: 9,
                    letterSpacing: .8,
                    fontWeight: FontWeight.w800)),
            const Spacer(),
            Text('${speed.round()}%',
                style: const TextStyle(
                    color: ink, fontSize: 11, fontWeight: FontWeight.w800))
          ]),
          SizedBox(
              height: compact ? 42 : 48,
              child: Row(children: [
                _speedAdjustButton(increase: false),
                Expanded(
                  child: Slider(
                    value: speed,
                    min: 0,
                    max: 100,
                    activeColor: green,
                    inactiveColor: const Color(0xFFE5EAE4),
                    onChanged: (value) => setState(() => speed = value),
                    onChangeEnd: (_) => _sendSpeed(),
                  ),
                ),
                _speedAdjustButton(increase: true),
              ])),
          const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('PRECISE', style: TextStyle(color: muted, fontSize: 8)),
                Text('MAX POWER', style: TextStyle(color: muted, fontSize: 8))
              ]),
        ]),
      );

  Widget _driveButton(
          IconData icon, String label, Alignment alignment, bool compact) =>
      Align(
        alignment: alignment,
        child: GestureDetector(
          onTapDown: (_) {
            setState(() => activeDrive = label);
            _sendDriveCommand(_driveApiDirection(label));
          },
          onTapUp: (_) => _stopDrive(),
          onTapCancel: () => _stopDrive(),
          child: Container(
            width: compact ? 48 : 54,
            height: compact ? 44 : 50,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: activeDrive == label ? green : Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color:
                        activeDrive == label ? green : const Color(0xFFE5E9E3)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(.035),
                      blurRadius: 5,
                      offset: const Offset(0, 2))
                ]),
            child: Icon(icon,
                size: 20, color: activeDrive == label ? Colors.white : ink),
          ),
        ),
      );
  Widget _speedAdjustButton({required bool increase}) => Tooltip(
        message: increase ? 'Increase speed by 5%' : 'Decrease speed by 5%',
        child: InkWell(
          onTap: () {
            setState(() => speed =
                (speed + (increase ? 5 : -5)).clamp(0.0, 100.0).toDouble());
            _sendSpeed();
          },
          borderRadius: BorderRadius.circular(9),
          child: Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
                color: canvas,
                borderRadius: BorderRadius.circular(9),
                border: Border.all(color: const Color(0xFFE3E8E1))),
            child: Icon(increase ? Icons.add_rounded : Icons.remove_rounded,
                size: 17, color: ink),
          ),
        ),
      );

  Widget _spinButton(IconData icon, String label, String command) =>
      GestureDetector(
        onTapDown: (_) {
          setState(() => activeDrive = command);
          _sendDriveCommand(_driveApiDirection(command));
        },
        onTapUp: (_) => _stopDrive(),
        onTapCancel: () => _stopDrive(),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
              color: activeDrive == command
                  ? const Color(0xFFF0F4EB)
                  : Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFE3E8E1))),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 15, color: ink),
            const SizedBox(width: 5),
            Text(label,
                style: const TextStyle(
                    color: ink, fontSize: 8, fontWeight: FontWeight.w800)),
          ]),
        ),
      );
  Widget _servoPicker(bool compact) => Container(
        width: double.infinity,
        padding: EdgeInsets.all(compact ? 9 : 13),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE8EBE5))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(
                child: Text('Servo selection',
                    style: TextStyle(
                        color: ink,
                        fontSize: 13,
                        fontWeight: FontWeight.w800))),
            const Text('LEFT 3  /  RIGHT 3',
                style: TextStyle(
                    color: muted,
                    fontSize: 8,
                    letterSpacing: .5,
                    fontWeight: FontWeight.w800))
          ]),
          SizedBox(height: compact ? 7 : 10),
          LayoutBuilder(builder: (context, bounds) {
            const order = [0, 1, 2, 3, 4, 5];
            const gap = 8.0;
            final width = (bounds.maxWidth - gap) / 2;
            return Wrap(spacing: gap, runSpacing: compact ? 7 : 10, children: [
              for (final index in order)
                SizedBox(width: width, child: _servoTile(index, compact)),
            ]);
          }),
        ]),
      );

  Widget _servoTile(int index, bool compact) {
    final servo = servos[index];
    final selected = servoControllerOpen && selectedServo == index;
    return InkWell(
      onTap: () => setState(() {
        if (selectedServo == index && servoControllerOpen) {
          servoControllerOpen = false;
        } else {
          selectedServo = index;
          servoControllerOpen = true;
        }
        lastServoAction = null;
      }),
      borderRadius: BorderRadius.circular(11),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: EdgeInsets.all(compact ? 11 : 14),
        decoration: BoxDecoration(
            color: selected ? const Color(0xFFF0F4EB) : Colors.white,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(
                color: selected ? green : const Color(0xFFE5E9E3),
                width: selected ? 1.3 : 1)),
        child: Row(children: [
          Container(
              width: compact ? 29 : 34,
              height: compact ? 29 : 34,
              decoration: BoxDecoration(
                  color: selected ? green : canvas,
                  borderRadius: BorderRadius.circular(8)),
              child: Icon(Icons.settings_input_component_rounded,
                  size: 16, color: selected ? Colors.white : muted)),
          const SizedBox(width: 7),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(servo.function,
                    style: const TextStyle(
                        color: ink, fontSize: 11, fontWeight: FontWeight.w800)),
                Text('${servo.name} · ${servo.channel}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: muted, fontSize: 8))
              ])),
          Text(index.isEven ? 'L' : 'R',
              style: TextStyle(
                  color: selected ? green : muted,
                  fontSize: 8,
                  fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }

  Widget _servoPanel(bool compact) {
    final servo = servos[selectedServo];
    final angle = angles[selectedServo];
    return Container(
      width: double.infinity,
      padding:
          EdgeInsets.fromLTRB(15, compact ? 12 : 16, 15, compact ? 11 : 15),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE8EBE5))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(servo.function,
                    style: const TextStyle(
                        color: ink,
                        fontSize: 16,
                        letterSpacing: -.2,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text('${servo.name}  ·  ${servo.channel}',
                    style: const TextStyle(
                        color: muted, fontSize: 9, fontWeight: FontWeight.w700))
              ])),
          Text('${angle.round()}°',
              style: const TextStyle(
                  color: ink, fontSize: 16, fontWeight: FontWeight.w800)),
        ]),
        SizedBox(height: compact ? 5 : 10),
        Row(children: [
          const Icon(Icons.tune_rounded, color: green, size: 15),
          const SizedBox(width: 6),
          const Text('POSITION',
              style: TextStyle(
                  color: ink,
                  fontSize: 9,
                  letterSpacing: .7,
                  fontWeight: FontWeight.w800)),
          const Spacer(),
          const Text('0° — 180°', style: TextStyle(color: muted, fontSize: 9))
        ]),
        SizedBox(
            height: compact ? 35 : 42,
            child: Slider(
                value: angle,
                min: 0,
                max: 180,
                activeColor: green,
                inactiveColor: const Color(0xFFE5EAE4),
                onChanged: (value) => setState(() {
                      angles[selectedServo] = value;
                      lastServoAction = null;
                    }),
                onChangeEnd: (_) => _sendServoAngle(selectedServo))),
        Row(children: [
          Expanded(child: _servoButton(servo.left, Icons.arrow_back_rounded)),
          const SizedBox(width: 8),
          Expanded(child: _servoButton('Home', Icons.home_rounded, home: true)),
          const SizedBox(width: 8),
          Expanded(
              child: _servoButton(servo.right, Icons.arrow_forward_rounded))
        ]),
        SizedBox(height: compact ? 7 : 9),
        Row(children: [
          const Icon(Icons.tune_rounded, color: green, size: 15),
          const SizedBox(width: 6),
          const Text('STEP',
              style: TextStyle(
                  color: ink,
                  fontSize: 9,
                  letterSpacing: .7,
                  fontWeight: FontWeight.w800)),
          const Spacer(),
          for (final step in const [2, 4, 5]) ...[
            if (step != 2) const SizedBox(width: 6),
            _stepChoice(step),
          ],
        ]),
        if (lastServoAction != null)
          Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('$lastServoAction · ${angle.round()}°  /  UI PREVIEW',
                  style: const TextStyle(
                      color: green, fontSize: 8, fontWeight: FontWeight.w700))),
      ]),
    );
  }

  Widget _servoButton(String label, IconData icon, {bool home = false}) =>
      GestureDetector(
        onTap: home ? () => _servoAction(label) : null,
        onTapDown: home ? null : (_) => _startServoHold(label),
        onTapUp: home ? null : (_) => _stopServoHold(),
        onTapCancel: home ? null : _stopServoHold,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
          decoration: BoxDecoration(
            color: home
                ? green
                : pressedServoAction == label
                    ? const Color(0xFFEAF1E9)
                    : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: home ? green : const Color(0xFFE3E8E1)),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 14, color: home ? Colors.white : ink),
            const SizedBox(width: 4),
            Flexible(
              child: Text(label,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: home ? Colors.white : ink)),
            ),
          ]),
        ),
      );

  Widget _stepChoice(int step) {
    final selected = servoStep == step;
    return InkWell(
      onTap: () => setState(() => servoStep = step),
      borderRadius: BorderRadius.circular(8),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? green : canvas,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: selected ? green : const Color(0xFFE3E8E1)),
        ),
        child: Text('$step°',
            style: TextStyle(
                color: selected ? Colors.white : ink,
                fontSize: 9,
                fontWeight: FontWeight.w800)),
      ),
    );
  }

  Widget _bottomBar() => Container(
        padding: const EdgeInsets.fromLTRB(14, 7, 14, 7),
        decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: Color(0xFFE7EAE5)))),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _navButton(0, Icons.gamepad_rounded, 'Drive'),
          _navButton(1, Icons.precision_manufacturing_rounded, 'Arm'),
          _navButton(2, Icons.dashboard_rounded, 'Project hub'),
        ]),
      );

  Widget _navButton(int index, IconData icon, String label) => InkWell(
        onTap: () => setState(() => tab = index),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 18, color: tab == index ? green : muted),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(
                    fontSize: 9,
                    fontWeight:
                        tab == index ? FontWeight.w800 : FontWeight.w500,
                    color: tab == index ? green : muted)),
          ]),
        ),
      );
}

class CameraGrid extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = Colors.white.withOpacity(.035)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 28) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += 28) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader =
          RadialGradient(colors: [green.withOpacity(.3), Colors.transparent])
              .createShader(Rect.fromCircle(
                  center: Offset(size.width * .5, size.height * .5),
                  radius: size.width * .6));
    canvas.drawRect(Offset.zero & size, glow);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ProjectHubScreen extends StatelessWidget {
  const ProjectHubScreen({super.key});

  // ============================================================
  // PREMIUM ROBOTICS - DARK BLUE + TEAL GLOW THEME
  // ============================================================

  static const Color bg = Color(0xFFF4F5F0);
  static const Color appBar = Color(0xFFFFFFFF);

  static const Color card = Color(0xFFFFFFFF);
  static const Color card2 = Color(0xFFFAFBF8);

  static const Color teal = Color(0xFF39745C);
  static const Color tealLight = Color(0xFF6F9651);
  static const Color selected = Color(0xFFEAF1E8);

  static const Color border = Color(0xFFE3E8E1);
  static const Color selectedBorder = Color(0xFF39745C);

  static const Color red = Color(0xFFFF4D5A);
  static const Color white = Color(0xFF17241F);
  static const Color grey = Color(0xFF718078);
  static const Color muted = Color(0xFF718078);

  // ============================================================
  // COMMON PREMIUM DECORATIONS
  // ============================================================

  static BoxDecoration premiumCard({
    Color accent = teal,
    bool redAccent = false,
  }) {
    final glow = redAccent ? red : accent;

    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [card2, card, const Color(0xFFF4F5F0)],
      ),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(
        color: glow.withOpacity(redAccent ? 0.28 : 0.20),
        width: 1,
      ),
      boxShadow: [
        BoxShadow(
          color: glow.withOpacity(redAccent ? 0.055 : 0.045),
          blurRadius: 18,
          spreadRadius: 1,
          offset: const Offset(0, 5),
        ),
        const BoxShadow(
          color: Color(0x12000000),
          blurRadius: 8,
          offset: Offset(0, 3),
        ),
      ],
    );
  }

  static BoxDecoration iconBox({Color accent = teal, bool locked = false}) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: locked
            ? [const Color(0xFFF4F5F0), const Color(0xFFFAFBF8)]
            : [accent.withOpacity(0.19), accent.withOpacity(0.055)],
      ),
      borderRadius: BorderRadius.circular(13),
      border: Border.all(
        color:
            locked ? Colors.white.withOpacity(0.06) : accent.withOpacity(0.30),
      ),
      boxShadow: locked
          ? []
          : [
              BoxShadow(
                color: accent.withOpacity(0.075),
                blurRadius: 14,
                spreadRadius: 1,
              ),
            ],
    );
  }

  static BoxDecoration smallGlowBox(Color color) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [color.withOpacity(0.18), color.withOpacity(0.045)],
      ),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color.withOpacity(0.22)),
      boxShadow: [BoxShadow(color: color.withOpacity(0.045), blurRadius: 10)],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 860),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 20),
              _sectionTitle('PROJECT INFORMATION'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.smart_toy_outlined,
                  title: 'ABOUT GC Bot',
                  subtitle: 'Project overview and system architecture',
                  color: teal,
                  onTap: () => _openPage(context, const AboutGCBotPage())),
              _hubCard(
                  icon: Icons.flag_outlined,
                  title: 'PROJECT OBJECTIVES',
                  subtitle: 'Main goals and functions of GC Bot',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const ProjectObjectivesPage())),
              _hubCard(
                  icon: Icons.memory_outlined,
                  title: 'HARDWARE COMPONENTS',
                  subtitle: 'Components used in the robot',
                  color: tealLight,
                  onTap: () =>
                      _openPage(context, const HardwareComponentsPage())),
              _hubCard(
                  icon: Icons.account_tree_outlined,
                  title: 'CONNECTIONS & GPIO',
                  subtitle: 'Raspberry Pi wiring and GPIO configuration',
                  color: teal,
                  onTap: () => _openPage(context, const ConnectionsPage())),
              const SizedBox(height: 12),
              _sectionTitle('SYSTEM WORKING'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.smart_toy,
                  title: 'AUTONOMOUS WORKING',
                  subtitle: 'Obstacle avoidance and autonomous operation',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const AutonomousWorkingPage())),
              _hubCard(
                  icon: Icons.phone_android,
                  title: 'APP CONTROL / MANUAL WORKING',
                  subtitle: 'Control GC Bot using the Android application',
                  color: tealLight,
                  onTap: () =>
                      _openPage(context, const AppManualWorkingPage())),
              _hubCard(
                  icon: Icons.hub_outlined,
                  title: 'FULL SYSTEM WORKING',
                  subtitle:
                      'Complete robot operation from detection to collection',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const FullSystemWorkingPage())),
              const SizedBox(height: 12),
              _sectionTitle('PROJECT DEVELOPMENT'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.precision_manufacturing_outlined,
                  title: 'ARM CONFIGURATION',
                  subtitle:
                      'Robotic arm servo mapping, presets and configuration',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const ArmConfigurationPage())),
              _hubCard(
                  icon: Icons.lock_outline,
                  title: 'SOFTWARE & TECHNOLOGIES',
                  subtitle:
                      'Software architecture and development technologies',
                  color: muted,
                  locked: true),
              _hubCard(
                  icon: Icons.menu_book_outlined,
                  title: 'PROJECT DIARY',
                  subtitle: 'Development progress and project timeline',
                  color: tealLight,
                  onTap: () => _openPage(context, const ProjectDiaryPage())),
              _hubCard(
                  icon: Icons.auto_awesome_outlined,
                  title: 'FUTURE IMPROVEMENTS',
                  subtitle: 'Planned intelligent features and future upgrades',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const FutureImprovementsPage())),
              const SizedBox(height: 18),
              _footer(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF0F4EB), Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
        ),
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: teal.withOpacity(0.30)),
        boxShadow: [
          BoxShadow(
            color: teal.withOpacity(0.09),
            blurRadius: 22,
            spreadRadius: 1,
          ),
          const BoxShadow(
            color: Color(0x18000000),
            blurRadius: 12,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 53,
            height: 53,
            decoration: iconBox(accent: teal),
            child: const Icon(
              Icons.settings_input_component,
              color: tealLight,
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'GC BOT PROJECT HUB',
                  style: TextStyle(
                    color: white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Explore the robot, hardware, working system and development.',
                  style: TextStyle(color: grey, fontSize: 12, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 19,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [tealLight, teal],
            ),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: teal.withOpacity(0.35), blurRadius: 8),
            ],
          ),
        ),
        const SizedBox(width: 9),
        Text(
          title,
          style: const TextStyle(
            color: white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _hubCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    VoidCallback? onTap,
    bool locked = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: locked ? null : onTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: teal.withOpacity(0.10),
          highlightColor: teal.withOpacity(0.055),
          hoverColor: teal.withOpacity(0.035),
          child: Ink(
            decoration: premiumCard(accent: locked ? muted : color),
            child: Container(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  Container(
                    width: 47,
                    height: 47,
                    decoration: iconBox(
                      accent: locked ? muted : color,
                      locked: locked,
                    ),
                    child: Icon(icon, color: locked ? muted : color, size: 23),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                title,
                                style: TextStyle(
                                  color: locked ? muted : white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            if (locked)
                              const Icon(Icons.lock, color: muted, size: 16),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: locked ? muted.withOpacity(0.65) : grey,
                            fontSize: 11,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!locked)
                    Icon(
                      Icons.chevron_right,
                      color: tealLight.withOpacity(0.85),
                      size: 23,
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _footer() {
    return Center(
      child: Column(
        children: [
          Container(
            width: 45,
            height: 45,
            decoration: iconBox(accent: teal),
            child: const Icon(
              Icons.smart_toy_outlined,
              color: tealLight,
              size: 25,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'GC Bot',
            style: TextStyle(
              color: white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            'AI-Based Autonomous Garbage Collection Robot',
            textAlign: TextAlign.center,
            style: TextStyle(color: grey.withOpacity(0.8), fontSize: 10),
          ),
        ],
      ),
    );
  }

  void _openPage(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}

// ============================================================
// ABOUT GC Bot
// ============================================================

class AboutGCBotPage extends StatelessWidget {
  const AboutGCBotPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return _standardPage(context, 'ABOUT GC Bot', Icons.smart_toy_outlined, [
      _infoCard(
        'PROJECT',
        'GC Bot is an AI-Based Autonomous Garbage Collection Robot designed to identify, collect and manage garbage using a mobile robotic platform, robotic arm, sensors and camera.',
        teal,
      ),
      _infoCard(
        'MAIN PLATFORM',
        'The robot uses four BO motors with mecanum wheels, two L298N motor drivers and a Raspberry Pi 4 Model B as the main control computer.',
        tealLight,
      ),
      _infoCard(
        'ROBOTIC ARM',
        'A six-servo robotic arm is used to pick garbage and transfer it into the waste container mounted on the robot.',
        teal,
      ),
      _infoCard(
        'VISION & SENSING',
        'A USB camera provides visual input while front and rear ultrasonic sensors provide distance information for obstacle awareness.',
        tealLight,
      ),
      _infoCard(
        'CONTROL',
        'The Android GC Bot application is being developed as the professional control interface for manual operation, monitoring and future autonomous functions.',
        teal,
      ),
    ]);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.7,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(children: children),
      ),
    );
  }

  Widget _infoCard(String title, String text, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 9),
          Text(
            text,
            style: const TextStyle(color: grey, fontSize: 12, height: 1.55),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// PROJECT OBJECTIVES
// ============================================================

class ProjectObjectivesPage extends StatelessWidget {
  const ProjectObjectivesPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return _standardPage(context, 'PROJECT OBJECTIVES', Icons.flag_outlined, [
      _objective(
        '01',
        'AUTONOMOUS MOVEMENT',
        'Enable GC Bot to navigate the working area with minimum human intervention.',
        teal,
      ),
      _objective(
        '02',
        'GARBAGE DETECTION',
        'Use the camera and future AI vision processing to identify garbage that needs to be collected.',
        tealLight,
      ),
      _objective(
        '03',
        'GARBAGE COLLECTION',
        'Use the robotic arm to pick detected garbage and place it inside the onboard waste container.',
        teal,
      ),
      _objective(
        '04',
        'OBSTACLE AVOIDANCE',
        'Use ultrasonic distance sensors to detect obstacles and improve safe navigation.',
        tealLight,
      ),
      _objective(
        '05',
        'MOBILE CONTROL',
        'Provide a professional Android interface for manual driving, arm control and system monitoring.',
        teal,
      ),
      _objective(
        '06',
        'FUTURE AUTONOMY',
        'Develop automatic container management, battery monitoring, charging and work-resume functions.',
        tealLight,
      ),
    ]);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(children: children),
      ),
    );
  }

  Widget _objective(
    String number,
    String title,
    String description,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: ProjectHubScreen.smallGlowBox(color),
            child: Text(
              number,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// HARDWARE COMPONENTS
// ============================================================

class HardwareComponentsPage extends StatelessWidget {
  const HardwareComponentsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    final components = [
      ['Raspberry Pi 4 Model B', '1 unit'],
      ['Raspberry Pi USB 2.0 Camera', '1 unit'],
      ['SD Card', '1 unit'],
      ['BO Motors', '4 units'],
      ['Mecanum Wheels', '4 units'],
      ['L298N Motor Drivers', '2 units'],
      ['3S 12V Lithium-Ion Batteries', '3 units'],
      ['Lithium-Ion Charger', '1 unit'],
      ['Wooden Board Chassis', '1 unit'],
      ['3D-Printed Robotic Arm', '1 unit'],
      ['MG995 Servo Motors', '3 units'],
      ['MG90S Servo Motors', '3 units'],
      ['Buck Converter', '1 unit'],
      ['PCA9685 Servo Driver', '1 unit'],
      ['HC-SR04 Ultrasonic Sensors', '2 units'],
      ['1 kΩ Resistors (voltage divider)', '4 units'],
      ['Jumper Wires', 'As required'],
      ['Switches', '4 units'],
      ['Cooling Fans', '2 units'],
    ];

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.memory_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'HARDWARE COMPONENTS',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: components.length,
        itemBuilder: (context, index) {
          final item = components[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 9),
            padding: const EdgeInsets.all(14),
            decoration: ProjectHubScreen.premiumCard(
              accent: index.isEven ? teal : tealLight,
            ),
            child: Row(
              children: [
                Container(
                  width: 39,
                  height: 39,
                  decoration: ProjectHubScreen.smallGlowBox(
                    index.isEven ? teal : tealLight,
                  ),
                  child: const Icon(
                    Icons.check_circle_outline,
                    color: tealLight,
                    size: 21,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item[0],
                    style: const TextStyle(
                      color: white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Text(
                  item[1],
                  style: const TextStyle(color: grey, fontSize: 11),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// CONNECTIONS & GPIO
// ============================================================

class ConnectionsPage extends StatelessWidget {
  const ConnectionsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.account_tree_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'CONNECTIONS & GPIO',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _group('L298N MOTOR DRIVER #1 — LEFT SIDE', teal, [
              'FL motor → OUT1 / OUT2 → IN1 GPIO17, IN2 GPIO27',
              'RL motor → OUT3 / OUT4 → IN3 GPIO10, IN4 GPIO24',
              'ENA → GPIO18 (physical Pin 12)',
              'ENB → GPIO19 (physical Pin 35)',
            ]),
            _group('L298N MOTOR DRIVER #2 — RIGHT SIDE', tealLight, [
              'FR motor → OUT1 / OUT2 → IN1 GPIO5, IN2 GPIO6',
              'RR motor → OUT3 / OUT4 → IN3 GPIO13, IN4 GPIO26',
              'ENA → GPIO20 (physical Pin 38)',
              'ENB → GPIO21 (physical Pin 40)',
            ]),
            _group('ULTRASONIC SENSORS', teal, [
              'Front HC-SR04 → TRIG GPIO9, ECHO GPIO25',
              'Rear HC-SR04 → TRIG GPIO16, ECHO GPIO12',
              'Echo signals use a voltage divider before Raspberry Pi GPIO',
            ]),
            _group('PCA9685 SERVO DRIVER', tealLight, [
              'VCC → Raspberry Pi 3.3V',
              'GND → Raspberry Pi GND',
              'SDA → GPIO2',
              'SCL → GPIO3',
              'I2C address → 0x40',
            ]),
            _group('SERVO CHANNELS', teal, [
              'CH0 → Base → MG995',
              'CH1 → Shoulder → MG995',
              'CH2 → Elbow → MG995',
              'CH3 → Wrist → MG90S',
              'CH4 → Wrist Rotation → MG90S',
              'CH5 → Gripper → MG90S',
            ]),
            _group('COOLING FANS — PARALLEL CONNECTION', tealLight, [
              'Connect Fan 1 positive to Fan 2 positive (shared + line).',
              'Connect Fan 1 negative to Fan 2 negative (shared − line).',
              'Battery negative → shared fan negative line.',
              'Battery positive → one switch → shared fan positive line.',
            ]),
            _group('POWER & SAFETY', red, [
              'Motor batteries supply the L298N motor drivers.',
              'Raspberry Pi uses a proper USB-C power supply.',
              'Servo power uses a separate suitable 5–6V supply/BEC.',
              'All grounds must be common.',
              'Never connect motor battery voltage directly to Raspberry Pi 5V.',
              'Physical emergency stop is placed in the motor battery positive line.',
            ]),
          ],
        ),
      ),
    );
  }

  Widget _group(String title, Color color, List<String> lines) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 11),
          ...lines.map(
            (line) => Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• ', style: TextStyle(color: color, fontSize: 12)),
                  Expanded(
                    child: Text(
                      line,
                      style: const TextStyle(
                        color: grey,
                        fontSize: 11,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// AUTONOMOUS WORKING
// ============================================================

class AutonomousWorkingPage extends StatelessWidget {
  const AutonomousWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    const steps = [
      _WorkStep(
        '01',
        'START',
        'GC Bot starts its autonomous operating mode.',
        Icons.power_settings_new,
        teal,
      ),
      _WorkStep(
        '02',
        'SENSE',
        'Ultrasonic sensors continuously monitor the surrounding area.',
        Icons.radar,
        tealLight,
      ),
      _WorkStep(
        '03',
        'DETECT',
        'The camera can provide visual information for future AI-based garbage detection.',
        Icons.camera_alt_outlined,
        teal,
      ),
      _WorkStep(
        '04',
        'NAVIGATE',
        'The mecanum drive platform moves through the working area while responding to obstacles.',
        Icons.navigation_outlined,
        tealLight,
      ),
      _WorkStep(
        '05',
        'COLLECT',
        'The robotic arm picks the detected garbage and transfers it into the onboard container.',
        Icons.precision_manufacturing_outlined,
        teal,
      ),
      _WorkStep(
        '06',
        'CONTINUE',
        'The robot continues searching and collecting according to the autonomous control logic.',
        Icons.autorenew,
        tealLight,
      ),
    ];

    return _standardPage(context, 'AUTONOMOUS WORKING', Icons.smart_toy, steps);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<_WorkStep> steps,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: steps.length,
        itemBuilder: (context, index) {
          final step = steps[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 11),
            padding: const EdgeInsets.all(15),
            decoration: ProjectHubScreen.premiumCard(accent: step.color),
            child: Row(
              children: [
                Container(
                  width: 45,
                  height: 45,
                  decoration: ProjectHubScreen.iconBox(accent: step.color),
                  child: Icon(step.icon, color: step.color, size: 22),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            step.number,
                            style: TextStyle(
                              color: step.color,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            step.title,
                            style: const TextStyle(
                              color: white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        step.description,
                        style: const TextStyle(
                          color: grey,
                          fontSize: 11,
                          height: 1.45,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// APP CONTROL / MANUAL WORKING
// ============================================================

class AppManualWorkingPage extends StatelessWidget {
  const AppManualWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.phone_android, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'APP CONTROL / MANUAL',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _step(
              '01',
              'CONNECT',
              'The Android GC Bot application communicates with the Raspberry Pi through the local Wi-Fi network.',
              Icons.wifi,
              teal,
            ),
            _step(
              '02',
              'DRIVE',
              'The DRIVE screen provides forward, backward, left, right and rotation controls for the mecanum wheel platform.',
              Icons.gamepad_outlined,
              tealLight,
            ),
            _step(
              '03',
              'MONITOR',
              'The application can display camera and sensor information received from the robot.',
              Icons.monitor_outlined,
              teal,
            ),
            _step(
              '04',
              'ARM',
              'The ARM screen provides individual servo control, home position and grab/release presets.',
              Icons.precision_manufacturing_outlined,
              tealLight,
            ),
            _step(
              '05',
              'EMERGENCY STOP',
              'The software emergency stop is available from the control screens. A physical emergency stop is also part of the robot safety design.',
              Icons.warning_amber_rounded,
              red,
            ),
            _serverCard(),
          ],
        ),
      ),
    );
  }

  Widget _step(
    String number,
    String title,
    String text,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 23),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  text,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _serverCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CURRENT RASPBERRY PI SERVER',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          SizedBox(height: 9),
          Text(
            '192.168.1.32:5000',
            style: TextStyle(
              color: white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'This is the current Raspberry Pi server address used during project development. The Flutter app backend integration will be connected in the next development stage.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.45),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// FULL SYSTEM WORKING
// ============================================================

class FullSystemWorkingPage extends StatelessWidget {
  const FullSystemWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.hub_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'FULL SYSTEM WORKING',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _systemStep(
              '01',
              'POWER & INITIALIZATION',
              'Raspberry Pi, motor drivers, sensors, camera and robotic arm control system are initialized.',
              Icons.power,
              teal,
            ),
            _systemStep(
              '02',
              'MOBILE PLATFORM',
              'The four mecanum wheels provide movement in forward, backward, sideways and rotational directions.',
              Icons.directions_car_filled_outlined,
              tealLight,
            ),
            _systemStep(
              '03',
              'ENVIRONMENT SENSING',
              'Front and rear ultrasonic sensors monitor distances around the robot for obstacle awareness.',
              Icons.radar,
              teal,
            ),
            _systemStep(
              '04',
              'GARBAGE DETECTION',
              'The USB camera provides visual information for garbage detection and future AI processing.',
              Icons.camera_alt_outlined,
              tealLight,
            ),
            _systemStep(
              '05',
              'ROBOTIC ARM',
              'The robotic arm moves to the required position and picks the garbage.',
              Icons.precision_manufacturing_outlined,
              teal,
            ),
            _systemStep(
              '06',
              'WASTE CONTAINER',
              'The physical waste container is mounted behind the robotic arm. The arm transfers collected garbage into this container.',
              Icons.delete_outline,
              tealLight,
            ),
            _systemStep(
              '07',
              'CONTINUOUS OPERATION',
              'The complete system is intended to continue detecting, navigating and collecting garbage as part of the autonomous working cycle.',
              Icons.autorenew,
              teal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _systemStep(
    String number,
    String title,
    String text,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  text,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ARM CONFIGURATION - ACTIVE
// ============================================================

class ArmConfigurationPage extends StatelessWidget {
  const ArmConfigurationPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(
              Icons.precision_manufacturing_outlined,
              color: tealLight,
              size: 21,
            ),
            SizedBox(width: 10),
            Text(
              'ARM CONFIGURATION',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _intro(),
            const SizedBox(height: 16),
            _title('SERVO CONFIGURATION'),
            const SizedBox(height: 9),
            _servo('01', 'BASE', 'MG995', 'PCA9685 CH0', teal),
            _servo('02', 'SHOULDER', 'MG995', 'PCA9685 CH1', tealLight),
            _servo('03', 'ELBOW', 'MG995', 'PCA9685 CH2', teal),
            _servo('04', 'WRIST', 'MG90S', 'PCA9685 CH3', tealLight),
            _servo('05', 'WRIST ROTATION', 'MG90S', 'PCA9685 CH4', teal),
            _servo('06', 'GRIPPER', 'MG90S', 'PCA9685 CH5', tealLight),
            const SizedBox(height: 8),
            _title('ANGLE RANGE'),
            const SizedBox(height: 9),
            _infoBox(
              '0° – 180°',
              'Configured operating range for each arm servo. Home position is 90° for all six servos.',
              teal,
            ),
            const SizedBox(height: 15),
            _title('ARM PRESETS'),
            const SizedBox(height: 9),
            _presetTable(),
            const SizedBox(height: 15),
            _title('CURRENT / LEGACY COMMAND REFERENCE'),
            const SizedBox(height: 9),
            _commandReference(),
            const SizedBox(height: 15),
            _title('SERVO POWER SAFETY'),
            const SizedBox(height: 9),
            _infoBox(
              'SEPARATE SERVO POWER',
              'The six servos must be powered from a suitable external 5–6V supply/BEC through the PCA9685 V+ and GND. Do not power all six servos directly from the Raspberry Pi 5V pin. Raspberry Pi and servo supply grounds must be common.',
              red,
            ),
          ],
        ),
      ),
    );
  }

  Widget _intro() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '6-AXIS ROBOTIC ARM',
            style: TextStyle(
              color: tealLight,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'GC Bot uses six servos controlled through a PCA9685 servo driver. Three MG995 servos handle the main arm joints and three MG90S servos handle the wrist and gripper section.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _title(String text) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 17,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [tealLight, teal]),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: teal.withOpacity(0.30), blurRadius: 7),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: white,
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  Widget _servo(
    String number,
    String name,
    String model,
    String channel,
    Color color,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(13),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: ProjectHubScreen.smallGlowBox(color),
            child: Text(
              number,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(model, style: const TextStyle(color: grey, fontSize: 10)),
              ],
            ),
          ),
          Text(
            channel,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBox(String title, String text, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            text,
            style: const TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _presetTable() {
    final rows = [
      ['HOME', '90°', '90°', '90°', '90°', '90°', '90°'],
      ['GRAB', '90°', '120°', '60°', '80°', '90°', '30°'],
      ['RELEASE', '90°', '100°', '80°', '90°', '90°', '120°'],
    ];

    const headers = [
      'PRESET',
      'BASE',
      'SHOULDER',
      'ELBOW',
      'WRIST',
      'ROT.',
      'GRIP',
    ];

    return Container(
      width: double.infinity,
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 14,
          headingRowHeight: 42,
          dataRowMinHeight: 42,
          dataRowMaxHeight: 48,
          columns: headers
              .map(
                (header) => DataColumn(
                  label: Text(
                    header,
                    style: const TextStyle(
                      color: tealLight,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
          rows: rows
              .map(
                (row) => DataRow(
                  cells: row
                      .map(
                        (value) => DataCell(
                          Text(
                            value,
                            style: const TextStyle(color: white, fontSize: 10),
                          ),
                        ),
                      )
                      .toList(),
                ),
              )
              .toList(),
        ),
      ),
    );
  }

  Widget _commandReference() {
    final commands = [
      ['B', 'Base angle'],
      ['S', 'Shoulder angle'],
      ['E', 'Elbow angle'],
      ['W', 'Wrist angle'],
      ['R', 'Wrist rotation angle'],
      ['G', 'Gripper angle'],
      ['H', 'Home position'],
      ['T', 'Arm test'],
      ['P', 'Show positions'],
      ['X', 'Emergency stop'],
      ['?', 'Help'],
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: Column(
        children: commands
            .map(
              (command) => Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  children: [
                    Container(
                      width: 30,
                      height: 27,
                      alignment: Alignment.center,
                      decoration: ProjectHubScreen.smallGlowBox(teal),
                      child: Text(
                        command[0],
                        style: const TextStyle(
                          color: tealLight,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      command[1],
                      style: const TextStyle(color: grey, fontSize: 11),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

// ============================================================
// PROJECT DIARY - ACTIVE
// ============================================================

class ProjectDiaryPage extends StatelessWidget {
  const ProjectDiaryPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    final entries = [
      _DiaryEntry(
        '17/08/2026',
        'COMPONENT PURCHASE & TESTING',
        'Purchased the major components required for the GC Bot project. Components were checked individually to ensure they were available and working before assembly.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        '18/08/2026',
        'CAR / MOBILE PLATFORM',
        'The first major project stage was completed: the car/mobile platform was assembled using the chassis, four BO motors, four mecanum wheels, two L298N motor drivers and the Raspberry Pi control system.',
        'COMPLETED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'RASPBERRY PI CONTROL SYSTEM',
        'The Raspberry Pi was prepared as the central controller. Motor control, ultrasonic sensing, camera support and robotic arm control were organized around the Raspberry Pi.',
        'COMPLETED / DEVELOPED',
        tealLight,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'ROBOTIC ARM HARDWARE',
        'The robotic arm system was planned around six servos and a PCA9685 servo driver. Servo channels, home position and grab/release positions were defined.',
        'CONFIGURED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'FLUTTER APP SETUP',
        'The Flutter Android development environment was configured. The GC Bot application project was created and successfully built for the Android phone.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'GC Bot UI',
        'A professional dark robotics interface was developed with Drive, Arm and Project Hub sections. The app includes a splash screen, navigation, movement controls, sensor display areas and arm controls.',
        'COMPLETED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'ARM CONTROL UI',
        'Individual servo controls, home/grab/release presets and press-and-hold movement controls were added to the Arm screen.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        'CURRENT STAGE',
        'PROJECT HUB',
        'Project documentation sections were added inside the application, including hardware, GPIO connections, system working, arm configuration, project diary and future development.',
        'IN DEVELOPMENT',
        teal,
      ),
      _DiaryEntry(
        'NEXT STAGE',
        'HARDWARE + BACKEND INTEGRATION',
        'The next development stage is to connect the Flutter interface to the existing Raspberry Pi server using the exact backend endpoints already implemented on the Raspberry Pi.',
        'PLANNED',
        tealLight,
      ),
      _DiaryEntry(
        'FUTURE',
        'AUTONOMOUS INTELLIGENCE',
        'Future development will focus on AI-based garbage detection, automatic container-full handling, charging station docking and automatic work resumption.',
        'PLANNED',
        teal,
      ),
    ];

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.menu_book_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'PROJECT DIARY',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: entries.length,
        itemBuilder: (context, index) {
          final entry = entries[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: ProjectHubScreen.premiumCard(accent: entry.color),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 4,
                  height: 82,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [entry.color, entry.color.withOpacity(0.35)],
                    ),
                    borderRadius: BorderRadius.circular(5),
                    boxShadow: [
                      BoxShadow(
                        color: entry.color.withOpacity(0.25),
                        blurRadius: 7,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.date,
                        style: TextStyle(
                          color: entry.color,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text('', style: TextStyle(fontSize: 0)),
                      Text(
                        entry.title,
                        style: const TextStyle(
                          color: white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        entry.description,
                        style: const TextStyle(
                          color: grey,
                          fontSize: 11,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: ProjectHubScreen.smallGlowBox(entry.color),
                        child: Text(
                          entry.status,
                          style: TextStyle(
                            color: entry.color,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// FUTURE IMPROVEMENTS - ACTIVE
// ============================================================

class FutureImprovementsPage extends StatelessWidget {
  const FutureImprovementsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.auto_awesome_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'FUTURE IMPROVEMENTS',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _intro(),
            const SizedBox(height: 16),
            _feature(
              '01',
              'AUTOMATIC CONTAINER-FULL DETECTION',
              'Add a sensor or sensing method to determine when the onboard garbage container has reached its full level.',
              Icons.delete_outline,
              teal,
            ),
            _feature(
              '02',
              'AUTOMATIC WASTE-DUMPING LOCATION',
              'When the container becomes full, GC Bot will identify or navigate to a designated emptying location.',
              Icons.location_on_outlined,
              tealLight,
            ),
            _feature(
              '03',
              'AUTOMATIC CONTAINER EMPTYING',
              'At the designated location, the robot will perform an automatic waste-emptying operation so the container becomes ready for further collection.',
              Icons.delete_sweep_outlined,
              teal,
            ),
            _feature(
              '04',
              'RETURN TO WORK',
              'After emptying the container, GC Bot will leave the emptying location and return to its previous work area or continue its assigned route.',
              Icons.keyboard_return,
              tealLight,
            ),
            _feature(
              '05',
              'RASPBERRY PI BATTERY MONITORING',
              'Add automatic battery-voltage monitoring so the system can determine the remaining power level and detect when the battery becomes low.',
              Icons.battery_alert_outlined,
              teal,
            ),
            _feature(
              '06',
              'AUTONOMOUS CHARGING DOCK',
              'When the battery becomes low, GC Bot will navigate toward a designated charging station and align itself with the charging dock.',
              Icons.ev_station_outlined,
              tealLight,
            ),
            _feature(
              '07',
              'AUTOMATIC CHARGING',
              'The robot will remain at the charging station until the battery reaches the required full-charge level.',
              Icons.battery_charging_full,
              teal,
            ),
            _feature(
              '08',
              'UNDOCK & RESUME WORK',
              'After charging is complete, GC Bot will undock, navigate back to its working area and automatically resume its assigned task.',
              Icons.restart_alt,
              tealLight,
            ),
            _feature(
              '09',
              'AI-BASED GARBAGE DETECTION',
              'Improve the camera system with AI/computer vision so different types of garbage can be detected more intelligently.',
              Icons.psychology_outlined,
              teal,
            ),
            const SizedBox(height: 8),
            _workflow(),
          ],
        ),
      ),
    );
  }

  Widget _intro() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PLANNED DEVELOPMENT',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'These features are future improvements. They are planned functionality and are not being presented as already completed hardware features.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _feature(
    String number,
    String title,
    String description,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _workflow() {
    const items = [
      'Container becomes full',
      'Navigate to emptying location',
      'Empty waste container',
      'Return to work',
      'Monitor battery level',
      'Battery becomes low',
      'Navigate to charging station',
      'Charge until full',
      'Undock',
      'Return to work and resume',
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'FUTURE AUTONOMOUS CYCLE',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 12),
          ...List.generate(items.length, (index) {
            final last = index == items.length - 1;

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE6F0E8), Color(0xFFF0F4EB)],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: teal.withOpacity(0.25)),
                        boxShadow: [
                          BoxShadow(
                            color: teal.withOpacity(0.06),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: tealLight,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (!last)
                      Container(
                        width: 1,
                        height: 20,
                        decoration: BoxDecoration(
                          color: teal.withOpacity(0.20),
                          boxShadow: [
                            BoxShadow(
                              color: teal.withOpacity(0.08),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 5, bottom: 11),
                    child: Text(
                      items[index],
                      style: const TextStyle(color: grey, fontSize: 11),
                    ),
                  ),
                ),
              ],
            );
          }),
        ],
      ),
    );
  }
}

// ============================================================
// SOFTWARE & TECHNOLOGIES - LOCKED
// ============================================================

class SoftwareTechnologiesLockedPage extends StatelessWidget {
  const SoftwareTechnologiesLockedPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color grey = ProjectHubScreen.grey;
  static const Color white = ProjectHubScreen.white;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Text(
          'SOFTWARE & TECHNOLOGIES',
          style: TextStyle(
            color: white,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(25),
          decoration: ProjectHubScreen.premiumCard(
            accent: ProjectHubScreen.muted,
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.lock_outline, color: grey, size: 42),
              SizedBox(height: 14),
              Text(
                'SECTION LOCKED',
                style: TextStyle(
                  color: white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 7),
              Text(
                'This section will be activated later.',
                textAlign: TextAlign.center,
                style: TextStyle(color: grey, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SUPPORTING MODELS
// ============================================================

class _WorkStep {
  final String number;
  final String title;
  final String description;
  final IconData icon;
  final Color color;

  const _WorkStep(
    this.number,
    this.title,
    this.description,
    this.icon,
    this.color,
  );
}

class _DiaryEntry {
  final String date;
  final String title;
  final String description;
  final String status;
  final Color color;

  const _DiaryEntry(
    this.date,
    this.title,
    this.description,
    this.status,
    this.color,
  );
}
