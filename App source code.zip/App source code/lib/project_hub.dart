import 'package:flutter/material.dart';

class ProjectHubScreen extends StatelessWidget {
  const ProjectHubScreen({super.key});

  // ============================================================
  // PREMIUM ROBOTICS - DARK BLUE + TEAL GLOW THEME
  // ============================================================

  static const Color bg = Color(0xFFF4F5F0);
  static const Color appBar = Color(0xFFFFFFFF);

  static const Color card = Color(0xFFFFFFFF);
  static const Color card2 = Color(0xFFFAFBF8);

  static const Color teal = Color(0xFF39745C);
  static const Color tealLight = Color(0xFF6F9651);
  static const Color selected = Color(0xFFEAF1E8);

  static const Color border = Color(0xFFE3E8E1);
  static const Color selectedBorder = Color(0xFF39745C);

  static const Color red = Color(0xFFFF4D5A);
  static const Color white = Color(0xFF17241F);
  static const Color grey = Color(0xFF718078);
  static const Color muted = Color(0xFF718078);

  // ============================================================
  // COMMON PREMIUM DECORATIONS
  // ============================================================

  static BoxDecoration premiumCard({
    Color accent = teal,
    bool redAccent = false,
  }) {
    final glow = redAccent ? red : accent;

    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [card2, card, const Color(0xFFF4F5F0)],
      ),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(
        color: glow.withOpacity(redAccent ? 0.28 : 0.20),
        width: 1,
      ),
      boxShadow: [
        BoxShadow(
          color: glow.withOpacity(redAccent ? 0.055 : 0.045),
          blurRadius: 18,
          spreadRadius: 1,
          offset: const Offset(0, 5),
        ),
        const BoxShadow(
          color: Color(0x12000000),
          blurRadius: 8,
          offset: Offset(0, 3),
        ),
      ],
    );
  }

  static BoxDecoration iconBox({Color accent = teal, bool locked = false}) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: locked
            ? [const Color(0xFFF4F5F0), const Color(0xFFFAFBF8)]
            : [accent.withOpacity(0.19), accent.withOpacity(0.055)],
      ),
      borderRadius: BorderRadius.circular(13),
      border: Border.all(
        color:
            locked ? Colors.white.withOpacity(0.06) : accent.withOpacity(0.30),
      ),
      boxShadow: locked
          ? []
          : [
              BoxShadow(
                color: accent.withOpacity(0.075),
                blurRadius: 14,
                spreadRadius: 1,
              ),
            ],
    );
  }

  static BoxDecoration smallGlowBox(Color color) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [color.withOpacity(0.18), color.withOpacity(0.045)],
      ),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color.withOpacity(0.22)),
      boxShadow: [BoxShadow(color: color.withOpacity(0.045), blurRadius: 10)],
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 860),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              const SizedBox(height: 20),
              _sectionTitle('PROJECT INFORMATION'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.smart_toy_outlined,
                  title: 'ABOUT GC-Bot',
                  subtitle: 'Project overview and system architecture',
                  color: teal,
                  onTap: () => _openPage(context, const AboutGCBotPage())),
              _hubCard(
                  icon: Icons.flag_outlined,
                  title: 'PROJECT OBJECTIVES',
                  subtitle: 'Main goals and functions of GC-Bot',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const ProjectObjectivesPage())),
              _hubCard(
                  icon: Icons.memory_outlined,
                  title: 'HARDWARE COMPONENTS',
                  subtitle: 'Components used in the robot',
                  color: tealLight,
                  onTap: () =>
                      _openPage(context, const HardwareComponentsPage())),
              _hubCard(
                  icon: Icons.account_tree_outlined,
                  title: 'CONNECTIONS & GPIO',
                  subtitle: 'Raspberry Pi wiring and GPIO configuration',
                  color: teal,
                  onTap: () => _openPage(context, const ConnectionsPage())),
              const SizedBox(height: 12),
              _sectionTitle('SYSTEM WORKING'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.smart_toy,
                  title: 'AUTONOMOUS WORKING',
                  subtitle: 'Obstacle avoidance and autonomous operation',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const AutonomousWorkingPage())),
              _hubCard(
                  icon: Icons.phone_android,
                  title: 'APP CONTROL / MANUAL WORKING',
                  subtitle: 'Control GC-Bot using the Android application',
                  color: tealLight,
                  onTap: () =>
                      _openPage(context, const AppManualWorkingPage())),
              _hubCard(
                  icon: Icons.hub_outlined,
                  title: 'FULL SYSTEM WORKING',
                  subtitle:
                      'Complete robot operation from detection to collection',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const FullSystemWorkingPage())),
              const SizedBox(height: 12),
              _sectionTitle('PROJECT DEVELOPMENT'),
              const SizedBox(height: 10),
              _hubCard(
                  icon: Icons.precision_manufacturing_outlined,
                  title: 'ARM CONFIGURATION',
                  subtitle:
                      'Robotic arm servo mapping, presets and configuration',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const ArmConfigurationPage())),
              _hubCard(
                  icon: Icons.lock_outline,
                  title: 'SOFTWARE & TECHNOLOGIES',
                  subtitle:
                      'Software architecture and development technologies',
                  color: muted,
                  locked: true),
              _hubCard(
                  icon: Icons.menu_book_outlined,
                  title: 'PROJECT DIARY',
                  subtitle: 'Development progress and project timeline',
                  color: tealLight,
                  onTap: () => _openPage(context, const ProjectDiaryPage())),
              _hubCard(
                  icon: Icons.auto_awesome_outlined,
                  title: 'FUTURE IMPROVEMENTS',
                  subtitle: 'Planned intelligent features and future upgrades',
                  color: teal,
                  onTap: () =>
                      _openPage(context, const FutureImprovementsPage())),
              const SizedBox(height: 18),
              _footer(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF0F4EB), Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
        ),
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: teal.withOpacity(0.30)),
        boxShadow: [
          BoxShadow(
            color: teal.withOpacity(0.09),
            blurRadius: 22,
            spreadRadius: 1,
          ),
          const BoxShadow(
            color: Color(0x18000000),
            blurRadius: 12,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 53,
            height: 53,
            decoration: iconBox(accent: teal),
            child: const Icon(
              Icons.settings_input_component,
              color: tealLight,
              size: 27,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'GC-Bot PROJECT HUB',
                  style: TextStyle(
                    color: white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Explore the robot, hardware, working system and development.',
                  style: TextStyle(color: grey, fontSize: 12, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 19,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [tealLight, teal],
            ),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: teal.withOpacity(0.35), blurRadius: 8),
            ],
          ),
        ),
        const SizedBox(width: 9),
        Text(
          title,
          style: const TextStyle(
            color: white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _hubCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    VoidCallback? onTap,
    bool locked = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: locked ? null : onTap,
          borderRadius: BorderRadius.circular(16),
          splashColor: teal.withOpacity(0.10),
          highlightColor: teal.withOpacity(0.055),
          hoverColor: teal.withOpacity(0.035),
          child: Ink(
            decoration: premiumCard(accent: locked ? muted : color),
            child: Container(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  Container(
                    width: 47,
                    height: 47,
                    decoration: iconBox(
                      accent: locked ? muted : color,
                      locked: locked,
                    ),
                    child: Icon(icon, color: locked ? muted : color, size: 23),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                title,
                                style: TextStyle(
                                  color: locked ? muted : white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            if (locked)
                              const Icon(Icons.lock, color: muted, size: 16),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: locked ? muted.withOpacity(0.65) : grey,
                            fontSize: 11,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!locked)
                    Icon(
                      Icons.chevron_right,
                      color: tealLight.withOpacity(0.85),
                      size: 23,
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _footer() {
    return Center(
      child: Column(
        children: [
          Container(
            width: 45,
            height: 45,
            decoration: iconBox(accent: teal),
            child: const Icon(
              Icons.smart_toy_outlined,
              color: tealLight,
              size: 25,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'GC-Bot',
            style: TextStyle(
              color: white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            'AI-Based Autonomous Garbage Collection Robot',
            textAlign: TextAlign.center,
            style: TextStyle(color: grey.withOpacity(0.8), fontSize: 10),
          ),
        ],
      ),
    );
  }

  void _openPage(BuildContext context, Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}

// ============================================================
// ABOUT GC-Bot
// ============================================================

class AboutGCBotPage extends StatelessWidget {
  const AboutGCBotPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return _standardPage(context, 'ABOUT GC-Bot', Icons.smart_toy_outlined, [
      _infoCard(
        'PROJECT',
        'GC-Bot is an AI-Based Autonomous Garbage Collection Robot designed to identify, collect and manage garbage using a mobile robotic platform, robotic arm, sensors and camera.',
        teal,
      ),
      _infoCard(
        'MAIN PLATFORM',
        'The robot uses four BO motors with mecanum wheels, two L298N motor drivers and a Raspberry Pi 4 Model B as the main control computer.',
        tealLight,
      ),
      _infoCard(
        'ROBOTIC ARM',
        'A six-servo robotic arm is used to pick garbage and transfer it into the waste container mounted on the robot.',
        teal,
      ),
      _infoCard(
        'VISION & SENSING',
        'A USB camera provides visual input while front and rear ultrasonic sensors provide distance information for obstacle awareness.',
        tealLight,
      ),
      _infoCard(
        'CONTROL',
        'The Android GC-Bot application is being developed as the professional control interface for manual operation, monitoring and future autonomous functions.',
        teal,
      ),
    ]);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.7,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(children: children),
      ),
    );
  }

  Widget _infoCard(String title, String text, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 9),
          Text(
            text,
            style: const TextStyle(color: grey, fontSize: 12, height: 1.55),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// PROJECT OBJECTIVES
// ============================================================

class ProjectObjectivesPage extends StatelessWidget {
  const ProjectObjectivesPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return _standardPage(context, 'PROJECT OBJECTIVES', Icons.flag_outlined, [
      _objective(
        '01',
        'AUTONOMOUS MOVEMENT',
        'Enable GC-Bot to navigate the working area with minimum human intervention.',
        teal,
      ),
      _objective(
        '02',
        'GARBAGE DETECTION',
        'Use the camera and future AI vision processing to identify garbage that needs to be collected.',
        tealLight,
      ),
      _objective(
        '03',
        'GARBAGE COLLECTION',
        'Use the robotic arm to pick detected garbage and place it inside the onboard waste container.',
        teal,
      ),
      _objective(
        '04',
        'OBSTACLE AVOIDANCE',
        'Use ultrasonic distance sensors to detect obstacles and improve safe navigation.',
        tealLight,
      ),
      _objective(
        '05',
        'MOBILE CONTROL',
        'Provide a professional Android interface for manual driving, arm control and system monitoring.',
        teal,
      ),
      _objective(
        '06',
        'FUTURE AUTONOMY',
        'Develop automatic container management, battery monitoring, charging and work-resume functions.',
        tealLight,
      ),
    ]);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<Widget> children,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(children: children),
      ),
    );
  }

  Widget _objective(
    String number,
    String title,
    String description,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: ProjectHubScreen.smallGlowBox(color),
            child: Text(
              number,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// HARDWARE COMPONENTS
// ============================================================

class HardwareComponentsPage extends StatelessWidget {
  const HardwareComponentsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    final components = [
      ['Raspberry Pi 4 Model B', '1 unit'],
      ['Raspberry Pi USB 2.0 Camera', '1 unit'],
      ['SD Card', '1 unit'],
      ['BO Motors', '4 units'],
      ['Mecanum Wheels', '4 units'],
      ['L298N Motor Drivers', '2 units'],
      ['3S 12V Lithium-Ion Batteries', '3 units'],
      ['Lithium-Ion Charger', '1 unit'],
      ['Wooden Board Chassis', '1 unit'],
      ['3D-Printed Robotic Arm', '1 unit'],
      ['MG995 Servo Motors', '3 units'],
      ['MG90S Servo Motors', '3 units'],
      ['Buck Converter', '1 unit'],
      ['PCA9685 Servo Driver', '1 unit'],
      ['HC-SR04 Ultrasonic Sensors', '2 units'],
      ['1 kΩ Resistors (voltage divider)', '4 units'],
      ['Jumper Wires', 'As required'],
      ['Switches', '4 units'],
      ['Cooling Fans', '2 units'],
    ];

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.memory_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'HARDWARE COMPONENTS',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: components.length,
        itemBuilder: (context, index) {
          final item = components[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 9),
            padding: const EdgeInsets.all(14),
            decoration: ProjectHubScreen.premiumCard(
              accent: index.isEven ? teal : tealLight,
            ),
            child: Row(
              children: [
                Container(
                  width: 39,
                  height: 39,
                  decoration: ProjectHubScreen.smallGlowBox(
                    index.isEven ? teal : tealLight,
                  ),
                  child: const Icon(
                    Icons.check_circle_outline,
                    color: tealLight,
                    size: 21,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item[0],
                    style: const TextStyle(
                      color: white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Text(
                  item[1],
                  style: const TextStyle(color: grey, fontSize: 11),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// CONNECTIONS & GPIO
// ============================================================

class ConnectionsPage extends StatelessWidget {
  const ConnectionsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.account_tree_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'CONNECTIONS & GPIO',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _group('L298N MOTOR DRIVER #1 — LEFT SIDE', teal, [
              'FL motor → OUT1 / OUT2 → IN1 GPIO17, IN2 GPIO27',
              'RL motor → OUT3 / OUT4 → IN3 GPIO10, IN4 GPIO24',
              'ENA → GPIO18 (physical Pin 12)',
              'ENB → GPIO19 (physical Pin 35)',
            ]),
            _group('L298N MOTOR DRIVER #2 — RIGHT SIDE', tealLight, [
              'FR motor → OUT1 / OUT2 → IN1 GPIO5, IN2 GPIO6',
              'RR motor → OUT3 / OUT4 → IN3 GPIO13, IN4 GPIO26',
              'ENA → GPIO20 (physical Pin 38)',
              'ENB → GPIO21 (physical Pin 40)',
            ]),
            _group('ULTRASONIC SENSORS', teal, [
              'Front HC-SR04 → TRIG GPIO9, ECHO GPIO25',
              'Rear HC-SR04 → TRIG GPIO16, ECHO GPIO12',
              'Echo signals use a voltage divider before Raspberry Pi GPIO',
            ]),
            _group('PCA9685 SERVO DRIVER', tealLight, [
              'VCC → Raspberry Pi 3.3V',
              'GND → Raspberry Pi GND',
              'SDA → GPIO2',
              'SCL → GPIO3',
              'I2C address → 0x40',
            ]),
            _group('SERVO CHANNELS', teal, [
              'CH0 → Base → MG995',
              'CH1 → Shoulder → MG995',
              'CH2 → Elbow → MG995',
              'CH3 → Wrist → MG90S',
              'CH4 → Wrist Rotation → MG90S',
              'CH5 → Gripper → MG90S',
            ]),
            _group('COOLING FANS — PARALLEL CONNECTION', tealLight, [
              'Connect Fan 1 positive to Fan 2 positive (shared + line).',
              'Connect Fan 1 negative to Fan 2 negative (shared − line).',
              'Battery negative → shared fan negative line.',
              'Battery positive → one switch → shared fan positive line.',
            ]),
            _group('POWER & SAFETY', red, [
              'Motor batteries supply the L298N motor drivers.',
              'Raspberry Pi uses a proper USB-C power supply.',
              'Servo power uses a separate suitable 5–6V supply/BEC.',
              'All grounds must be common.',
              'Never connect motor battery voltage directly to Raspberry Pi 5V.',
              'Physical emergency stop is placed in the motor battery positive line.',
            ]),
          ],
        ),
      ),
    );
  }

  Widget _group(String title, Color color, List<String> lines) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 11),
          ...lines.map(
            (line) => Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• ', style: TextStyle(color: color, fontSize: 12)),
                  Expanded(
                    child: Text(
                      line,
                      style: const TextStyle(
                        color: grey,
                        fontSize: 11,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// AUTONOMOUS WORKING
// ============================================================

class AutonomousWorkingPage extends StatelessWidget {
  const AutonomousWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    const steps = [
      _WorkStep(
        '01',
        'START',
        'GC-Bot starts its autonomous operating mode.',
        Icons.power_settings_new,
        teal,
      ),
      _WorkStep(
        '02',
        'SENSE',
        'Ultrasonic sensors continuously monitor the surrounding area.',
        Icons.radar,
        tealLight,
      ),
      _WorkStep(
        '03',
        'DETECT',
        'The camera can provide visual information for future AI-based garbage detection.',
        Icons.camera_alt_outlined,
        teal,
      ),
      _WorkStep(
        '04',
        'NAVIGATE',
        'The mecanum drive platform moves through the working area while responding to obstacles.',
        Icons.navigation_outlined,
        tealLight,
      ),
      _WorkStep(
        '05',
        'COLLECT',
        'The robotic arm picks the detected garbage and transfers it into the onboard container.',
        Icons.precision_manufacturing_outlined,
        teal,
      ),
      _WorkStep(
        '06',
        'CONTINUE',
        'The robot continues searching and collecting according to the autonomous control logic.',
        Icons.autorenew,
        tealLight,
      ),
    ];

    return _standardPage(context, 'AUTONOMOUS WORKING', Icons.smart_toy, steps);
  }

  Widget _standardPage(
    BuildContext context,
    String title,
    IconData icon,
    List<_WorkStep> steps,
  ) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: Row(
          children: [
            Icon(icon, color: tealLight, size: 21),
            const SizedBox(width: 10),
            Text(
              title,
              style: const TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: steps.length,
        itemBuilder: (context, index) {
          final step = steps[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 11),
            padding: const EdgeInsets.all(15),
            decoration: ProjectHubScreen.premiumCard(accent: step.color),
            child: Row(
              children: [
                Container(
                  width: 45,
                  height: 45,
                  decoration: ProjectHubScreen.iconBox(accent: step.color),
                  child: Icon(step.icon, color: step.color, size: 22),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            step.number,
                            style: TextStyle(
                              color: step.color,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            step.title,
                            style: const TextStyle(
                              color: white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        step.description,
                        style: const TextStyle(
                          color: grey,
                          fontSize: 11,
                          height: 1.45,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// APP CONTROL / MANUAL WORKING
// ============================================================

class AppManualWorkingPage extends StatelessWidget {
  const AppManualWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.phone_android, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'APP CONTROL / MANUAL',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _step(
              '01',
              'CONNECT',
              'The Android GC-Bot application communicates with the Raspberry Pi through the local Wi-Fi network.',
              Icons.wifi,
              teal,
            ),
            _step(
              '02',
              'DRIVE',
              'The DRIVE screen provides forward, backward, left, right and rotation controls for the mecanum wheel platform.',
              Icons.gamepad_outlined,
              tealLight,
            ),
            _step(
              '03',
              'MONITOR',
              'The application can display camera and sensor information received from the robot.',
              Icons.monitor_outlined,
              teal,
            ),
            _step(
              '04',
              'ARM',
              'The ARM screen provides individual servo control, home position and grab/release presets.',
              Icons.precision_manufacturing_outlined,
              tealLight,
            ),
            _step(
              '05',
              'EMERGENCY STOP',
              'The software emergency stop is available from the control screens. A physical emergency stop is also part of the robot safety design.',
              Icons.warning_amber_rounded,
              red,
            ),
            _serverCard(),
          ],
        ),
      ),
    );
  }

  Widget _step(
    String number,
    String title,
    String text,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 23),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  text,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _serverCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CURRENT RASPBERRY PI SERVER',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          SizedBox(height: 9),
          Text(
            '192.168.1.32:5000',
            style: TextStyle(
              color: white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'This is the current Raspberry Pi server address used during project development. The Flutter app backend integration will be connected in the next development stage.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.45),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// FULL SYSTEM WORKING
// ============================================================

class FullSystemWorkingPage extends StatelessWidget {
  const FullSystemWorkingPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.hub_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'FULL SYSTEM WORKING',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _systemStep(
              '01',
              'POWER & INITIALIZATION',
              'Raspberry Pi, motor drivers, sensors, camera and robotic arm control system are initialized.',
              Icons.power,
              teal,
            ),
            _systemStep(
              '02',
              'MOBILE PLATFORM',
              'The four mecanum wheels provide movement in forward, backward, sideways and rotational directions.',
              Icons.directions_car_filled_outlined,
              tealLight,
            ),
            _systemStep(
              '03',
              'ENVIRONMENT SENSING',
              'Front and rear ultrasonic sensors monitor distances around the robot for obstacle awareness.',
              Icons.radar,
              teal,
            ),
            _systemStep(
              '04',
              'GARBAGE DETECTION',
              'The USB camera provides visual information for garbage detection and future AI processing.',
              Icons.camera_alt_outlined,
              tealLight,
            ),
            _systemStep(
              '05',
              'ROBOTIC ARM',
              'The robotic arm moves to the required position and picks the garbage.',
              Icons.precision_manufacturing_outlined,
              teal,
            ),
            _systemStep(
              '06',
              'WASTE CONTAINER',
              'The physical waste container is mounted behind the robotic arm. The arm transfers collected garbage into this container.',
              Icons.delete_outline,
              tealLight,
            ),
            _systemStep(
              '07',
              'CONTINUOUS OPERATION',
              'The complete system is intended to continue detecting, navigating and collecting garbage as part of the autonomous working cycle.',
              Icons.autorenew,
              teal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _systemStep(
    String number,
    String title,
    String text,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  text,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// ARM CONFIGURATION - ACTIVE
// ============================================================

class ArmConfigurationPage extends StatelessWidget {
  const ArmConfigurationPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color red = ProjectHubScreen.red;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(
              Icons.precision_manufacturing_outlined,
              color: tealLight,
              size: 21,
            ),
            SizedBox(width: 10),
            Text(
              'ARM CONFIGURATION',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _intro(),
            const SizedBox(height: 16),
            _title('SERVO CONFIGURATION'),
            const SizedBox(height: 9),
            _servo('01', 'BASE', 'MG995', 'PCA9685 CH0', teal),
            _servo('02', 'SHOULDER', 'MG995', 'PCA9685 CH1', tealLight),
            _servo('03', 'ELBOW', 'MG995', 'PCA9685 CH2', teal),
            _servo('04', 'WRIST', 'MG90S', 'PCA9685 CH3', tealLight),
            _servo('05', 'WRIST ROTATION', 'MG90S', 'PCA9685 CH4', teal),
            _servo('06', 'GRIPPER', 'MG90S', 'PCA9685 CH5', tealLight),
            const SizedBox(height: 8),
            _title('ANGLE RANGE'),
            const SizedBox(height: 9),
            _infoBox(
              '0° – 180°',
              'Configured operating range for each arm servo. Home position is 90° for all six servos.',
              teal,
            ),
            const SizedBox(height: 15),
            _title('ARM PRESETS'),
            const SizedBox(height: 9),
            _presetTable(),
            const SizedBox(height: 15),
            _title('CURRENT / LEGACY COMMAND REFERENCE'),
            const SizedBox(height: 9),
            _commandReference(),
            const SizedBox(height: 15),
            _title('SERVO POWER SAFETY'),
            const SizedBox(height: 9),
            _infoBox(
              'SEPARATE SERVO POWER',
              'The six servos must be powered from a suitable external 5–6V supply/BEC through the PCA9685 V+ and GND. Do not power all six servos directly from the Raspberry Pi 5V pin. Raspberry Pi and servo supply grounds must be common.',
              red,
            ),
          ],
        ),
      ),
    );
  }

  Widget _intro() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '6-AXIS ROBOTIC ARM',
            style: TextStyle(
              color: tealLight,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'GC-Bot uses six servos controlled through a PCA9685 servo driver. Three MG995 servos handle the main arm joints and three MG90S servos handle the wrist and gripper section.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _title(String text) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 17,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [tealLight, teal]),
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(color: teal.withOpacity(0.30), blurRadius: 7),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: white,
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  Widget _servo(
    String number,
    String name,
    String model,
    String channel,
    Color color,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(13),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: ProjectHubScreen.smallGlowBox(color),
            child: Text(
              number,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(model, style: const TextStyle(color: grey, fontSize: 10)),
              ],
            ),
          ),
          Text(
            channel,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoBox(String title, String text, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(
        accent: color,
        redAccent: color == red,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            text,
            style: const TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _presetTable() {
    final rows = [
      ['HOME', '90°', '90°', '90°', '90°', '90°', '90°'],
      ['GRAB', '90°', '120°', '60°', '80°', '90°', '30°'],
      ['RELEASE', '90°', '100°', '80°', '90°', '90°', '120°'],
    ];

    const headers = [
      'PRESET',
      'BASE',
      'SHOULDER',
      'ELBOW',
      'WRIST',
      'ROT.',
      'GRIP',
    ];

    return Container(
      width: double.infinity,
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 14,
          headingRowHeight: 42,
          dataRowMinHeight: 42,
          dataRowMaxHeight: 48,
          columns: headers
              .map(
                (header) => DataColumn(
                  label: Text(
                    header,
                    style: const TextStyle(
                      color: tealLight,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
          rows: rows
              .map(
                (row) => DataRow(
                  cells: row
                      .map(
                        (value) => DataCell(
                          Text(
                            value,
                            style: const TextStyle(color: white, fontSize: 10),
                          ),
                        ),
                      )
                      .toList(),
                ),
              )
              .toList(),
        ),
      ),
    );
  }

  Widget _commandReference() {
    final commands = [
      ['B', 'Base angle'],
      ['S', 'Shoulder angle'],
      ['E', 'Elbow angle'],
      ['W', 'Wrist angle'],
      ['R', 'Wrist rotation angle'],
      ['G', 'Gripper angle'],
      ['H', 'Home position'],
      ['T', 'Arm test'],
      ['P', 'Show positions'],
      ['X', 'Emergency stop'],
      ['?', 'Help'],
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: Column(
        children: commands
            .map(
              (command) => Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  children: [
                    Container(
                      width: 30,
                      height: 27,
                      alignment: Alignment.center,
                      decoration: ProjectHubScreen.smallGlowBox(teal),
                      child: Text(
                        command[0],
                        style: const TextStyle(
                          color: tealLight,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      command[1],
                      style: const TextStyle(color: grey, fontSize: 11),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}

// ============================================================
// PROJECT DIARY - ACTIVE
// ============================================================

class ProjectDiaryPage extends StatelessWidget {
  const ProjectDiaryPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    final entries = [
      _DiaryEntry(
        '17/08/2026',
        'COMPONENT PURCHASE & TESTING',
        'Purchased the major components required for the GC-Bot project. Components were checked individually to ensure they were available and working before assembly.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        '18/08/2026',
        'CAR / MOBILE PLATFORM',
        'The first major project stage was completed: the car/mobile platform was assembled using the chassis, four BO motors, four mecanum wheels, two L298N motor drivers and the Raspberry Pi control system.',
        'COMPLETED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'RASPBERRY PI CONTROL SYSTEM',
        'The Raspberry Pi was prepared as the central controller. Motor control, ultrasonic sensing, camera support and robotic arm control were organized around the Raspberry Pi.',
        'COMPLETED / DEVELOPED',
        tealLight,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'ROBOTIC ARM HARDWARE',
        'The robotic arm system was planned around six servos and a PCA9685 servo driver. Servo channels, home position and grab/release positions were defined.',
        'CONFIGURED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'FLUTTER APP SETUP',
        'The Flutter Android development environment was configured. The GC-Bot application project was created and successfully built for the Android phone.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'GC-Bot UI',
        'A professional dark robotics interface was developed with Drive, Arm and Project Hub sections. The app includes a splash screen, navigation, movement controls, sensor display areas and arm controls.',
        'COMPLETED',
        teal,
      ),
      _DiaryEntry(
        'DEVELOPMENT',
        'ARM CONTROL UI',
        'Individual servo controls, home/grab/release presets and press-and-hold movement controls were added to the Arm screen.',
        'COMPLETED',
        tealLight,
      ),
      _DiaryEntry(
        'CURRENT STAGE',
        'PROJECT HUB',
        'Project documentation sections were added inside the application, including hardware, GPIO connections, system working, arm configuration, project diary and future development.',
        'IN DEVELOPMENT',
        teal,
      ),
      _DiaryEntry(
        'NEXT STAGE',
        'HARDWARE + BACKEND INTEGRATION',
        'The next development stage is to connect the Flutter interface to the existing Raspberry Pi server using the exact backend endpoints already implemented on the Raspberry Pi.',
        'PLANNED',
        tealLight,
      ),
      _DiaryEntry(
        'FUTURE',
        'AUTONOMOUS INTELLIGENCE',
        'Future development will focus on AI-based garbage detection, automatic container-full handling, charging station docking and automatic work resumption.',
        'PLANNED',
        teal,
      ),
    ];

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.menu_book_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'PROJECT DIARY',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        itemCount: entries.length,
        itemBuilder: (context, index) {
          final entry = entries[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: ProjectHubScreen.premiumCard(accent: entry.color),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 4,
                  height: 82,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [entry.color, entry.color.withOpacity(0.35)],
                    ),
                    borderRadius: BorderRadius.circular(5),
                    boxShadow: [
                      BoxShadow(
                        color: entry.color.withOpacity(0.25),
                        blurRadius: 7,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.date,
                        style: TextStyle(
                          color: entry.color,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text('', style: TextStyle(fontSize: 0)),
                      Text(
                        entry.title,
                        style: const TextStyle(
                          color: white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        entry.description,
                        style: const TextStyle(
                          color: grey,
                          fontSize: 11,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: ProjectHubScreen.smallGlowBox(entry.color),
                        child: Text(
                          entry.status,
                          style: TextStyle(
                            color: entry.color,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// FUTURE IMPROVEMENTS - ACTIVE
// ============================================================

class FutureImprovementsPage extends StatelessWidget {
  const FutureImprovementsPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color teal = ProjectHubScreen.teal;
  static const Color tealLight = ProjectHubScreen.tealLight;
  static const Color white = ProjectHubScreen.white;
  static const Color grey = ProjectHubScreen.grey;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Row(
          children: [
            Icon(Icons.auto_awesome_outlined, color: tealLight, size: 21),
            SizedBox(width: 10),
            Text(
              'FUTURE IMPROVEMENTS',
              style: TextStyle(
                color: white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
        child: Column(
          children: [
            _intro(),
            const SizedBox(height: 16),
            _feature(
              '01',
              'AUTOMATIC CONTAINER-FULL DETECTION',
              'Add a sensor or sensing method to determine when the onboard garbage container has reached its full level.',
              Icons.delete_outline,
              teal,
            ),
            _feature(
              '02',
              'AUTOMATIC WASTE-DUMPING LOCATION',
              'When the container becomes full, GC-Bot will identify or navigate to a designated emptying location.',
              Icons.location_on_outlined,
              tealLight,
            ),
            _feature(
              '03',
              'AUTOMATIC CONTAINER EMPTYING',
              'At the designated location, the robot will perform an automatic waste-emptying operation so the container becomes ready for further collection.',
              Icons.delete_sweep_outlined,
              teal,
            ),
            _feature(
              '04',
              'RETURN TO WORK',
              'After emptying the container, GC-Bot will leave the emptying location and return to its previous work area or continue its assigned route.',
              Icons.keyboard_return,
              tealLight,
            ),
            _feature(
              '05',
              'RASPBERRY PI BATTERY MONITORING',
              'Add automatic battery-voltage monitoring so the system can determine the remaining power level and detect when the battery becomes low.',
              Icons.battery_alert_outlined,
              teal,
            ),
            _feature(
              '06',
              'AUTONOMOUS CHARGING DOCK',
              'When the battery becomes low, GC-Bot will navigate toward a designated charging station and align itself with the charging dock.',
              Icons.ev_station_outlined,
              tealLight,
            ),
            _feature(
              '07',
              'AUTOMATIC CHARGING',
              'The robot will remain at the charging station until the battery reaches the required full-charge level.',
              Icons.battery_charging_full,
              teal,
            ),
            _feature(
              '08',
              'UNDOCK & RESUME WORK',
              'After charging is complete, GC-Bot will undock, navigate back to its working area and automatically resume its assigned task.',
              Icons.restart_alt,
              tealLight,
            ),
            _feature(
              '09',
              'AI-BASED GARBAGE DETECTION',
              'Improve the camera system with AI/computer vision so different types of garbage can be detected more intelligently.',
              Icons.psychology_outlined,
              teal,
            ),
            const SizedBox(height: 8),
            _workflow(),
          ],
        ),
      ),
    );
  }

  Widget _intro() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PLANNED DEVELOPMENT',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'These features are future improvements. They are planned functionality and are not being presented as already completed hardware features.',
            style: TextStyle(color: grey, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _feature(
    String number,
    String title,
    String description,
    IconData icon,
    Color color,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 11),
      padding: const EdgeInsets.all(15),
      decoration: ProjectHubScreen.premiumCard(accent: color),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: ProjectHubScreen.iconBox(accent: color),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$number  $title',
                  style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  description,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _workflow() {
    const items = [
      'Container becomes full',
      'Navigate to emptying location',
      'Empty waste container',
      'Return to work',
      'Monitor battery level',
      'Battery becomes low',
      'Navigate to charging station',
      'Charge until full',
      'Undock',
      'Return to work and resume',
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: ProjectHubScreen.premiumCard(accent: teal),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'FUTURE AUTONOMOUS CYCLE',
            style: TextStyle(
              color: tealLight,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 12),
          ...List.generate(items.length, (index) {
            final last = index == items.length - 1;

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 25,
                      height: 25,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE6F0E8), Color(0xFFF0F4EB)],
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(color: teal.withOpacity(0.25)),
                        boxShadow: [
                          BoxShadow(
                            color: teal.withOpacity(0.06),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: tealLight,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (!last)
                      Container(
                        width: 1,
                        height: 20,
                        decoration: BoxDecoration(
                          color: teal.withOpacity(0.20),
                          boxShadow: [
                            BoxShadow(
                              color: teal.withOpacity(0.08),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 5, bottom: 11),
                    child: Text(
                      items[index],
                      style: const TextStyle(color: grey, fontSize: 11),
                    ),
                  ),
                ),
              ],
            );
          }),
        ],
      ),
    );
  }
}

// ============================================================
// SOFTWARE & TECHNOLOGIES - LOCKED
// ============================================================

class SoftwareTechnologiesLockedPage extends StatelessWidget {
  const SoftwareTechnologiesLockedPage({super.key});

  static const Color bg = ProjectHubScreen.bg;
  static const Color appBar = ProjectHubScreen.appBar;
  static const Color card = ProjectHubScreen.card;
  static const Color grey = ProjectHubScreen.grey;
  static const Color white = ProjectHubScreen.white;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: appBar,
        elevation: 0,
        scrolledUnderElevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF4F5F0)],
            ),
          ),
        ),
        title: const Text(
          'SOFTWARE & TECHNOLOGIES',
          style: TextStyle(
            color: white,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(25),
          decoration: ProjectHubScreen.premiumCard(
            accent: ProjectHubScreen.muted,
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.lock_outline, color: grey, size: 42),
              SizedBox(height: 14),
              Text(
                'SECTION LOCKED',
                style: TextStyle(
                  color: white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 7),
              Text(
                'This section will be activated later.',
                textAlign: TextAlign.center,
                style: TextStyle(color: grey, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SUPPORTING MODELS
// ============================================================

class _WorkStep {
  final String number;
  final String title;
  final String description;
  final IconData icon;
  final Color color;

  const _WorkStep(
    this.number,
    this.title,
    this.description,
    this.icon,
    this.color,
  );
}

class _DiaryEntry {
  final String date;
  final String title;
  final String description;
  final String status;
  final Color color;

  const _DiaryEntry(
    this.date,
    this.title,
    this.description,
    this.status,
    this.color,
  );
}
