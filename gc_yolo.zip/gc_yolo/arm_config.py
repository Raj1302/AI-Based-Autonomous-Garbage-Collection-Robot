"""Arm configuration. Populate physical values only after measurement/verification."""
from pathlib import Path

ARM_CAMERA_DEVICE = "/dev/video2"
ARM_CAMERA_WIDTH = 640
ARM_CAMERA_HEIGHT = 480
ARM_CAMERA_FPS = 30
# User-specified PCA9685 channel names/mapping. Wiring still requires confirmation.
SERVO_CHANNELS = {
    "base_rotation": 0, "shoulder": 1, "elbow": 2,
    "wrist": 3, "wrist_rotation": 4, "gripper": 5,
}
# These remain unset until verified on the physical mechanism.
LINK_LENGTHS_MM = None
JOINT_OFFSETS_DEG = None
SERVO_DIRECTIONS = None
NEUTRAL_ANGLES_DEG = None
SAFE_LIMITS_DEG = None
GRIPPER_ACTION = None
START_POSE_VERIFIED = False
CAMERA_CALIBRATION = None
WIRING_VERIFIED = False
POWER_VERIFIED = False
CALIBRATION_VERIFIED = False
REAL_MOVEMENT_ENABLED = False
DRY_RUN = True
MAX_RETRIES = 1
MAX_JOINT_STEP_DEG = None
SETTLE_SECONDS = None

def movement_prerequisites():
    required = {
        "PCA9685 and servo wiring/channel confirmation": WIRING_VERIFIED,
        "logic/external servo power and common-ground confirmation": POWER_VERIFIED,
        "arm geometry, offsets, directions, neutral angles, and safe limits": (
            LINK_LENGTHS_MM is not None and JOINT_OFFSETS_DEG is not None
            and SERVO_DIRECTIONS is not None and NEUTRAL_ANGLES_DEG is not None
            and SAFE_LIMITS_DEG is not None
        ),
        "gripper action confirmation": GRIPPER_ACTION is not None,
        "verified known starting pose": START_POSE_VERIFIED,
        "camera-to-arm/target-plane calibration": CAMERA_CALIBRATION is not None,
        "movement calibration sign-off": CALIBRATION_VERIFIED,
    }
    return [name for name, okay in required.items() if not okay]
