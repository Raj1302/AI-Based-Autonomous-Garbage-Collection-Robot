"""One-shot pickup state machine; current archive lacks required calibration."""
from dataclasses import dataclass
import arm_config
from robot.inverse_kinematics import planar_two_link

@dataclass
class PickupResult:
    status: str
    detail: str

class PickupController:
    def __init__(self, dry_run=True):
        self.dry_run = bool(dry_run)
        self.handled = False
    def reset(self):
        """Re-arm the one-shot state after the chassis leaves the stop state."""
        self.handled = False
    def pickup(self, target):
        if self.handled:
            return PickupResult("PICKUP_FAILED", "Stop event already handled")
        self.handled = True
        if not target or not {"center", "box", "class_name"}.issubset(target):
            return PickupResult("PICKUP_FAILED", "Missing valid detection target")
        if self.dry_run:
            print("[PICKUP DRY-RUN] stop event accepted; target metadata:", {
                "class_name": target["class_name"], "confidence": target.get("confidence"),
                "center_px": target["center"], "box_px": target["box"]})
            try:
                planar_two_link(0, 0)
            except ValueError as exc:
                return PickupResult("ARM_ERROR", f"Dry-run safely halted before motion: {exc}; missing: " + "; ".join(arm_config.movement_prerequisites()))
            return PickupResult("ARM_ERROR", "Dry-run only; calibrated target projection is not configured")
        missing = arm_config.movement_prerequisites()
        if missing:
            return PickupResult("ARM_ERROR", "Real movement interlocked; verify: " + "; ".join(missing))
        camera = None
        arm = None
        try:
            from hardware.arm_camera import ArmCamera
            from hardware.arm_controller import ArmController
            from hardware.arm_vision import ArmVision
            camera = ArmCamera()
            camera.read()
            vision = ArmVision(camera)
            vision.estimate_target_in_arm_base(target)
            arm = ArmController(dry_run=False)
            return PickupResult("ARM_ERROR", "No commissioned IK/pickup pose or servo driver")
        except Exception as exc:
            return PickupResult("CAMERA_ERROR" if camera is None else "ARM_ERROR", str(exc))
        finally:
            if arm is not None: arm.close()
            if camera is not None: camera.close()
