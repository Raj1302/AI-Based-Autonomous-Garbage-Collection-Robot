"""Safety-first controller for three-zone target alignment and approach."""
import config


class ApproachController:
    def __init__(self, motors):
        self.motors = motors
        self.missing_frames = 0

    def update(self, target, distance_cm, distance_age_s=0.0):
        if target is None:
            self.missing_frames += 1
            self.motors.stop()
            return "STOPPED: TARGET LOST"

        self.missing_frames = 0

        if distance_cm is None or distance_age_s is None:
            self.motors.stop()
            return "STOPPED: INVALID DISTANCE"

        if distance_age_s > config.ULTRASONIC_MAX_AGE_S:
            self.motors.stop()
            return "STOPPED: STALE DISTANCE"

        if distance_cm <= config.STOP_DISTANCE_CM:
            self.motors.stop()
            return "STOPPED: STOP DISTANCE"

        if distance_cm > config.APPROACH_MAX_DISTANCE_CM:
            self.motors.stop()
            return "STOPPED: OUTSIDE APPROACH RANGE"

        center_x = target["center"][0]
        frame_width = target.get("frame_width", config.CAMERA_WIDTH)
        normalized_x = center_x / max(1, frame_width)

        if normalized_x < config.CENTER_DEADBAND_MIN:
            self.motors.stop()
            if not config.ENABLE_STRAFE:
                return "ALIGN LEFT DISABLED: VERIFY WHEELS"
            self.motors.strafe_left(config.ALIGNMENT_SPEED_PERCENT)
            return "ALIGNING LEFT"

        if normalized_x > config.CENTER_DEADBAND_MAX:
            self.motors.stop()
            if not config.ENABLE_STRAFE:
                return "ALIGN RIGHT DISABLED: VERIFY WHEELS"
            self.motors.strafe_right(config.ALIGNMENT_SPEED_PERCENT)
            return "ALIGNING RIGHT"

        self.motors.forward(config.APPROACH_SPEED_PERCENT)
        return "CENTERED - APPROACHING"
