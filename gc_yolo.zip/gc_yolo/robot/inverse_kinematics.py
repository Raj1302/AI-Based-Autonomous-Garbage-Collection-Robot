"""Parametric planar reach check; refuses to run with unverified geometry."""
import math
import arm_config

class IKError(ValueError):
    pass

def planar_two_link(x_mm, z_mm, link_lengths_mm=None):
    links = link_lengths_mm if link_lengths_mm is not None else arm_config.LINK_LENGTHS_MM
    if not links or len(links) != 2 or any(float(v) <= 0 for v in links):
        raise IKError("IK unavailable: two measured positive link lengths are required")
    a, b = map(float, links)
    d2 = float(x_mm) ** 2 + float(z_mm) ** 2
    c2 = (d2-a*a-b*b)/(2*a*b)
    if c2 < -1.0 or c2 > 1.0:
        raise IKError("Target is outside the measured two-link arm reach")
    c2 = max(-1.0, min(1.0, c2))
    elbow = math.acos(c2)
    shoulder = math.atan2(float(z_mm), float(x_mm)) - math.atan2(b*math.sin(elbow), a+b*math.cos(elbow))
    return {"shoulder": math.degrees(shoulder), "elbow": math.degrees(elbow)}

def validate_joint_targets(targets, limits=None):
    limits = limits if limits is not None else arm_config.SAFE_LIMITS_DEG
    if not limits:
        raise IKError("Joint targets rejected: verified safe joint limits are missing")
    for joint, angle in targets.items():
        if joint not in limits:
            raise IKError(f"Joint target rejected: no verified limit for {joint}")
        lo, hi = limits[joint]
        if not lo <= angle <= hi:
            raise IKError(f"Joint target rejected: {joint}={angle:.2f} outside [{lo}, {hi}]")
    return targets
