"""Three-zone classification and camera overlay for GC-BOT."""
import cv2


def classify_zone(center_x, frame_width):
    """Classify a horizontal coordinate into LEFT, CENTER, or RIGHT thirds."""
    if frame_width <= 0:
        raise ValueError("frame_width must be positive")
    if center_x < frame_width / 3:
        return "LEFT"
    if center_x > 2 * frame_width / 3:
        return "RIGHT"
    return "CENTER"


def draw_zones(frame, active_zone=None, status="SEARCHING", distance_cm=None):
    """Draw three vertical zones and concise robot status on a frame."""
    height, width = frame.shape[:2]
    x1, x2 = width // 3, (2 * width) // 3

    # Neutral divider lines and zone labels.
    cv2.line(frame, (x1, 0), (x1, height), (220, 220, 220), 2)
    cv2.line(frame, (x2, 0), (x2, height), (220, 220, 220), 2)
    labels = [
        ("LEFT", width // 6),
        ("CENTER", width // 2),
        ("RIGHT", (5 * width) // 6),
    ]
    for label, cx in labels:
        color = (0, 255, 255) if label == active_zone else (240, 240, 240)
        cv2.putText(frame, label, (max(5, cx - 40), 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA)

    dist_text = f"{distance_cm:.1f} cm" if distance_cm is not None else "INVALID"
    cv2.rectangle(frame, (0, height - 38), (width, height), (20, 20, 20), -1)
    cv2.putText(frame, f"{status} | FRONT: {dist_text}",
                (10, height - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.52,
                (0, 220, 255), 2, cv2.LINE_AA)
    return frame
