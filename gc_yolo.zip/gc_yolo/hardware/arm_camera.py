"""Arm camera capture. This module opens only /dev/video2 by default."""
import arm_config

class ArmCamera:
    def __init__(self, device=arm_config.ARM_CAMERA_DEVICE):
        if str(device) != arm_config.ARM_CAMERA_DEVICE:
            raise ValueError("ArmCamera is restricted to the configured camera 2 device")
        try:
            import cv2
        except ImportError as exc:
            raise RuntimeError("OpenCV is required for arm camera access") from exc
        self.cv2 = cv2
        self.device = device
        self.cap = self.cv2.VideoCapture(device, self.cv2.CAP_V4L2)
        self.cap.set(self.cv2.CAP_PROP_FRAME_WIDTH, arm_config.ARM_CAMERA_WIDTH)
        self.cap.set(self.cv2.CAP_PROP_FRAME_HEIGHT, arm_config.ARM_CAMERA_HEIGHT)
        self.cap.set(self.cv2.CAP_PROP_FPS, arm_config.ARM_CAMERA_FPS)
        if not self.cap.isOpened():
            self.cap.release()
            raise RuntimeError(f"Could not open arm camera {device}")
    def read(self):
        ok, frame = self.cap.read()
        if not ok or frame is None or frame.size == 0:
            raise RuntimeError(f"No valid frame from arm camera {self.device}")
        return frame
    def close(self):
        self.cap.release()
