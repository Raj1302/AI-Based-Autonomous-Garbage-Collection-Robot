"""Camera feedback placeholder with explicit calibration/evidence requirements."""
import arm_config

class ArmVision:
    def __init__(self, camera):
        self.camera = camera
    def estimate_target_in_arm_base(self, target):
        if arm_config.CAMERA_CALIBRATION is None:
            raise RuntimeError("Camera-to-arm transform, intrinsics/distortion, target plane, and scale are uncalibrated")
        # A target detector/projection is deliberately not fabricated: calibration
        # alone does not define segmentation or a validated pixel-to-plane estimator.
        raise RuntimeError("No validated waste pixel-to-coordinate estimator is configured")
    def observe_pickup(self):
        self.camera.read()
        return {"camera_frame_valid": True, "waste_lifted": None, "securely_held": None}
