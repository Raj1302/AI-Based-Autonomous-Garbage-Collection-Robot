"""Raspberry Pi check: open only /dev/video2 and read valid frames."""
import argparse
from hardware.arm_camera import ArmCamera

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--camera-check", action="store_true", required=True)
    args = parser.parse_args()
    camera = ArmCamera()
    try:
        for index in range(10):
            frame = camera.read()
            print(f"frame {index + 1}: {frame.shape[1]}x{frame.shape[0]} valid")
    finally:
        camera.close()
if __name__ == "__main__": main()
