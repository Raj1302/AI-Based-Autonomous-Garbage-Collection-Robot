
"""HC-SR04-style ultrasonic distance reader for Raspberry Pi."""

import time
import config


class Ultrasonic:
    def __init__(
        self,
        trig_pin=config.FRONT_TRIG_GPIO,
        echo_pin=config.FRONT_ECHO_GPIO,
        simulated=False,
    ):
        self.simulated = simulated
        self.trig_pin = trig_pin
        self.echo_pin = echo_pin
        self.GPIO = None

        if simulated:
            return

        try:
            import RPi.GPIO as GPIO
        except ImportError as exc:
            raise RuntimeError(
                "RPi.GPIO unavailable; run on Raspberry Pi."
            ) from exc

        self.GPIO = GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(trig_pin, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(echo_pin, GPIO.IN)
        time.sleep(0.05)

    def distance_cm(self):
        if self.simulated:
            return None

        GPIO = self.GPIO

        # Send a 10-microsecond trigger pulse.
        GPIO.output(self.trig_pin, GPIO.LOW)
        time.sleep(0.002)
        GPIO.output(self.trig_pin, GPIO.HIGH)
        time.sleep(0.00001)
        GPIO.output(self.trig_pin, GPIO.LOW)

        # Wait for ECHO to rise.
        timeout = time.monotonic() + 0.03

        while GPIO.input(self.echo_pin) == 0:
            if time.monotonic() >= timeout:
                return None

        pulse_start = time.monotonic()

        # Wait for ECHO to fall.
        timeout = pulse_start + 0.03

        while GPIO.input(self.echo_pin) == 1:
            if time.monotonic() >= timeout:
                return None

        pulse_end = time.monotonic()

        distance = (pulse_end - pulse_start) * 17150.0

        if not (
            config.ULTRASONIC_MIN_VALID_CM
            <= distance
            <= config.ULTRASONIC_MAX_VALID_CM
        ):
            return None

        return round(distance, 1)

    def close(self):
        if self.GPIO is not None:
            self.GPIO.cleanup([self.trig_pin, self.echo_pin])
            self.GPIO = None
