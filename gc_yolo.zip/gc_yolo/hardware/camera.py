import cv2
import config

class Camera:
    def __init__(self, index=config.CAMERA_INDEX):
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.CAMERA_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.CAMERA_HEIGHT)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera index {index}")
    def read(self):
        ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("Camera frame read failed")
        return frame
    def close(self):
        self.cap.release()
