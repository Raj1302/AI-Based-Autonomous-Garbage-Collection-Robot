"""PCA9685 output gate. No driver dependency is loaded until all gates pass."""
import arm_config

class ArmController:
    def __init__(self, dry_run=True):
        self.dry_run = bool(dry_run)
        if not self.dry_run:
            missing = arm_config.movement_prerequisites()
            if not arm_config.REAL_MOVEMENT_ENABLED or missing:
                raise RuntimeError("Real arm output locked; verify: " + "; ".join(missing or ["REAL_MOVEMENT_ENABLED sign-off"]))
            # Intentionally no guessed PCA9685/servo driver configuration. Enable only
            # after the precise driver, PWM frequency, pulse mapping, and calibration
            # are supplied and verified in this deployment.
            raise RuntimeError("Real arm output driver is not commissioned")
    def move_joints(self, targets):
        if not self.dry_run:
            raise RuntimeError("Servo output is unavailable until hardware is commissioned")
        print(f"[ARM DRY-RUN] would move through validated targets: {targets}")
    def close(self):
        pass
