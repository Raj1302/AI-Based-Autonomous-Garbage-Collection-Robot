
"""L298N motor controller with PWM speed control for GC-BOT."""

import config


class Motors:
    def __init__(self, simulated=True):
        self.simulated = simulated or not config.ENABLE_REAL_MOTORS
        self.GPIO = None
        self.pwm = {}

        if self.simulated:
            print("[SIMULATION] Motor controller initialized")
            return

        try:
            import RPi.GPIO as GPIO
        except ImportError as exc:
            raise RuntimeError(
                "RPi.GPIO unavailable; cannot control motors"
            ) from exc

        self.GPIO = GPIO

        try:
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)

            # Initialize motor direction pins and PWM enable pins.
            for name, pins in config.MOTOR_PINS.items():
                GPIO.setup(pins["in1"], GPIO.OUT, initial=GPIO.LOW)
                GPIO.setup(pins["in2"], GPIO.OUT, initial=GPIO.LOW)

                enable_pin = config.MOTOR_ENABLE_PINS[name]
                GPIO.setup(enable_pin, GPIO.OUT, initial=GPIO.LOW)

                frequency = getattr(config, "MOTOR_PWM_FREQUENCY", 1000)
                pwm = GPIO.PWM(enable_pin, frequency)
                pwm.start(0)
                self.pwm[name] = pwm

            self.stop()
            print("[HARDWARE] Motor controller initialized")

        except Exception:
            for pwm in self.pwm.values():
                try:
                    pwm.stop()
                except Exception:
                    pass

            GPIO.cleanup()
            raise

    def _set(self, name, forward, speed):
        pins = config.MOTOR_PINS[name]

        if config.MOTOR_INVERT.get(name, False):
            forward = not forward

        speed = max(0, min(100, int(speed)))

        if self.simulated:
            print(
                f"[SIMULATION] {name}: "
                f"{'forward' if forward else 'reverse'}, "
                f"speed={speed}%"
            )
            return

        # Disable PWM before changing direction.
        self.pwm[name].ChangeDutyCycle(0)
        self.GPIO.output(pins["in1"], self.GPIO.LOW)
        self.GPIO.output(pins["in2"], self.GPIO.LOW)

        if speed == 0:
            return

        if forward:
            self.GPIO.output(pins["in1"], self.GPIO.HIGH)
            self.GPIO.output(pins["in2"], self.GPIO.LOW)
        else:
            self.GPIO.output(pins["in1"], self.GPIO.LOW)
            self.GPIO.output(pins["in2"], self.GPIO.HIGH)

        self.pwm[name].ChangeDutyCycle(speed)

    def forward(self, speed=None):
        if speed is None:
            speed = config.MOTOR_SPEED_PERCENT

        for name in config.MOTOR_PINS:
            self._set(name, True, speed)

    def backward(self, speed=None):
        if speed is None:
            speed = config.MOTOR_SPEED_PERCENT

        for name in config.MOTOR_PINS:
            self._set(name, False, speed)

    def _pattern(self, directions, speed):
        """Apply a logical per-wheel direction pattern."""
        for name in config.MOTOR_PINS:
            self._set(name, directions[name], speed)

    def strafe_left(self, speed=None):
        """Standard X-roller mecanum strafe-left pattern; verify wheel layout first."""
        if speed is None:
            speed = config.ALIGNMENT_SPEED_PERCENT
        self._pattern({
            "front_left": False,
            "front_right": True,
            "rear_left": True,
            "rear_right": False,
        }, speed)

    def strafe_right(self, speed=None):
        """Standard X-roller mecanum strafe-right pattern; verify wheel layout first."""
        if speed is None:
            speed = config.ALIGNMENT_SPEED_PERCENT
        self._pattern({
            "front_left": True,
            "front_right": False,
            "rear_left": False,
            "rear_right": True,
        }, speed)

    def stop(self):
        if self.simulated:
            print("[SIMULATION] motors STOP")
            return

        for name, pins in config.MOTOR_PINS.items():
            if name in self.pwm:
                self.pwm[name].ChangeDutyCycle(0)

            self.GPIO.output(pins["in1"], self.GPIO.LOW)
            self.GPIO.output(pins["in2"], self.GPIO.LOW)

    def close(self):
        if self.simulated:
            return

        try:
            self.stop()
        finally:
            try:
                for pwm in self.pwm.values():
                    pwm.stop()
            finally:
                self.GPIO.cleanup()
                self.pwm.clear()
