"""YOLOv8 ONNX inference with single-target selection for GC-BOT.

The ONNX model is unchanged. This module filters weak predictions and returns
at most one target per frame so the preview/controller do not chase multiple
boxes at once. This does not replace training with background/negative images
if the model itself consistently mistakes background for waste.
"""
from pathlib import Path
import cv2
import numpy as np
import onnxruntime as ort
import config


class WasteDetector:
    def __init__(self, model_path=config.MODEL_PATH, confidence=config.CONFIDENCE_THRESHOLD):
        self.model_path = Path(model_path)
        if not self.model_path.is_file():
            raise FileNotFoundError(
                f"ONNX model not found at {self.model_path}. Copy your exported "
                "YOLOv8 model to models/waste_model.onnx."
            )
        self.classes = [x.strip() for x in config.CLASS_PATH.read_text(encoding="utf-8").splitlines() if x.strip()]
        if len(self.classes) != 3:
            raise ValueError(f"Expected 3 class names; got {self.classes}")

        # Raise the effective threshold without editing config.py. This reduces
        # low-confidence background detections; increase further only after testing.
        self.confidence = max(float(confidence), 0.55)
        self.session = ort.InferenceSession(str(self.model_path), providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        shape = self.session.get_inputs()[0].shape
        self.input_h = int(shape[2]) if isinstance(shape[2], int) else config.MODEL_INPUT_HEIGHT
        self.input_w = int(shape[3]) if isinstance(shape[3], int) else config.MODEL_INPUT_WIDTH

    def detect(self, frame):
        """Return [] or a list containing exactly one selected detection."""
        if frame is None or frame.size == 0:
            return []
        h, w = frame.shape[:2]
        scale = min(self.input_w / w, self.input_h / h)
        nw, nh = int(round(w * scale)), int(round(h * scale))
        resized = cv2.resize(frame, (nw, nh))
        canvas = np.full((self.input_h, self.input_w, 3), 114, dtype=np.uint8)
        px, py = (self.input_w - nw) // 2, (self.input_h - nh) // 2
        canvas[py:py+nh, px:px+nw] = resized
        rgb = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)
        tensor = np.transpose(rgb.astype(np.float32) / 255.0, (2, 0, 1))[None]
        raw = self.session.run(None, {self.input_name: tensor})[0]
        pred = np.asarray(raw)[0]
        if pred.ndim != 2:
            raise ValueError(f"Unexpected model output shape: {raw.shape}")
        if pred.shape[0] == 7:
            pred = pred.T
        if pred.shape[1] != 7:
            raise ValueError(f"Expected 7 output values per candidate for 3 classes; got {raw.shape}")

        xywh = pred[:, :4].astype(np.float32)
        class_scores = pred[:, 4:].astype(np.float32)
        class_ids = np.argmax(class_scores, axis=1)
        scores = class_scores[np.arange(len(class_scores)), class_ids]
        selected = scores >= self.confidence
        xywh, scores, class_ids = xywh[selected], scores[selected], class_ids[selected]
        if not len(xywh):
            return []

        boxes = []
        for cx, cy, bw, bh in xywh:
            x1 = (cx - bw/2 - px) / scale
            y1 = (cy - bh/2 - py) / scale
            x2 = (cx + bw/2 - px) / scale
            y2 = (cy + bh/2 - py) / scale
            x1 = int(np.clip(x1, 0, w-1)); x2 = int(np.clip(x2, 0, w-1))
            y1 = int(np.clip(y1, 0, h-1)); y2 = int(np.clip(y2, 0, h-1))
            boxes.append((x1, y1, x2, y2))

        nms_boxes = [[x1, y1, max(0, x2-x1), max(0, y2-y1)] for x1, y1, x2, y2 in boxes]
        indices = cv2.dnn.NMSBoxes(nms_boxes, scores.tolist(), self.confidence, config.NMS_IOU_THRESHOLD)
        results = []
        for idx in np.array(indices).reshape(-1) if len(indices) else []:
            x1, y1, x2, y2 = boxes[int(idx)]
            if x2 <= x1 or y2 <= y1:
                continue
            cid = int(class_ids[int(idx)])
            results.append({
                "class_id": cid, "class_name": self.classes[cid],
                "confidence": float(scores[int(idx)]), "box": (x1, y1, x2, y2),
                "center": ((x1+x2)//2, (y1+y2)//2)
            })

        if not results:
            return []

        # Pick one target: confidence is dominant; a larger, more central box
        # breaks close ties. Frame-relative area makes the score resolution-independent.
        frame_area = max(1, w * h)
        frame_cx = w / 2.0
        half_w = max(1.0, w / 2.0)
        def target_score(d):
            x1, y1, x2, y2 = d["box"]
            area_fraction = max(0, x2-x1) * max(0, y2-y1) / frame_area
            center_offset = abs(d["center"][0] - frame_cx) / half_w
            return d["confidence"] + min(0.08, area_fraction * 0.20) - 0.05 * center_offset

        return [max(results, key=target_score)]


def draw_detections(frame, detections):
    # detect() returns at most one item; retain the list interface for compatibility.
    for d in detections[:1]:
        x1, y1, x2, y2 = d["box"]
        label = f'{d["class_name"]} {d["confidence"]:.2f}'
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 220, 0), 2)
        cv2.putText(frame, label, (x1, max(20, y1-8)), cv2.FONT_HERSHEY_SIMPLEX, .55, (0, 220, 0), 2)
    return frame
