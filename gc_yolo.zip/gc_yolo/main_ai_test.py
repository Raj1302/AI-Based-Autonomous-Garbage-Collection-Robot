"""AI-only camera test. Does not initialize motors or GPIO."""
import argparse
import cv2
from ai.detector import WasteDetector, draw_detections
from hardware.camera import Camera

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--camera", type=int, default=0)
    args = p.parse_args()
    detector = WasteDetector()
    camera = Camera(args.camera)
    try:
        while True:
            frame = camera.read()
            detections = detector.detect(frame)
            draw_detections(frame, detections)
            cv2.imshow("GC-BOT AI test - q to quit", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        camera.close()
        cv2.destroyAllWindows()
if __name__ == "__main__":
    main()
