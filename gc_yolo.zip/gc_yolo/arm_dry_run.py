"""Exercise the stop-to-pickup state machine without camera or hardware access."""
import argparse
from robot.pickup_controller import PickupController

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", required=True)
    args = parser.parse_args()
    event = {"class_id": 0, "class_name": "plastic", "confidence": 0.9,
             "box": (280, 200, 350, 270), "center": (315, 235), "frame_width": 640}
    controller = PickupController(dry_run=True)
    print("State: WAITING_FOR_STOP -> STOP_REPORTED -> PICKUP_GATED")
    result = controller.pickup(event)
    print(f"Result: {result.status}: {result.detail}")
    print("No camera, motors, or servos were opened or activated.")
if __name__ == "__main__": main()
