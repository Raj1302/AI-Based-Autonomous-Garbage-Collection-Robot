import argparse, cv2
from ai.detector import WasteDetector

p = argparse.ArgumentParser()
p.add_argument("images", nargs="+")
p.add_argument("--confidence", type=float, default=0.35)
args = p.parse_args()
detector = WasteDetector(confidence=args.confidence)
for path in args.images:
    image = cv2.imread(path)
    if image is None:
        print(f"{path}: could not read")
        continue
    results = detector.detect(image)
    print(f"\n{path}: {len(results)} detections")
    for d in results:
        print(f"  {d['class_name']} {d['confidence']:.3f} box={d['box']}")
