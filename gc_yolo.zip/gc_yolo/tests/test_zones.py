"""Unit tests for GC-BOT zone classification and safety controller."""
import unittest
from robot.zones import classify_zone
from robot.approach_controller import ApproachController


class FakeMotors:
    def __init__(self):
        self.commands = []
    def stop(self): self.commands.append(("stop",))
    def forward(self, speed): self.commands.append(("forward", speed))
    def strafe_left(self, speed): self.commands.append(("left", speed))
    def strafe_right(self, speed): self.commands.append(("right", speed))


class ZoneTests(unittest.TestCase):
    def test_zone_thirds(self):
        self.assertEqual(classify_zone(10, 640), "LEFT")
        self.assertEqual(classify_zone(320, 640), "CENTER")
        self.assertEqual(classify_zone(630, 640), "RIGHT")

    def test_invalid_distance_stops(self):
        motors = FakeMotors()
        controller = ApproachController(motors)
        target = {"center": (320, 240), "frame_width": 640}
        self.assertEqual(controller.update(target, None, None),
                         "STOPPED: INVALID DISTANCE")
        self.assertEqual(motors.commands[-1], ("stop",))

    def test_stop_distance_stops(self):
        motors = FakeMotors()
        controller = ApproachController(motors)
        target = {"center": (320, 240), "frame_width": 640}
        self.assertEqual(controller.update(target, 10.0, 0.0),
                         "STOPPED: STOP DISTANCE")
        self.assertEqual(motors.commands[-1], ("stop",))


if __name__ == "__main__":
    unittest.main()
