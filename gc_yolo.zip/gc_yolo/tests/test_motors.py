
"""GC-BOT motor test for L298N drivers with PWM enable pins.

Keep all wheels lifted off the floor during testing.
"""

import time
import config
from hardware.motors import Motors


def main():
    if not config.ENABLE_REAL_MOTORS:
        raise SystemExit(
            "Real motors are disabled. Check config.py before testing."
        )

    motors = Motors(simulated=False)

    try:
        input(
            "Lift ALL wheels off the floor and keep motor power "
            "switch reachable. Press Enter to start..."
        )

        speed = min(config.MOTOR_SPEED_PERCENT, 70)

        print(f"FORWARD: {speed}% speed for 2 seconds")
        motors.forward(speed=speed)
        time.sleep(2)
        motors.stop()
        time.sleep(2)

        print(f"BACKWARD: {speed}% speed for 2 seconds")
        motors.backward(speed=speed)
        time.sleep(2)
        motors.stop()
        time.sleep(2)

        print("Motor test complete. Check all four wheel directions.")

    except KeyboardInterrupt:
        print("\nTest interrupted.")

    finally:
        motors.stop()
        motors.close()


if __name__ == "__main__":
    main()
