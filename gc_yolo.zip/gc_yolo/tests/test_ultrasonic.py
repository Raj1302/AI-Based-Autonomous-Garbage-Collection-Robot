
"""Test the front ultrasonic sensor on Raspberry Pi."""

import time
import config
from hardware.ultrasonic import Ultrasonic


def main():
    if not config.ENABLE_REAL_ULTRASONIC:
        raise SystemExit(
            "Ultrasonic disabled. Set ENABLE_REAL_ULTRASONIC=True "
            "only after verifying wiring and ECHO level shifting."
        )

    sensor = Ultrasonic(
        config.FRONT_TRIG_GPIO,
        config.FRONT_ECHO_GPIO,
    )

    valid_readings = 0
    invalid_readings = 0

    try:
        print("Testing FRONT ultrasonic sensor...")
        print(f"TRIG: BCM GPIO {config.FRONT_TRIG_GPIO}")
        print(f"ECHO: BCM GPIO {config.FRONT_ECHO_GPIO}")
        print("Keep a flat object approximately 20-50 cm in front.")
        print("")

        for i in range(20):
            distance = sensor.distance_cm()

            if distance is None:
                invalid_readings += 1
                print(f"Reading {i + 1:02d}: NO ECHO / INVALID")
            else:
                valid_readings += 1
                print(f"Reading {i + 1:02d}: {distance:.1f} cm")

            time.sleep(0.3)

    except KeyboardInterrupt:
        print("\nTest interrupted.")

    finally:
        sensor.close()

    print("\n========== TEST SUMMARY ==========")
    print(f"Valid readings:   {valid_readings}")
    print(f"Invalid readings: {invalid_readings}")

    if valid_readings == 20:
        print("Result: Sensor is returning valid readings.")
    elif valid_readings > 0:
        print("Result: Intermittent readings. Check wiring and sensor position.")
    else:
        print("Result: No valid readings. Check wiring, power and ECHO signal.")


if __name__ == "__main__":
    main()
