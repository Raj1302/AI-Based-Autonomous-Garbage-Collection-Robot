"""GC-BOT: YOLOv8 ONNX detection, three-zone overlay, and safe approach."""
import argparse
import time
import cv2
import config

from ai.detector import WasteDetector, draw_detections
from hardware.camera import Camera
from hardware.motors import Motors
from hardware.ultrasonic import Ultrasonic
from robot.approach_controller import ApproachController
from robot.pickup_controller import PickupController


def choose_target(detections, frame_width):
    """Choose a confident target with a mild preference for larger, central boxes."""
    if not detections:
        return None

    frame_area = max(1, frame_width)
    def score(d):
        x1, _, x2, _ = d["box"]
        box_width = max(0, x2 - x1)
        center_penalty = abs(d["center"][0] - frame_width / 2) / (frame_width / 2)
        size_bonus = min(0.10, box_width / frame_area * 0.10)
        return d["confidence"] - 0.12 * center_penalty + size_bonus

    return max(detections, key=score)


def main():
    parser = argparse.ArgumentParser(description="GC-BOT autonomous waste approach")
    parser.add_argument("--camera", type=int, default=config.CAMERA_INDEX,
                        help="OpenCV camera index")
    parser.add_argument("--simulate", action="store_true",
                        help="Disable real motors and ultrasonic hardware")
    args = parser.parse_args()

    detector = WasteDetector()
    camera = None
    motors = None
    ultrasonic = None
    start_time = time.monotonic()
    last_ping = 0.0
    distance_cm = None
    distance_timestamp = None
    confirmed_frames = 0
    target_lost_frames = 0
    pickup_attempted_for_stop = False

    try:
        camera = Camera(args.camera)
        motors = Motors(simulated=args.simulate or not config.ENABLE_REAL_MOTORS)

        if not args.simulate and config.ENABLE_REAL_ULTRASONIC:
            ultrasonic = Ultrasonic(config.FRONT_TRIG_GPIO, config.FRONT_ECHO_GPIO)
            print("[HARDWARE] Front ultrasonic initialized")
        else:
            print("[SAFE MODE] Ultrasonic unavailable/disabled; robot will not approach")

        controller = ApproachController(motors)
        pickup = PickupController(dry_run=True)
        print("[GC-BOT] Press q to quit. Keep an operator at the power switch.")

        while True:
            if time.monotonic() - start_time >= config.APPROACH_TIMEOUT_S:
                motors.stop()
                print("Approach timeout: stopped for safety.")
                break

            frame = camera.read()
            detections = detector.detect(frame)
            target = choose_target(detections, frame.shape[1])

            if target is not None:
                confirmed_frames += 1
                target_lost_frames = 0
                target["frame_width"] = frame.shape[1]
            else:
                confirmed_frames = 0
                target_lost_frames += 1

            if ultrasonic is not None and (
                time.monotonic() - last_ping >= config.ULTRASONIC_PING_INTERVAL_S
            ):
                measured = ultrasonic.distance_cm()
                last_ping = time.monotonic()
                if measured is not None:
                    distance_cm = measured
                    distance_timestamp = last_ping
                    print(f"Front distance: {distance_cm:.1f} cm")
                else:
                    # An invalid ping invalidates the prior reading for safety.
                    distance_cm = None
                    distance_timestamp = None
                    print("Front distance: INVALID")

            distance_age = (
                time.monotonic() - distance_timestamp
                if distance_timestamp is not None else None
            )

            if target is None or confirmed_frames < config.TARGET_CONFIRM_FRAMES:
                motors.stop()
                status = "SEARCHING" if target is None else "CONFIRMING TARGET"
            elif ultrasonic is None:
                motors.stop()
                status = "STOPPED: ULTRASONIC DISABLED"
            else:
                status = controller.update(target, distance_cm, distance_age)

            # Consume the existing controller's explicit stop report once per
            # stop episode. Pickup owns no navigation or chassis control.
            stopped_for_target = (
                status == "STOPPED: STOP DISTANCE"
                and target is not None
                and confirmed_frames >= config.TARGET_CONFIRM_FRAMES
            )
            if stopped_for_target and not pickup_attempted_for_stop:
                motors.stop()
                result = pickup.pickup(target)
                print(f"[PICKUP] {result.status}: {result.detail}")
                pickup_attempted_for_stop = True
            elif not stopped_for_target:
                pickup_attempted_for_stop = False
                pickup.reset()

            overlay = frame.copy()
            draw_detections(overlay, detections)
            
            if config.SHOW_PREVIEW:
                cv2.imshow("GC-BOT (q to quit)", overlay)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    print("Quit requested: stopping motors.")
                    break

    except KeyboardInterrupt:
        print("\nKeyboard interrupt: stopping motors.")
    except Exception as exc:
        print(f"[ERROR] {exc}")
        raise
    finally:
        if motors is not None:
            motors.stop()
        if ultrasonic is not None:
            ultrasonic.close()
        if camera is not None:
            camera.close()
        if motors is not None:
            motors.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
