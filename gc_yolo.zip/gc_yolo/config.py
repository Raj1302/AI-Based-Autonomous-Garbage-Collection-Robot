
"""GC-BOT configuration for YOLOv8 ONNX on Raspberry Pi."""

from pathlib import Path

ROOT = Path(__file__).resolve().parent

# ============================================================
# YOLO MODEL CONFIGURATION
# ============================================================

MODEL_PATH = ROOT / "models" / "waste_model.onnx"
CLASS_PATH = ROOT / "config" / "classes.txt"

MODEL_INPUT_WIDTH = 320
MODEL_INPUT_HEIGHT = 320

CONFIDENCE_THRESHOLD = 0.35
NMS_IOU_THRESHOLD = 0.45

CLASS_NAMES = ["plastic", "paper", "cardboard"]


# ============================================================
# ULTRASONIC SENSOR GPIO CONFIGURATION
# ============================================================

FRONT_TRIG_GPIO = 9
FRONT_ECHO_GPIO = 25

REAR_TRIG_GPIO = 16
REAR_ECHO_GPIO = 12

STOP_DISTANCE_CM = 15.0
APPROACH_MAX_DISTANCE_CM = 100.0

ULTRASONIC_MIN_VALID_CM = 2.0
ULTRASONIC_MAX_VALID_CM = 350.0
ULTRASONIC_PING_INTERVAL_S = 0.12


# ============================================================
# MOTOR DIRECTION GPIO CONFIGURATION
# ============================================================

# L298N #1 - LEFT SIDE
# Front-left: IN1 = GPIO17, IN2 = GPIO27
# Rear-left:  IN1 = GPIO24, IN2 = GPIO10

# L298N #2 - RIGHT SIDE
# Front-right: IN1 = GPIO5, IN2 = GPIO6
# Rear-right:  IN1 = GPIO13, IN2 = GPIO26

MOTOR_PINS = {
    "front_left": {
        "in1": 17,
        "in2": 27,
    },
    "rear_left": {
        "in1": 24,
        "in2": 10,
    },
    "front_right": {
        "in1": 5,
        "in2": 6,
    },
    "rear_right": {
        "in1": 13,
        "in2": 26,
    },
}


# Invert right-side motors to account for their mounting orientation.
MOTOR_INVERT = {
    "front_left": False,
    "rear_left": False,
    "front_right": True,
    "rear_right": True,
}


# ============================================================
# L298N ENABLE PINS - ENA / ENB PWM CONTROL
# ============================================================

# L298N #1 - LEFT SIDE
# ENA -> GPIO18 (physical pin 12)
# ENB -> GPIO19 (physical pin 35)

# L298N #2 - RIGHT SIDE
# ENA -> GPIO20 (physical pin 38)
# ENB -> GPIO21 (physical pin 40)

# Assumed mapping:
# L298N #1 ENA -> Front-left
# L298N #1 ENB -> Rear-left
# L298N #2 ENA -> Front-right
# L298N #2 ENB -> Rear-right

MOTOR_ENABLE_PINS = {
    "front_left": 18,
    "rear_left": 19,
    "front_right": 20,
    "rear_right": 21,
}

MOTOR_PWM_FREQUENCY = 1000
MOTOR_SPEED_PERCENT = 70


# ============================================================
# CAMERA CONFIGURATION
# ============================================================

CAMERA_INDEX = 0
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

SHOW_PREVIEW = True


# ============================================================
# AUTONOMOUS ROBOT CONFIGURATION
# ============================================================

TARGET_CONFIRM_FRAMES = 3
TARGET_LOST_STOP_FRAMES = 5

APPROACH_TIMEOUT_S = 30.0


# ============================================================
# HARDWARE ENABLE SWITCHES
# ============================================================

ENABLE_REAL_MOTORS = True

# Keep disabled until ultrasonic wiring and voltage levels
# have been verified.
ENABLE_REAL_ULTRASONIC = True


# ============================================================
# THREE-ZONE TARGET ALIGNMENT
# ============================================================

# Display zones are thirds of the live camera frame.
SHOW_ZONE_OVERLAY = True
TARGET_CONFIRM_FRAMES = 3
TARGET_LOST_STOP_FRAMES = 3

# Central deadband for alignment (fraction of frame width).
# The selected target is considered aligned inside this central range.
CENTER_DEADBAND_MIN = 0.30
CENTER_DEADBAND_MAX = 0.70

# Separate speeds for cautious alignment and forward approach.
ALIGNMENT_SPEED_PERCENT = 25
APPROACH_SPEED_PERCENT = 35
ALIGNMENT_PULSE_SECONDS = 0.12
ALIGNMENT_SETTLE_SECONDS = 0.08

# Sensor readings older than this are considered stale.
ULTRASONIC_MAX_AGE_S = 0.40

# IMPORTANT: Keep False until mecanum wheel orientation and motor mapping
# are verified with all wheels lifted. True enables the standard mecanum
# strafe pattern in hardware/motors.py; validate actual direction first.
ENABLE_STRAFE = False
