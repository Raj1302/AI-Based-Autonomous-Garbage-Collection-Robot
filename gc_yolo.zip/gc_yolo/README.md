# GC-BOT Raspberry Pi deployment — AI waste approach

## Goal
Use the currently trained YOLOv8n ONNX model to detect plastic, paper, or cardboard, then approach a centered target and stop when the **front ultrasonic sensor reads 15 cm or less**.

## Model
Copy your existing 12,649,041-byte model to:
`models/waste_model.onnx`

This bundle does not contain the model file. It uses the YOLOv8n ONNX export currently in your Windows project, not the older MobileNetSSD Caffe model.

## Current status / limitations
- AI detector is written for the exported output shape `(1, 7, 2100)` and must be verified on sample images.
- Motors and ultrasonic hardware code are included, but the actual GPIO wiring has not been verified against the full source package in this chat.
- `ENABLE_REAL_MOTORS` and `ENABLE_REAL_ULTRASONIC` are **False by default**. Do not enable until pins/wiring are verified and tests pass.
- The initial approach controller stops if the target is not centered; it does not turn the car. This avoids unverified steering assumptions. Implement/test steering once the wheel mapping is confirmed.
- The robot arm is not activated by this package because the immediate requirement is to approach waste and stop at 15 cm.
- Never connect an ultrasonic ECHO pin directly to a Pi GPIO if it can output 5 V. Use a suitable voltage divider/level shifter.
- Motors should be powered from a suitable motor supply; do not power motors from the Pi 5 V pin.

## Raspberry Pi install (64-bit OS; Python 3.11 recommended)
```bash
cd gc_bot_pi_deployment
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Install/enable Raspberry Pi GPIO support according to your OS. Enable I2C only if using PCA9685 later.

## Test order
1. Confirm model exists: `ls -lh models/waste_model.onnx`
2. Static image test: `python tests/test_model.py /path/to/test.jpg`
3. AI-only camera test: `python main_ai_test.py --camera 0`
4. Check front ultrasonic wiring and ECHO voltage, then set `ENABLE_REAL_ULTRASONIC=True` in `config.py`; run `python tests/test_ultrasonic.py`.
5. Confirm motor pin mapping against your actual wiring and with wheels lifted. Only then set `ENABLE_REAL_MOTORS=True` and run `python tests/test_motors.py`.
6. After hardware tests pass, run `python main_robot.py --camera 0`.

## Important
The `--simulate` flag is for logic preview; it intentionally does not fake a safe distance, so the car will stop instead of moving when distance is invalid. Never test autonomous movement with wheels on the floor until the real sensor reading and motor directions have been confirmed.


## Three-zone deployment update

The preview now draws LEFT, CENTER, and RIGHT zones and displays the selected waste class, confidence, state, and front distance. The autonomous controller stops for missing, invalid, stale, or too-close distance readings.

### Important: steering is deliberately disabled by default

`config.py` contains `ENABLE_STRAFE = False`. The code includes a standard X-roller mecanum strafe pattern, but the actual wheel roller orientation and motor channel mapping must be verified on this robot before enabling it. With this flag False, the screen reports that alignment is disabled and motors remain stopped rather than guessing the direction.

### Run checks on Raspberry Pi

```bash
cd ~/gc_bot_pi_deployment_complete
source .venv/bin/activate
python -m py_compile main_robot.py config.py ai/detector.py hardware/camera.py hardware/motors.py hardware/ultrasonic.py robot/approach_controller.py robot/zones.py
python -m unittest tests.test_zones
```

Camera/model preview without real motor movement or ultrasonic-driven approach:

```bash
python main_robot.py --camera 0 --simulate
```

After confirming camera and ultrasonic readings, test wheel directions with all wheels lifted and the motor power switch reachable. Only then, after confirming the mecanum roller layout and each motor's actual direction, set `ENABLE_STRAFE = True` and test `strafe_left()` / `strafe_right()` at low speed with wheels lifted. Do not enable automatic floor movement until this mapping is verified.


## Arm pickup addition (camera 2 only; movement interlocked)

The arm feature is isolated in `arm_config.py`, `hardware/arm_camera.py`, `hardware/arm_vision.py`, `hardware/arm_controller.py`, `robot/inverse_kinematics.py`, and `robot/pickup_controller.py`. `main_robot.py` calls it once when the existing `ApproachController.update()` returns exactly `STOPPED: STOP DISTANCE` for a confirmed target. The existing controller remains the sole owner of approach, stopping, motors, and obstacle sensing. The integrated instance is dry-run only.

The archive supplies only this PCA9685 channel naming: CH0 base rotation, CH1 shoulder, CH2 elbow, CH3 wrist, CH4 wrist rotation, CH5 gripper. Actual servo-to-channel wiring and Pi-to-board wiring are unverified. No PCA9685 driver, arm geometry, servo calibration, gripper action, or camera calibration exists in the archive. `arm_config.py` therefore leaves all physical values unset and `REAL_MOVEMENT_ENABLED = False`. Do not enable movement by editing only that flag: a PCA9685 driver, pulse calibration, verified start pose, visual pose estimator, pickup pose, feedback controller, and independent calibration evidence are not commissioned here.

### Dry-run and camera 2 checks

From the project root, using the Python environment installed for this deployment:

```bash
python -m py_compile arm_config.py arm_dry_run.py hardware/arm_camera.py hardware/arm_camera_test.py hardware/arm_controller.py hardware/arm_vision.py robot/inverse_kinematics.py robot/pickup_controller.py main_robot.py
python arm_dry_run.py --dry-run
```

On the Raspberry Pi, after activating the project environment, check only camera 2 (no camera 0 open):

```bash
python hardware/arm_camera_test.py --camera-check
```

This check opens `/dev/video2`, reads ten frames, and exits. The main integrated dry-run does not open either camera from the arm module and cannot activate motor/servo outputs.

### Hardware questions to resolve before motion

| Item | Archive status | Required confirmation |
|---|---|---|
| Raspberry Pi to PCA9685 SDA/SCL, power, ground, I2C address | Not documented | Record actual board wiring; enable I2C and confirm address with `i2cdetect -y 1` on Pi |
| PCA9685 VCC | Not documented | Verify logic supply and board requirements |
| PCA9685 V+ and common ground | Not documented | Verify external servo supply polarity/rating and common ground with Pi and PCA9685 |
| Servo-to-channel wiring | Channel names provided only | Confirm each of six physical servo leads against CH0–CH5 |
| MG995/MG90S exact variants and supply | Not documented | Check exact datasheets/labels and combined stall-current needs; do not power servos from Pi 3.3/5 V |
| Actual arm arrangement and geometry | Not documented | Measure links, axes, offsets, gripper orientation and pickup height |
| Each servo mapping/calibration | Not documented | Establish neutral pulse, direction, safe limits and conservative increments individually |
| Starting pose/gripper action | Not documented | Record a known safe pose and how the gripper opens/closes |
| Camera mounting/calibration | Camera 2 device stated only | Calibrate intrinsics/distortion and camera-to-base transform; define target plane/height and known-size reference or markers |
| Visual evidence | Not defined in archive | Provide visible markers/features and validate before/after lift/held criteria; a closed gripper is insufficient |

Camera pixels and the AI detection center are not physical XYZ. A calibrated projection needs camera intrinsics/distortion, camera pose relative to arm base, and a known plane/depth or equivalent reference. The current vision module intentionally refuses to estimate coordinates; ordinary webcam images cannot directly read servo angles. The camera test only verifies frames, not calibration or tracking.

### Raspberry Pi independent checks and staged commissioning

Run in this order, with the chassis motors disabled during all arm-only checks:

1. Preserve the current deployment (see rollback below). Confirm actual servo-channel wiring, Pi/PCA9685 pins, I2C address, polarity, logic power, external V+ supply and common ground. Compare exact servo variants and combined current demand against their specifications before selecting a supply.
2. Activate the existing project Python environment. Confirm I2C device visibility with `i2cdetect -y 1`; a missing command can be installed using the OS package manager, and permission/device-tree issues should be diagnosed rather than running project Python with sudo.
3. Run `python hardware/arm_camera_test.py --camera-check`; confirm ten valid frames from `/dev/video2`. Resolve device numbering/permissions first if it fails. It must not be redirected to `/dev/video0`.
4. Obtain measured geometry and full calibration values listed above. Implement and independently review the actual arm pose estimator, IK model for its real degrees of freedom, PCA9685 driver parameters and servo pulse mapping. Keep movement disabled until these are recorded and verified. Current archive lacks sufficient data for these steps; there is no servo-channel sweep command in this package.
5. Run the compile and dry-run commands above. Unit-level IK calculations with real measured values and joint-limit rejection can only be meaningful after those values are supplied; current IK deliberately rejects absent geometry/limits.
6. Only after the driver and all calibration are completed, test one channel/joint at a time at conservative measured values, without waste and with chassis motors disabled. Verify direction/range and stop on unexpected movement. No joint test is enabled by this package.
7. Validate visual tracking and target-plane calibration, then verify lift/held evidence. A frame-valid result alone never produces `PICKUP_SUCCESS`. Attempt a controlled pickup only after prior checks pass and an operator can remove servo power.
8. Test the integrated stop event on the Pi with motors disabled/simulated and pickup dry-run. Compare the stop text and event count; do not change navigation thresholds or movement behavior.

I2C scan command: `i2cdetect -y 1`. No hardware was attached to this development environment, so I2C, camera, servo, tracking, stop-event runtime, and pickup are Raspberry Pi commissioning checks, not tests claimed as passed here.

### Rollback

The original ZIP in Downloads was not modified. The extracted working copy is separate. To roll back this output copy, remove `outputs/gc_yolo/gc_yolo/main_robot.py` and the eight added files (`arm_config.py`, `arm_dry_run.py`, `hardware/arm_camera.py`, `hardware/arm_camera_test.py`, `hardware/arm_controller.py`, `hardware/arm_vision.py`, `robot/inverse_kinematics.py`, `robot/pickup_controller.py`); restore `main_robot.py` from the original archive. If deployed on Pi, first stop the service/process, back up that deployment, then restore only the prior `main_robot.py` and remove those added files. Do not overwrite model, config, camera, motor, sensor, or navigation files.
